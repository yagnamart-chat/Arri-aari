package a1;

import java.io.Closeable;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public final class a implements Closeable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final a f5a = new a();

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public final void close() {
    }
}
