package a4;

import android.graphics.Bitmap;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public final class v {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Bitmap f184a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int f185b;

    public v(Bitmap bitmap, int i) {
        this.f184a = bitmap;
        this.f185b = i;
    }
}
