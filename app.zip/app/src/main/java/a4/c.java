package a4;

import android.content.Context;
import android.content.res.AssetManager;
import android.net.Uri;
import b2.t1;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public final class c extends n0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Context f79a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Object f80b = new Object();

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public AssetManager f81c;

    public c(Context context) {
        this.f79a = context;
    }

    @Override // a4.n0
    public final boolean b(k0 k0Var) {
        Uri uri = (Uri) k0Var.f131b;
        return "file".equals(uri.getScheme()) && !uri.getPathSegments().isEmpty() && "android_asset".equals(uri.getPathSegments().get(0));
    }

    @Override // a4.n0
    public final m0 e(k0 k0Var, int i) {
        if (this.f81c == null) {
            synchronized (this.f80b) {
                try {
                    if (this.f81c == null) {
                        this.f81c = this.f79a.getAssets();
                    }
                } finally {
                }
            }
        }
        return new m0(t1.h0(this.f81c.open(((Uri) k0Var.f131b).toString().substring(22))), 2);
    }
}
