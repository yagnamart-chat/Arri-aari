package a4;

import android.content.Context;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Looper;
import android.view.ViewTreeObserver;
import android.widget.ImageView;
import com.squareup.picasso.PicassoProvider;
import com.uptodown.R;
import j$.util.DesugarCollections;
import java.lang.ref.ReferenceQueue;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;
import java.util.WeakHashMap;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public final class g0 {
    public static final c0 j = new c0(Looper.getMainLooper(), 0, false);

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public static volatile g0 f98k = null;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final f0 f99a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final List f100b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Context f101c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final q f102d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final a3.d f103e;
    public final o0 f;
    public final WeakHashMap g;
    public final WeakHashMap h;
    public final ReferenceQueue i;

    public g0(Context context, q qVar, a3.d dVar, f0 f0Var, o0 o0Var) {
        this.f101c = context;
        this.f102d = qVar;
        this.f103e = dVar;
        this.f99a = f0Var;
        ArrayList arrayList = new ArrayList(7);
        arrayList.add(new k(context, 1));
        arrayList.add(new j(context));
        int i = 0;
        arrayList.add(new y(context, i));
        arrayList.add(new k(context, i));
        arrayList.add(new c(context));
        arrayList.add(new y(context, 1));
        arrayList.add(new b0(qVar.f174c, o0Var));
        this.f100b = DesugarCollections.unmodifiableList(arrayList);
        this.f = o0Var;
        this.g = new WeakHashMap();
        this.h = new WeakHashMap();
        ReferenceQueue referenceQueue = new ReferenceQueue();
        this.i = referenceQueue;
        new e0(referenceQueue, j).start();
    }

    public static g0 d() {
        if (f98k == null) {
            synchronized (g0.class) {
                try {
                    if (f98k == null) {
                        Context context = PicassoProvider.f3441a;
                        if (context == null) {
                            throw new IllegalStateException("context == null");
                        }
                        f98k = new d0(context).h();
                    }
                } finally {
                }
            }
        }
        return f98k;
    }

    public final void a(Object obj) {
        StringBuilder sb = t0.f181a;
        if (Looper.getMainLooper().getThread() != Thread.currentThread()) {
            androidx.window.layout.c.g("Method call should happen from the main thread.");
            return;
        }
        b bVar = (b) this.g.remove(obj);
        if (bVar != null) {
            bVar.a();
            n nVar = this.f102d.h;
            nVar.sendMessage(nVar.obtainMessage(2, bVar));
        }
        if (obj instanceof ImageView) {
            l lVar = (l) this.h.remove((ImageView) obj);
            if (lVar != null) {
                lVar.f137l = null;
                WeakReference weakReference = lVar.f136b;
                ImageView imageView = (ImageView) weakReference.get();
                if (imageView == null) {
                    return;
                }
                weakReference.clear();
                imageView.removeOnAttachStateChangeListener(lVar);
                ViewTreeObserver viewTreeObserver = imageView.getViewTreeObserver();
                if (viewTreeObserver.isAlive()) {
                    viewTreeObserver.removeOnPreDrawListener(lVar);
                }
            }
        }
    }

    public final void b(Bitmap bitmap, int i, b bVar, Exception exc) {
        if (bVar.g) {
            return;
        }
        if (!bVar.f) {
            this.g.remove(bVar.d());
        }
        if (bitmap == null) {
            bVar.c(exc);
        } else if (i != 0) {
            bVar.b(bitmap, i);
        } else {
            a3.b.j("LoadedFrom cannot be null.");
        }
    }

    public final void c(b bVar) {
        Object objD = bVar.d();
        if (objD != null) {
            WeakHashMap weakHashMap = this.g;
            if (weakHashMap.get(objD) != bVar) {
                a(objD);
                weakHashMap.put(objD, bVar);
            }
        }
        n nVar = this.f102d.h;
        nVar.sendMessage(nVar.obtainMessage(1, bVar));
    }

    public final l0 e(String str) {
        if (str == null) {
            return new l0(this, null, 0);
        }
        if (str.trim().length() != 0) {
            return new l0(this, Uri.parse(str), 0);
        }
        com.google.android.material.drawable.a.l("Path must not be empty.");
        return null;
    }

    public final l0 f() {
        return new l0(this, null, R.drawable.vector_user_default);
    }

    public final Bitmap g(String str) {
        v vVar = (v) ((u) this.f103e.f67b).get(str);
        Bitmap bitmap = vVar != null ? vVar.f184a : null;
        o0 o0Var = this.f;
        if (bitmap != null) {
            o0Var.f152b.sendEmptyMessage(0);
            return bitmap;
        }
        o0Var.f152b.sendEmptyMessage(1);
        return bitmap;
    }
}
