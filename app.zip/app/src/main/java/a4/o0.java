package a4;

import android.os.HandlerThread;
import android.os.Looper;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public final class o0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final a3.d f151a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final n f152b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public long f153c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public long f154d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public long f155e;
    public long f;
    public long g;
    public long h;
    public long i;
    public long j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public int f156k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public int f157l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public int f158m;

    public o0(a3.d dVar) {
        this.f151a = dVar;
        HandlerThread handlerThread = new HandlerThread("Picasso-Stats", 10);
        handlerThread.start();
        Looper looper = handlerThread.getLooper();
        StringBuilder sb = t0.f181a;
        c0 c0Var = new c0(looper, 1, false);
        c0Var.sendMessageDelayed(c0Var.obtainMessage(), 1000L);
        this.f152b = new n(handlerThread.getLooper(), this, 1);
    }

    public final p0 a() {
        a3.d dVar = this.f151a;
        return new p0(((u) dVar.f67b).maxSize(), ((u) dVar.f67b).size(), this.f153c, this.f154d, this.f155e, this.f, this.g, this.h, this.i, this.j, this.f156k, this.f157l, this.f158m, System.currentTimeMillis());
    }
}
