package a4;

import android.graphics.Bitmap;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public abstract class b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final g0 f72a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final k0 f73b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final a f74c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final String f75d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final b f76e;
    public boolean f;
    public boolean g;

    public b(g0 g0Var, Object obj, k0 k0Var, String str) {
        this.f72a = g0Var;
        this.f73b = k0Var;
        this.f74c = obj == null ? null : new a(this, obj, g0Var.i);
        this.f75d = str;
        this.f76e = this;
    }

    public void a() {
        this.g = true;
    }

    public abstract void b(Bitmap bitmap, int i);

    public abstract void c(Exception exc);

    public Object d() {
        a aVar = this.f74c;
        if (aVar == null) {
            return null;
        }
        return aVar.get();
    }
}
