package a4;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.Animatable;
import android.graphics.drawable.Drawable;
import android.widget.ImageView;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public final class t extends b {
    public i h;

    @Override // a4.b
    public final void a() {
        this.g = true;
        if (this.h != null) {
            this.h = null;
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // a4.b
    public final void b(Bitmap bitmap, int i) {
        if (bitmap == null) {
            throw new AssertionError("Attempted to complete action with no result!\n" + this);
        }
        ImageView imageView = (ImageView) this.f74c.get();
        if (imageView == null) {
            return;
        }
        Context context = this.f72a.f101c;
        int i10 = h0.f120e;
        Drawable drawable = imageView.getDrawable();
        if (drawable instanceof Animatable) {
            ((Animatable) drawable).stop();
        }
        imageView.setImageDrawable(new h0(context, bitmap, drawable, i));
        i iVar = this.h;
        if (iVar != null) {
            iVar.onSuccess();
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // a4.b
    public final void c(Exception exc) {
        ImageView imageView = (ImageView) this.f74c.get();
        if (imageView == null) {
            return;
        }
        Object drawable = imageView.getDrawable();
        if (drawable instanceof Animatable) {
            ((Animatable) drawable).stop();
        }
        i iVar = this.h;
        if (iVar != null) {
            iVar.d(exc);
        }
    }
}
