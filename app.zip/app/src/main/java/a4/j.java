package a4;

import android.content.ContentResolver;
import android.content.Context;
import android.content.UriMatcher;
import android.net.Uri;
import android.provider.ContactsContract;
import b2.t1;
import java.io.FileNotFoundException;
import java.io.InputStream;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public final class j extends n0 {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final UriMatcher f126b;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Context f127a;

    static {
        UriMatcher uriMatcher = new UriMatcher(-1);
        f126b = uriMatcher;
        uriMatcher.addURI("com.android.contacts", "contacts/lookup/*/#", 1);
        uriMatcher.addURI("com.android.contacts", "contacts/lookup/*", 1);
        uriMatcher.addURI("com.android.contacts", "contacts/#/photo", 2);
        uriMatcher.addURI("com.android.contacts", "contacts/#", 3);
        uriMatcher.addURI("com.android.contacts", "display_photo/#", 4);
    }

    public j(Context context) {
        this.f127a = context;
    }

    @Override // a4.n0
    public final boolean b(k0 k0Var) {
        Uri uri = (Uri) k0Var.f131b;
        return "content".equals(uri.getScheme()) && ContactsContract.Contacts.CONTENT_URI.getHost().equals(uri.getHost()) && f126b.match(uri) != -1;
    }

    @Override // a4.n0
    public final m0 e(k0 k0Var, int i) throws FileNotFoundException {
        InputStream inputStreamOpenContactPhotoInputStream;
        ContentResolver contentResolver = this.f127a.getContentResolver();
        Uri uriLookupContact = (Uri) k0Var.f131b;
        int iMatch = f126b.match(uriLookupContact);
        if (iMatch != 1) {
            if (iMatch != 2) {
                if (iMatch != 3) {
                    if (iMatch != 4) {
                        a3.b.k(uriLookupContact, "Invalid uri: ");
                        return null;
                    }
                }
            }
            inputStreamOpenContactPhotoInputStream = contentResolver.openInputStream(uriLookupContact);
        } else {
            uriLookupContact = ContactsContract.Contacts.lookupContact(contentResolver, uriLookupContact);
            inputStreamOpenContactPhotoInputStream = uriLookupContact == null ? null : ContactsContract.Contacts.openContactPhotoInputStream(contentResolver, uriLookupContact, true);
        }
        if (inputStreamOpenContactPhotoInputStream == null) {
            return null;
        }
        return new m0(t1.h0(inputStreamOpenContactPhotoInputStream), 2);
    }
}
