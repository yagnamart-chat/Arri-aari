package a4;

import android.content.Context;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import b2.t1;
import java.io.FileNotFoundException;
import java.util.List;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public class k extends n0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f128a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Context f129b;

    public /* synthetic */ k(Context context, int i) {
        this.f128a = i;
        this.f129b = context;
    }

    @Override // a4.n0
    public boolean b(k0 k0Var) {
        switch (this.f128a) {
            case 0:
                return "content".equals(((Uri) k0Var.f131b).getScheme());
            default:
                if (k0Var.f132c != 0) {
                    return true;
                }
                return "android.resource".equals(((Uri) k0Var.f131b).getScheme());
        }
    }

    @Override // a4.n0
    public m0 e(k0 k0Var, int i) throws FileNotFoundException {
        Resources resources;
        int i10 = this.f128a;
        Context context = this.f129b;
        switch (i10) {
            case 0:
                return new m0(t1.h0(context.getContentResolver().openInputStream((Uri) k0Var.f131b)), 2);
            default:
                StringBuilder sb = t0.f181a;
                int i11 = k0Var.f132c;
                Uri uri = (Uri) k0Var.f131b;
                if (i11 == 0 && uri != null) {
                    String authority = uri.getAuthority();
                    if (authority == null) {
                        a3.b.v(uri, "No package provided: ");
                        return null;
                    }
                    try {
                        resources = context.getPackageManager().getResourcesForApplication(authority);
                    } catch (PackageManager.NameNotFoundException unused) {
                        a3.b.v(uri, "Unable to obtain resources for package: ");
                        return null;
                    }
                    break;
                } else {
                    resources = context.getResources();
                }
                int identifier = k0Var.f132c;
                if (identifier == 0 && uri != null) {
                    String authority2 = uri.getAuthority();
                    if (authority2 == null) {
                        a3.b.v(uri, "No package provided: ");
                        return null;
                    }
                    List<String> pathSegments = uri.getPathSegments();
                    if (pathSegments == null || pathSegments.isEmpty()) {
                        a3.b.v(uri, "No path segments: ");
                        return null;
                    }
                    if (pathSegments.size() == 1) {
                        try {
                            identifier = Integer.parseInt(pathSegments.get(0));
                        } catch (NumberFormatException unused2) {
                            a3.b.v(uri, "Last path segment is not a resource ID: ");
                            return null;
                        }
                    } else {
                        if (pathSegments.size() != 2) {
                            a3.b.v(uri, "More than two path segments: ");
                            return null;
                        }
                        identifier = resources.getIdentifier(pathSegments.get(1), pathSegments.get(0), authority2);
                    }
                    break;
                }
                BitmapFactory.Options optionsC = n0.c(k0Var);
                if (optionsC != null && optionsC.inJustDecodeBounds) {
                    BitmapFactory.decodeResource(resources, identifier, optionsC);
                    n0.a(k0Var.f133d, k0Var.f134e, optionsC.outWidth, optionsC.outHeight, optionsC, k0Var);
                }
                Bitmap bitmapDecodeResource = BitmapFactory.decodeResource(resources, identifier, optionsC);
                if (bitmapDecodeResource != null) {
                    return new m0(bitmapDecodeResource, null, 2, 0);
                }
                com.google.android.material.drawable.a.j("bitmap == null");
                return null;
        }
    }
}
