package a4;

import android.net.Uri;
import j$.util.DesugarCollections;
import java.io.EOFException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public final class k0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f130a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public Object f131b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f132c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f133d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f134e;
    public boolean f;
    public int g;
    public int h;
    public Object i;

    public k0(Uri uri, int i, ArrayList arrayList, int i10, int i11, boolean z9, int i12, int i13) {
        this.f130a = 1;
        this.f131b = uri;
        this.f132c = i;
        if (arrayList == null) {
            this.i = null;
        } else {
            this.i = DesugarCollections.unmodifiableList(arrayList);
        }
        this.f133d = i10;
        this.f134e = i11;
        this.f = z9;
        this.g = i12;
        this.h = i13;
    }

    public void a(int i) {
        int i10;
        if (i > 0) {
            int length = ((w8.b[]) this.i).length - 1;
            int i11 = 0;
            while (true) {
                i10 = this.f134e;
                if (length < i10 || i <= 0) {
                    break;
                }
                int i12 = ((w8.b[]) this.i)[length].f10823c;
                i -= i12;
                this.h -= i12;
                this.g--;
                i11++;
                length--;
            }
            w8.b[] bVarArr = (w8.b[]) this.i;
            int i13 = i10 + 1;
            System.arraycopy(bVarArr, i13, bVarArr, i13 + i11, this.g);
            w8.b[] bVarArr2 = (w8.b[]) this.i;
            int i14 = this.f134e + 1;
            Arrays.fill(bVarArr2, i14, i14 + i11, (Object) null);
            this.f134e += i11;
        }
    }

    public boolean b() {
        return (this.f133d == 0 && this.f134e == 0) ? false : true;
    }

    public void c(w8.b bVar) {
        int i = bVar.f10823c;
        int i10 = this.f133d;
        if (i > i10) {
            Arrays.fill((w8.b[]) this.i, (Object) null);
            this.f134e = ((w8.b[]) this.i).length - 1;
            this.g = 0;
            this.h = 0;
            return;
        }
        a((this.h + i) - i10);
        int i11 = this.g + 1;
        w8.b[] bVarArr = (w8.b[]) this.i;
        if (i11 > bVarArr.length) {
            w8.b[] bVarArr2 = new w8.b[bVarArr.length * 2];
            System.arraycopy(bVarArr, 0, bVarArr2, bVarArr.length, bVarArr.length);
            this.f134e = ((w8.b[]) this.i).length - 1;
            this.i = bVarArr2;
        }
        int i12 = this.f134e;
        this.f134e = i12 - 1;
        ((w8.b[]) this.i)[i12] = bVar;
        this.g++;
        this.h += i;
    }

    public boolean d() {
        return b();
    }

    public void e(int i, int i10) {
        if (i < 0) {
            com.google.android.material.drawable.a.l("Width must be positive number or 0.");
            return;
        }
        if (i10 < 0) {
            com.google.android.material.drawable.a.l("Height must be positive number or 0.");
        } else if (i10 == 0 && i == 0) {
            com.google.android.material.drawable.a.l("At least one dimension has to be positive number.");
        } else {
            this.f133d = i;
            this.f134e = i10;
        }
    }

    public void f(a9.k kVar) throws EOFException {
        a9.h hVar = (a9.h) this.f131b;
        w8.y.f10918d.getClass();
        long j = 0;
        long j10 = 0;
        for (int i = 0; i < kVar.f(); i++) {
            j10 += (long) w8.y.f10917c[kVar.k(i) & 255];
        }
        if (((int) ((j10 + 7) >> 3)) >= kVar.f()) {
            g(kVar.f(), 127, 0);
            hVar.y(kVar);
            return;
        }
        a9.h hVar2 = new a9.h();
        w8.y.f10918d.getClass();
        int i10 = 0;
        for (int i11 = 0; i11 < kVar.f(); i11++) {
            int iK = kVar.k(i11) & 255;
            int i12 = w8.y.f10916b[iK];
            byte b10 = w8.y.f10917c[iK];
            j = (j << b10) | ((long) i12);
            i10 += b10;
            while (i10 >= 8) {
                i10 -= 8;
                hVar2.A((int) (j >> i10));
            }
        }
        if (i10 > 0) {
            hVar2.A((int) ((j << (8 - i10)) | ((long) (255 >>> i10))));
        }
        a9.k kVarF = hVar2.f(hVar2.f250b);
        g(kVarF.f(), 127, 128);
        hVar.y(kVarF);
    }

    public void g(int i, int i10, int i11) {
        a9.h hVar = (a9.h) this.f131b;
        if (i < i10) {
            hVar.A(i | i11);
            return;
        }
        hVar.A(i11 | i10);
        int i12 = i - i10;
        while (i12 >= 128) {
            hVar.A(128 | (i12 & 127));
            i12 >>>= 7;
        }
        hVar.A(i12);
    }

    public String toString() {
        switch (this.f130a) {
            case 1:
                int i = this.f133d;
                List<q0> list = (List) this.i;
                StringBuilder sb = new StringBuilder("Request{");
                int i10 = this.f132c;
                if (i10 > 0) {
                    sb.append(i10);
                } else {
                    sb.append((Uri) this.f131b);
                }
                if (list != null && !list.isEmpty()) {
                    for (q0 q0Var : list) {
                        sb.append(' ');
                        sb.append(q0Var.b());
                    }
                }
                if (i > 0) {
                    sb.append(" resize(");
                    sb.append(i);
                    sb.append(',');
                    sb.append(this.f134e);
                    sb.append(')');
                }
                if (this.f) {
                    sb.append(" centerCrop");
                }
                sb.append('}');
                return sb.toString();
            default:
                return super.toString();
        }
    }

    public k0(a9.h hVar) {
        this.f130a = 2;
        this.f132c = Integer.MAX_VALUE;
        this.i = new w8.b[8];
        this.f134e = 7;
        this.g = 0;
        this.h = 0;
        this.f133d = 4096;
        this.f131b = hVar;
    }
}
