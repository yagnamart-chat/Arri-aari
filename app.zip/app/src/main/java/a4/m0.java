package a4;

import android.graphics.Bitmap;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public final class m0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f145a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Bitmap f146b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final a9.g0 f147c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f148d;

    public m0(Bitmap bitmap, a9.g0 g0Var, int i, int i10) {
        if ((bitmap != null) == (g0Var != null)) {
            throw new AssertionError();
        }
        this.f146b = bitmap;
        this.f147c = g0Var;
        if (i == 0) {
            com.google.android.material.drawable.a.j("loadedFrom == null");
        }
        this.f145a = i;
        this.f148d = i10;
    }

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public m0(a9.g0 g0Var, int i) {
        this(null, g0Var, i, 0);
        StringBuilder sb = t0.f181a;
        if (g0Var != null) {
        } else {
            com.google.android.material.drawable.a.j("source == null");
            throw null;
        }
    }
}
