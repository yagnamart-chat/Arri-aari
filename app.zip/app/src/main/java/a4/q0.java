package a4;

import android.graphics.Bitmap;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public interface q0 {
    Bitmap a(Bitmap bitmap);

    String b();
}
