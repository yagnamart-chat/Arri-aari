package a4;

import android.graphics.Bitmap;
import android.widget.ProgressBar;
import c4.n1;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public final class s extends b {
    public final /* synthetic */ int h;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ s(g0 g0Var, Object obj, k0 k0Var, String str, int i) {
        super(g0Var, obj, k0Var, str);
        this.h = i;
    }

    @Override // a4.b
    public final void b(Bitmap bitmap, int i) {
        switch (this.h) {
            case 0:
                return;
            default:
                if (bitmap == null) {
                    throw new AssertionError("Attempted to complete action with no result!\n" + this);
                }
                n1 n1Var = (n1) d();
                if (n1Var != null) {
                    n1Var.a(bitmap, i);
                    if (bitmap.isRecycled()) {
                        androidx.window.layout.c.g("Target callback must not recycle bitmap!");
                        return;
                    }
                    return;
                }
                return;
        }
    }

    @Override // a4.b
    public final void c(Exception exc) {
        switch (this.h) {
            case 0:
                break;
            default:
                n1 n1Var = (n1) d();
                if (n1Var != null) {
                    exc.getClass();
                    ((ProgressBar) n1Var.f1955a.f1996a.f1381m).setVisibility(8);
                }
                break;
        }
    }

    private final void f(Exception exc) {
    }

    private final void e(Bitmap bitmap, int i) {
    }
}
