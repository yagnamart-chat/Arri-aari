package a4;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public final class e extends n0 {
    @Override // a4.n0
    public final boolean b(k0 k0Var) {
        return true;
    }

    @Override // a4.n0
    public final m0 e(k0 k0Var, int i) {
        throw new IllegalStateException("Unrecognized type of request: " + k0Var);
    }
}
