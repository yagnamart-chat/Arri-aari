package a4;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public final class w extends InputStream {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final InputStream f186a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public long f187b;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public long f188l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public long f189m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public long f190n = -1;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public boolean f191o = true;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final int f192p;

    public w(a9.f fVar) {
        this.f192p = -1;
        this.f186a = fVar.markSupported() ? fVar : new BufferedInputStream(fVar, 4096);
        this.f192p = 1024;
    }

    @Override // java.io.InputStream
    public final int available() {
        return this.f186a.available();
    }

    public final void b(long j) throws IOException {
        if (this.f187b > this.f189m || j < this.f188l) {
            com.google.android.material.drawable.a.k("Cannot reset");
            return;
        }
        this.f186a.reset();
        d(this.f188l, j);
        this.f187b = j;
    }

    public final void c(long j) {
        try {
            long j10 = this.f188l;
            long j11 = this.f187b;
            InputStream inputStream = this.f186a;
            if (j10 >= j11 || j11 > this.f189m) {
                this.f188l = j11;
                inputStream.mark((int) (j - j11));
            } else {
                inputStream.reset();
                inputStream.mark((int) (j - this.f188l));
                d(this.f188l, this.f187b);
            }
            this.f189m = j;
        } catch (IOException e5) {
            a3.b.k(e5, "Unable to mark: ");
        }
    }

    @Override // java.io.InputStream, java.io.Closeable, java.lang.AutoCloseable
    public final void close() throws IOException {
        this.f186a.close();
    }

    public final void d(long j, long j10) throws IOException {
        while (j < j10) {
            long jSkip = this.f186a.skip(j10 - j);
            if (jSkip == 0) {
                if (read() == -1) {
                    return;
                } else {
                    jSkip = 1;
                }
            }
            j += jSkip;
        }
    }

    @Override // java.io.InputStream
    public final void mark(int i) {
        long j = this.f187b + ((long) i);
        if (this.f189m < j) {
            c(j);
        }
        this.f190n = this.f187b;
    }

    @Override // java.io.InputStream
    public final boolean markSupported() {
        return this.f186a.markSupported();
    }

    @Override // java.io.InputStream
    public final int read(byte[] bArr) throws IOException {
        if (!this.f191o) {
            long j = this.f187b;
            if (((long) bArr.length) + j > this.f189m) {
                c(j + ((long) bArr.length) + ((long) this.f192p));
            }
        }
        int i = this.f186a.read(bArr);
        if (i != -1) {
            this.f187b += (long) i;
        }
        return i;
    }

    @Override // java.io.InputStream
    public final void reset() throws IOException {
        b(this.f190n);
    }

    @Override // java.io.InputStream
    public final long skip(long j) throws IOException {
        if (!this.f191o) {
            long j10 = this.f187b + j;
            if (j10 > this.f189m) {
                c(j10 + ((long) this.f192p));
            }
        }
        long jSkip = this.f186a.skip(j);
        this.f187b += jSkip;
        return jSkip;
    }

    @Override // java.io.InputStream
    public final int read() throws IOException {
        if (!this.f191o) {
            long j = this.f187b + 1;
            long j10 = this.f189m;
            if (j > j10) {
                c(j10 + ((long) this.f192p));
            }
        }
        int i = this.f186a.read();
        if (i != -1) {
            this.f187b++;
        }
        return i;
    }

    @Override // java.io.InputStream
    public final int read(byte[] bArr, int i, int i10) throws IOException {
        if (!this.f191o) {
            long j = this.f187b + ((long) i10);
            if (j > this.f189m) {
                c(j + ((long) this.f192p));
            }
        }
        int i11 = this.f186a.read(bArr, i, i10);
        if (i11 != -1) {
            this.f187b += (long) i11;
        }
        return i11;
    }
}
