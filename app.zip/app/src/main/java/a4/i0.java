package a4;

import java.util.concurrent.FutureTask;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public final class i0 extends FutureTask implements Comparable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final h f125a;

    public i0(h hVar) {
        super(hVar, null);
        this.f125a = hVar;
    }

    @Override // java.lang.Comparable
    public final int compareTo(Object obj) {
        h hVar = this.f125a;
        int i = hVar.A;
        h hVar2 = ((i0) obj).f125a;
        int i10 = hVar2.A;
        return i == i10 ? hVar.f104a - hVar2.f104a : c.i.c(i10) - c.i.c(i);
    }
}
