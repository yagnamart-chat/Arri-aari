package a4;

import android.content.Context;
import android.content.ContextWrapper;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.StatFs;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.appcompat.widget.SwitchCompat;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import c3.i1;
import com.uptodown.R;
import com.uptodown.core.activities.InstallerActivity;
import j$.util.DesugarCollections;
import java.io.File;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.Executor;
import java.util.concurrent.PriorityBlockingQueue;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public final class d0 implements e3.b, s1.b, ViewBinding, t.b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f84a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public Object f85b;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public Object f86l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public Object f87m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public Object f88n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public Object f89o;

    public d0(s1.a aVar, s1.b bVar) {
        this.f84a = 7;
        HashSet hashSet = new HashSet();
        HashSet hashSet2 = new HashSet();
        HashSet hashSet3 = new HashSet();
        HashSet hashSet4 = new HashSet();
        HashSet hashSet5 = new HashSet();
        Set<s1.i> set = aVar.f8757c;
        Set set2 = aVar.g;
        for (s1.i iVar : set) {
            int i = iVar.f8778c;
            int i10 = iVar.f8777b;
            boolean z9 = i == 0;
            s1.q qVar = iVar.f8776a;
            if (z9) {
                if (i10 == 2) {
                    hashSet4.add(qVar);
                } else {
                    hashSet.add(qVar);
                }
            } else if (i == 2) {
                hashSet3.add(qVar);
            } else if (i10 == 2) {
                hashSet5.add(qVar);
            } else {
                hashSet2.add(qVar);
            }
        }
        if (!set2.isEmpty()) {
            hashSet.add(s1.q.a(p2.b.class));
        }
        this.f85b = DesugarCollections.unmodifiableSet(hashSet);
        this.f86l = DesugarCollections.unmodifiableSet(hashSet2);
        this.f87m = DesugarCollections.unmodifiableSet(hashSet3);
        this.f88n = DesugarCollections.unmodifiableSet(hashSet4);
        DesugarCollections.unmodifiableSet(hashSet5);
        this.f89o = bVar;
    }

    public static d0 g(View view) {
        RelativeLayout relativeLayout = (RelativeLayout) view;
        int i = R.id.sc_preference_switch;
        SwitchCompat switchCompat = (SwitchCompat) ViewBindings.findChildViewById(view, R.id.sc_preference_switch);
        if (switchCompat != null) {
            i = R.id.tv_preference_switch_description;
            TextView textView = (TextView) ViewBindings.findChildViewById(view, R.id.tv_preference_switch_description);
            if (textView != null) {
                i = R.id.tv_preference_switch_title;
                TextView textView2 = (TextView) ViewBindings.findChildViewById(view, R.id.tv_preference_switch_title);
                if (textView2 != null) {
                    return new d0(relativeLayout, relativeLayout, switchCompat, textView, textView2, 10);
                }
            }
        }
        com.google.android.material.drawable.a.j("Missing required view with ID: ".concat(view.getResources().getResourceName(i)));
        return null;
    }

    public static d0 i(SharedPreferences sharedPreferences, ScheduledThreadPoolExecutor scheduledThreadPoolExecutor) {
        d0 d0Var = new d0(sharedPreferences, scheduledThreadPoolExecutor);
        synchronized (((ArrayDeque) d0Var.f88n)) {
            try {
                ((ArrayDeque) d0Var.f88n).clear();
                String string = ((SharedPreferences) d0Var.f85b).getString((String) d0Var.f86l, "");
                if (!TextUtils.isEmpty(string) && string.contains((String) d0Var.f87m)) {
                    String[] strArrSplit = string.split((String) d0Var.f87m, -1);
                    if (strArrSplit.length == 0) {
                        Log.e("FirebaseMessaging", "Corrupted queue. Please check the queue contents and item separator provided");
                    }
                    for (String str : strArrSplit) {
                        if (!TextUtils.isEmpty(str)) {
                            ((ArrayDeque) d0Var.f88n).add(str);
                        }
                    }
                    return d0Var;
                }
                return d0Var;
            } finally {
            }
        }
    }

    public static d0 k(LayoutInflater layoutInflater) {
        View viewInflate = layoutInflater.inflate(R.layout.dialog_generic_accept_cancel, (ViewGroup) null, false);
        int i = R.id.cb_dont_show_again;
        CheckBox checkBox = (CheckBox) ViewBindings.findChildViewById(viewInflate, R.id.cb_dont_show_again);
        if (checkBox != null) {
            i = R.id.tv_cancel;
            TextView textView = (TextView) ViewBindings.findChildViewById(viewInflate, R.id.tv_cancel);
            if (textView != null) {
                i = R.id.tv_msg;
                TextView textView2 = (TextView) ViewBindings.findChildViewById(viewInflate, R.id.tv_msg);
                if (textView2 != null) {
                    i = R.id.tv_ok;
                    TextView textView3 = (TextView) ViewBindings.findChildViewById(viewInflate, R.id.tv_ok);
                    if (textView3 != null) {
                        return new d0((LinearLayout) viewInflate, checkBox, textView, textView2, textView3, 8);
                    }
                }
            }
        }
        com.google.android.material.drawable.a.j("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(i)));
        return null;
    }

    public static boolean l(l4.m mVar, int i) {
        int i10;
        return i == -1 || (i10 = mVar.f) == -1 || i10 == i;
    }

    @Override // s1.b
    public Object a(Class cls) {
        if (!((Set) this.f85b).contains(s1.q.a(cls))) {
            n1.i.m(cls, "Attempting to request an undeclared dependency ", ".");
            return null;
        }
        Object objA = ((s1.b) this.f89o).a(cls);
        if (!cls.equals(p2.b.class)) {
            return objA;
        }
        return new s1.r();
    }

    @Override // s1.b
    public s2.b b(s1.q qVar) {
        if (((Set) this.f86l).contains(qVar)) {
            return ((s1.b) this.f89o).b(qVar);
        }
        n1.i.m(qVar, "Attempting to request an undeclared dependency Provider<", ">.");
        return null;
    }

    @Override // s1.b
    public s2.b c(Class cls) {
        return b(s1.q.a(cls));
    }

    @Override // s1.b
    public Set d(s1.q qVar) {
        if (((Set) this.f88n).contains(qVar)) {
            return ((s1.b) this.f89o).d(qVar);
        }
        n1.i.m(qVar, "Attempting to request an undeclared dependency Set<", ">.");
        return null;
    }

    @Override // s1.b
    public Object e(s1.q qVar) {
        if (((Set) this.f85b).contains(qVar)) {
            return ((s1.b) this.f89o).e(qVar);
        }
        n1.i.m(qVar, "Attempting to request an undeclared dependency ", ".");
        return null;
    }

    @Override // s1.b
    public s1.o f(s1.q qVar) {
        if (((Set) this.f87m).contains(qVar)) {
            return ((s1.b) this.f89o).f(qVar);
        }
        n1.i.m(qVar, "Attempting to request an undeclared dependency Deferred<", ">.");
        return null;
    }

    @Override // q6.a
    public Object get() {
        switch (this.f84a) {
            case 1:
                return new c3.t0((n1.g) ((e3.c) this.f85b).f4526b, (t2.d) ((q6.a) this.f86l).get(), (f3.j) ((q6.a) this.f87m).get(), (c3.l) ((e3.d) this.f88n).get(), (x6.h) ((q6.a) this.f89o).get());
            case 2:
            default:
                return new w.a((Executor) ((q6.a) this.f85b).get(), (s.d) ((q6.a) this.f86l).get(), (u4.y) ((u4.y) this.f87m).get(), (y.d) ((q6.a) this.f88n).get(), (z.c) ((q6.a) this.f89o).get());
            case 3:
                return new f3.c((i1) ((q6.a) this.f85b).get(), (t2.d) ((q6.a) this.f86l).get(), (c3.b) ((q6.a) this.f87m).get(), (f3.d) ((q6.a) this.f88n).get(), (f3.n) ((e3.d) this.f89o).get());
        }
    }

    @Override // androidx.viewbinding.ViewBinding
    public View getRoot() {
        switch (this.f84a) {
        }
        return (RelativeLayout) this.f85b;
    }

    public g0 h() {
        long blockCountLong;
        Context context = (Context) this.f85b;
        if (((f0.i) this.f86l) == null) {
            StringBuilder sb = t0.f181a;
            File file = new File(context.getApplicationContext().getCacheDir(), "picasso-cache");
            if (!file.exists()) {
                file.mkdirs();
            }
            try {
                StatFs statFs = new StatFs(file.getAbsolutePath());
                blockCountLong = (statFs.getBlockCountLong() * statFs.getBlockSizeLong()) / 50;
            } catch (IllegalArgumentException unused) {
                blockCountLong = 5242880;
            }
            long jMax = Math.max(Math.min(blockCountLong, 52428800L), 5242880L);
            q8.v vVar = new q8.v();
            vVar.i = new q8.g(file, jMax);
            this.f86l = new f0.i(new q8.w(vVar), 1);
        }
        if (((a3.d) this.f88n) == null) {
            this.f88n = new a3.d(context);
        }
        if (((j0) this.f87m) == null) {
            this.f87m = new j0(3, 3, 0L, TimeUnit.MILLISECONDS, new PriorityBlockingQueue(), new s0());
        }
        if (((f0) this.f89o) == null) {
            this.f89o = f0.f95a;
        }
        o0 o0Var = new o0((a3.d) this.f88n);
        return new g0(context, new q(context, (j0) this.f87m, g0.j, (f0.i) this.f86l, (a3.d) this.f88n, o0Var), (a3.d) this.f88n, (f0) this.f89o, o0Var);
    }

    public s1.o j(Class cls) {
        return f(s1.q.a(cls));
    }

    public String m() {
        String str;
        synchronized (((ArrayDeque) this.f88n)) {
            str = (String) ((ArrayDeque) this.f88n).peek();
        }
        return str;
    }

    public boolean n(Object obj) {
        boolean zRemove;
        synchronized (((ArrayDeque) this.f88n)) {
            zRemove = ((ArrayDeque) this.f88n).remove(obj);
            if (zRemove) {
                ((ScheduledThreadPoolExecutor) this.f89o).execute(new a2.s(this, 18));
            }
        }
        return zRemove;
    }

    public void o(o.a aVar, o.g gVar) {
        r.q qVar = (r.q) this.f89o;
        r.j jVar = (r.j) this.f85b;
        String str = (String) this.f86l;
        o.e eVar = (o.e) this.f88n;
        if (eVar == null) {
            com.google.android.material.drawable.a.j("Null transformer");
            return;
        }
        o.c cVar = (o.c) this.f87m;
        w.a aVar2 = qVar.f8630c;
        r.j jVarA = jVar.a(aVar.f7593b);
        r.h hVar = new r.h();
        hVar.f8603r = new HashMap();
        hVar.f8601p = Long.valueOf(qVar.f8628a.h());
        hVar.f8602q = Long.valueOf(qVar.f8629b.h());
        hVar.f8596b = str;
        hVar.f8600o = new r.l(cVar, (byte[]) eVar.apply(aVar.f7592a));
        hVar.f8598m = null;
        o.b bVar = aVar.f7594c;
        if (bVar != null) {
            hVar.f8599n = bVar.f7595a;
        }
        aVar2.f10761b.execute(new a2.r(aVar2, jVarA, gVar, hVar.b(), 3));
    }

    public Set p(Class cls) {
        return d(s1.q.a(cls));
    }

    public d0(ContextWrapper contextWrapper) {
        long jC;
        String str;
        this.f84a = 2;
        String packageName = contextWrapper.getPackageName();
        packageName.getClass();
        this.f85b = packageName;
        PackageManager packageManager = contextWrapper.getPackageManager();
        packageManager.getClass();
        this.f86l = d5.b.b(packageManager, packageName);
        try {
            PackageManager packageManager2 = contextWrapper.getPackageManager();
            packageManager2.getClass();
            String packageName2 = contextWrapper.getPackageName();
            packageName2.getClass();
            jC = d5.b.c(d5.a.e(packageManager2, packageName2, 0));
        } catch (PackageManager.NameNotFoundException e5) {
            e5.printStackTrace();
            jC = 0;
        }
        this.f87m = String.valueOf(jC);
        try {
            PackageManager packageManager3 = contextWrapper.getPackageManager();
            packageManager3.getClass();
            String packageName3 = contextWrapper.getPackageName();
            packageName3.getClass();
            str = d5.a.e(packageManager3, packageName3, 0).versionName;
        } catch (PackageManager.NameNotFoundException e8) {
            e8.printStackTrace();
            str = null;
        }
        this.f88n = str;
        this.f89o = "117";
    }

    public d0(InstallerActivity installerActivity) {
        this.f84a = 5;
        this.f86l = new ArrayList();
        this.f87m = new ArrayList();
        this.f88n = new ArrayList();
        this.f89o = new ArrayList();
    }

    public d0(e2.d dVar) {
        this.f84a = 4;
        this.f85b = (h6.f) dVar.f4515b;
        this.f86l = (e1.c0) dVar.f4517m;
        this.f87m = (e1.c0) dVar.f4518n;
        this.f88n = (e1.c0) dVar.f4519o;
        this.f89o = (g4.v) dVar.f4521q;
    }

    public /* synthetic */ d0(Object obj, Object obj2, Object obj3, Object obj4, Object obj5, int i) {
        this.f84a = i;
        this.f85b = obj;
        this.f86l = obj2;
        this.f87m = obj3;
        this.f88n = obj4;
        this.f89o = obj5;
    }

    public d0(SharedPreferences sharedPreferences, ScheduledThreadPoolExecutor scheduledThreadPoolExecutor) {
        this.f84a = 14;
        this.f88n = new ArrayDeque();
        this.f85b = sharedPreferences;
        this.f86l = "topic_operation_queue";
        this.f87m = ",";
        this.f89o = scheduledThreadPoolExecutor;
    }

    public d0(Context context) {
        this.f84a = 0;
        if (context != null) {
            this.f85b = context.getApplicationContext();
        } else {
            com.google.android.material.drawable.a.l("Context must not be null.");
            throw null;
        }
    }
}
