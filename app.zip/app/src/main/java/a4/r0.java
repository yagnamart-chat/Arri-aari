package a4;

import android.os.Process;
import java.util.concurrent.locks.ReentrantLock;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public final class r0 extends Thread {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f180a = 0;

    public /* synthetic */ r0(Runnable runnable) {
        super(runnable);
    }

    @Override // java.lang.Thread, java.lang.Runnable
    public final void run() {
        ReentrantLock reentrantLock;
        a9.d dVarI;
        switch (this.f180a) {
            case 0:
                Process.setThreadPriority(10);
                super.run();
                return;
            case 1:
                break;
            default:
                Process.setThreadPriority(19);
                synchronized (this) {
                    while (true) {
                        try {
                            wait();
                        } catch (InterruptedException unused) {
                            return;
                        }
                    }
                }
                break;
        }
        while (true) {
            try {
                reentrantLock = a9.d.h;
                reentrantLock.lock();
                try {
                    dVarI = t0.f.i();
                } catch (Throwable th) {
                    reentrantLock.unlock();
                    throw th;
                }
            } catch (InterruptedException unused2) {
            }
            if (dVarI == a9.d.f240l) {
                a9.d.f240l = null;
                reentrantLock.unlock();
                return;
            } else {
                reentrantLock.unlock();
                if (dVarI != null) {
                    dVarI.j();
                }
            }
        }
    }

    public /* synthetic */ r0(String str) {
        super(str);
    }

    public /* synthetic */ r0(ThreadGroup threadGroup, String str) {
        super(threadGroup, str);
    }
}
