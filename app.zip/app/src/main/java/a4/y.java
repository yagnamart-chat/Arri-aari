package a4;

import android.content.Context;
import android.net.Uri;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public final class y extends k {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final String[] f193d = {"orientation"};

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ int f194c;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ y(Context context, int i) {
        super(context, 0);
        this.f194c = i;
    }

    @Override // a4.k, a4.n0
    public final boolean b(k0 k0Var) {
        switch (this.f194c) {
            case 0:
                Uri uri = (Uri) k0Var.f131b;
                return "content".equals(uri.getScheme()) && "media".equals(uri.getAuthority());
            default:
                return "file".equals(((Uri) k0Var.f131b).getScheme());
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:29:0x0082  */
    /* JADX WARN: Removed duplicated region for block: B:32:0x008c  */
    /* JADX WARN: Removed duplicated region for block: B:35:0x0094  */
    /* JADX WARN: Removed duplicated region for block: B:90:0x0133  */
    @Override // a4.k, a4.n0
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final a4.m0 e(a4.k0 r21, int r22) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 338
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: a4.y.e(a4.k0, int):a4.m0");
    }
}
