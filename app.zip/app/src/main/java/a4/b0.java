package a4;

import android.net.NetworkInfo;
import android.net.Uri;
import java.io.IOException;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public final class b0 extends n0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final f0.i f77a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final o0 f78b;

    public b0(f0.i iVar, o0 o0Var) {
        this.f77a = iVar;
        this.f78b = o0Var;
    }

    @Override // a4.n0
    public final boolean b(k0 k0Var) {
        String scheme = ((Uri) k0Var.f131b).getScheme();
        return "http".equals(scheme) || "https".equals(scheme);
    }

    @Override // a4.n0
    public final int d() {
        return 2;
    }

    @Override // a4.n0
    public final m0 e(k0 k0Var, int i) throws z, a0 {
        q8.i iVar;
        if (i == 0) {
            iVar = null;
        } else if ((i & 4) != 0) {
            iVar = q8.i.f8431n;
        } else {
            q8.h hVar = new q8.h();
            if ((i & 1) != 0) {
                hVar.f8427a = true;
            }
            if ((i & 2) != 0) {
                hVar.f8428b = true;
            }
            iVar = new q8.i(hVar);
        }
        y2.s sVar = new y2.s(9);
        sVar.F(((Uri) k0Var.f131b).toString());
        if (iVar != null) {
            String string = iVar.toString();
            if (string.isEmpty()) {
                ((g4.v) sVar.f11635m).b0("Cache-Control");
            } else {
                sVar.x("Cache-Control", string);
            }
        }
        q8.z zVarO = sVar.o();
        q8.w wVar = (q8.w) this.f77a.f4817b;
        q8.y yVar = new q8.y(wVar, zVarO);
        wVar.f8512o.getClass();
        yVar.f8532l = q8.b.f8385d;
        synchronized (yVar) {
            if (yVar.f8534n) {
                throw new IllegalStateException("Already Executed");
            }
            yVar.f8534n = true;
        }
        yVar.f8531b.f10491b = y8.h.f11778a.i();
        yVar.f8532l.getClass();
        try {
            try {
                wVar.f8507a.e(yVar);
                q8.b0 b0VarA = yVar.a();
                wVar.f8507a.g(yVar);
                q8.d0 d0Var = b0VarA.f8393p;
                int i10 = b0VarA.f8389l;
                if (i10 < 200 || i10 >= 300) {
                    d0Var.close();
                    throw new a0(androidx.lifecycle.l.u(b0VarA.f8389l, "HTTP "));
                }
                int i11 = b0VarA.f8395r == null ? 3 : 2;
                if (i11 == 2 && d0Var.b() == 0) {
                    d0Var.close();
                    throw new z("Received response with 0 content-length header.");
                }
                if (i11 == 3 && d0Var.b() > 0) {
                    o0 o0Var = this.f78b;
                    long jB = d0Var.b();
                    n nVar = o0Var.f152b;
                    nVar.sendMessage(nVar.obtainMessage(4, Long.valueOf(jB)));
                }
                return new m0(d0Var.c(), i11);
            } catch (IOException e5) {
                yVar.f8532l.getClass();
                throw e5;
            }
        } catch (Throwable th) {
            yVar.f8530a.f8507a.g(yVar);
            throw th;
        }
    }

    @Override // a4.n0
    public final boolean f(NetworkInfo networkInfo) {
        return networkInfo == null || networkInfo.isConnected();
    }
}
