package a4;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public final class g implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f96a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ q0 f97b;

    public /* synthetic */ g(q0 q0Var, int i) {
        this.f96a = i;
        this.f97b = q0Var;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.f96a) {
            case 0:
                throw new IllegalStateException("Transformation " + this.f97b.b() + " returned input Bitmap but recycled it.");
            default:
                throw new IllegalStateException("Transformation " + this.f97b.b() + " mutated input Bitmap but failed to recycle the original.");
        }
    }
}
