package a4;

import android.content.Context;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.WeakHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public final class q {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Context f172a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final ExecutorService f173b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final f0.i f174c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final LinkedHashMap f175d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final WeakHashMap f176e;
    public final WeakHashMap f;
    public final LinkedHashSet g;
    public final n h;
    public final Handler i;
    public final a3.d j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final o0 f177k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final ArrayList f178l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final boolean f179m;

    public q(Context context, j0 j0Var, Handler handler, f0.i iVar, a3.d dVar, o0 o0Var) {
        o oVar = new o("Picasso-Dispatcher", 10);
        oVar.start();
        Looper looper = oVar.getLooper();
        StringBuilder sb = t0.f181a;
        int i = 0;
        c0 c0Var = new c0(looper, 1, false);
        c0Var.sendMessageDelayed(c0Var.obtainMessage(), 1000L);
        this.f172a = context;
        this.f173b = j0Var;
        this.f175d = new LinkedHashMap();
        this.f176e = new WeakHashMap();
        this.f = new WeakHashMap();
        this.g = new LinkedHashSet();
        this.h = new n(oVar.getLooper(), this, i);
        this.f174c = iVar;
        this.i = handler;
        this.j = dVar;
        this.f177k = o0Var;
        this.f178l = new ArrayList(4);
        try {
            Settings.Global.getInt(context.getContentResolver(), "airplane_mode_on", 0);
        } catch (NullPointerException | SecurityException unused) {
        }
        this.f179m = context.checkCallingOrSelfPermission("android.permission.ACCESS_NETWORK_STATE") == 0;
        p pVar = new p(this, i);
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("android.intent.action.AIRPLANE_MODE");
        q qVar = (q) pVar.f162b;
        if (qVar.f179m) {
            intentFilter.addAction("android.net.conn.CONNECTIVITY_CHANGE");
        }
        qVar.f172a.registerReceiver(pVar, intentFilter);
    }

    public final void a(h hVar) {
        Future future = hVar.v;
        if (future == null || !future.isCancelled()) {
            Bitmap bitmap = hVar.f115u;
            if (bitmap != null) {
                bitmap.prepareToDraw();
            }
            this.f178l.add(hVar);
            n nVar = this.h;
            if (nVar.hasMessages(7)) {
                return;
            }
            nVar.sendEmptyMessageDelayed(7, 200L);
        }
    }

    public final void b(h hVar) {
        n nVar = this.h;
        nVar.sendMessage(nVar.obtainMessage(4, hVar));
    }

    public final void c(h hVar, boolean z9) {
        hVar.f105b.getClass();
        this.f175d.remove(hVar.f109o);
        a(hVar);
    }

    public final void d(b bVar, boolean z9) {
        b bVar2 = bVar.f76e;
        String str = bVar.f75d;
        if (this.g.contains(bVar2)) {
            this.f.put(bVar.d(), bVar);
            return;
        }
        LinkedHashMap linkedHashMap = this.f175d;
        h hVar = (h) linkedHashMap.get(str);
        if (hVar != null) {
            hVar.f105b.getClass();
            if (hVar.f113s == null) {
                hVar.f113s = bVar;
                return;
            }
            if (hVar.f114t == null) {
                hVar.f114t = new ArrayList(3);
            }
            hVar.f114t.add(bVar);
            int i = bVar.f73b.h;
            if (c.i.c(i) > c.i.c(hVar.A)) {
                hVar.A = i;
                return;
            }
            return;
        }
        ExecutorService executorService = this.f173b;
        boolean zIsShutdown = executorService.isShutdown();
        g0 g0Var = bVar.f72a;
        if (zIsShutdown) {
            return;
        }
        h hVarE = h.e(g0Var, this, this.j, this.f177k, bVar);
        hVarE.v = executorService.submit(hVarE);
        linkedHashMap.put(str, hVarE);
        if (z9) {
            this.f176e.remove(bVar.d());
        }
    }
}
