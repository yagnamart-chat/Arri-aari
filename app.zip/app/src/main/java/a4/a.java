package a4;

import java.lang.ref.ReferenceQueue;
import java.lang.ref.WeakReference;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public final class a extends WeakReference {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final b f71a;

    public a(b bVar, Object obj, ReferenceQueue referenceQueue) {
        super(obj, referenceQueue);
        this.f71a = bVar;
    }
}
