package a4;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.net.Uri;
import com.davemorrissey.labs.subscaleview.SubsamplingScaleImageView;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicInteger;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public final class h implements Runnable {
    public static final Object B = new Object();
    public static final d C = new d(0);
    public static final AtomicInteger D = new AtomicInteger();
    public static final e E = new e();
    public int A;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f104a = D.incrementAndGet();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final g0 f105b;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final q f106l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final a3.d f107m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final o0 f108n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final String f109o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final k0 f110p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public int f111q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final n0 f112r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public b f113s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public ArrayList f114t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public Bitmap f115u;
    public Future v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public int f116w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public Exception f117x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public int f118y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public int f119z;

    public h(g0 g0Var, q qVar, a3.d dVar, o0 o0Var, b bVar, n0 n0Var) {
        this.f105b = g0Var;
        this.f106l = qVar;
        this.f107m = dVar;
        this.f108n = o0Var;
        this.f113s = bVar;
        this.f109o = bVar.f75d;
        k0 k0Var = bVar.f73b;
        this.f110p = k0Var;
        this.A = k0Var.h;
        this.f111q = 0;
        this.f112r = n0Var;
        this.f119z = n0Var.d();
    }

    public static Bitmap a(List list, Bitmap bitmap) {
        int size = list.size();
        int i = 0;
        while (i < size) {
            q0 q0Var = (q0) list.get(i);
            try {
                Bitmap bitmapA = q0Var.a(bitmap);
                if (bitmapA == null) {
                    StringBuilder sbT = x.t("Transformation ");
                    sbT.append(q0Var.b());
                    sbT.append(" returned null after ");
                    sbT.append(i);
                    sbT.append(" previous transformation(s).\n\nTransformation list:\n");
                    Iterator it = list.iterator();
                    while (it.hasNext()) {
                        sbT.append(((q0) it.next()).b());
                        sbT.append('\n');
                    }
                    g0.j.post(new f(sbT, 0));
                    return null;
                }
                if (bitmapA == bitmap && bitmap.isRecycled()) {
                    g0.j.post(new g(q0Var, 0));
                    return null;
                }
                if (bitmapA != bitmap && !bitmap.isRecycled()) {
                    g0.j.post(new g(q0Var, 1));
                    return null;
                }
                i++;
                bitmap = bitmapA;
            } catch (RuntimeException e5) {
                g0.j.post(new m1.a(1, q0Var, e5));
                return null;
            }
        }
        return bitmap;
    }

    public static Bitmap c(a9.g0 g0Var, k0 k0Var) throws IOException {
        g0Var.getClass();
        a9.a0 a0Var = new a9.a0(g0Var);
        boolean z9 = a0Var.d(0L, t0.f182b) && a0Var.d(8L, t0.f183c);
        k0Var.getClass();
        int i = k0Var.f134e;
        int i10 = k0Var.f133d;
        BitmapFactory.Options optionsC = n0.c(k0Var);
        boolean z10 = optionsC != null && optionsC.inJustDecodeBounds;
        if (z9) {
            a9.h hVar = a0Var.f223b;
            hVar.z(g0Var);
            byte[] bArrJ = hVar.j(hVar.f250b);
            if (z10) {
                BitmapFactory.decodeByteArray(bArrJ, 0, bArrJ.length, optionsC);
                n0.a(i10, i, optionsC.outWidth, optionsC.outHeight, optionsC, k0Var);
            }
            return BitmapFactory.decodeByteArray(bArrJ, 0, bArrJ.length, optionsC);
        }
        a9.f fVar = new a9.f(a0Var, 1);
        InputStream inputStream = fVar;
        if (z10) {
            w wVar = new w(fVar);
            wVar.f191o = false;
            long j = wVar.f187b + ((long) 1024);
            if (wVar.f189m < j) {
                wVar.c(j);
            }
            long j10 = wVar.f187b;
            BitmapFactory.decodeStream(wVar, null, optionsC);
            n0.a(i10, i, optionsC.outWidth, optionsC.outHeight, optionsC, k0Var);
            wVar.b(j10);
            wVar.f191o = true;
            inputStream = wVar;
        }
        Bitmap bitmapDecodeStream = BitmapFactory.decodeStream(inputStream, null, optionsC);
        if (bitmapDecodeStream != null) {
            return bitmapDecodeStream;
        }
        com.google.android.material.drawable.a.k("Failed to decode stream.");
        return null;
    }

    public static h e(g0 g0Var, q qVar, a3.d dVar, o0 o0Var, b bVar) {
        k0 k0Var = bVar.f73b;
        List list = g0Var.f100b;
        int size = list.size();
        for (int i = 0; i < size; i++) {
            n0 n0Var = (n0) list.get(i);
            if (n0Var.b(k0Var)) {
                return new h(g0Var, qVar, dVar, o0Var, bVar, n0Var);
            }
        }
        return new h(g0Var, qVar, dVar, o0Var, bVar, E);
    }

    public static Bitmap g(k0 k0Var, Bitmap bitmap, int i) {
        float f;
        float f7;
        float f10;
        float f11;
        float f12;
        float f13;
        float f14;
        float f15;
        int i10;
        int i11;
        int i12;
        int i13;
        int i14;
        int i15;
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        k0Var.getClass();
        int i16 = k0Var.g;
        int i17 = k0Var.f134e;
        int i18 = k0Var.f133d;
        int i19 = i17;
        Matrix matrix = new Matrix();
        int i20 = 0;
        if (k0Var.d() || i != 0) {
            if (i != 0) {
                switch (i) {
                    case 3:
                    case 4:
                        i15 = SubsamplingScaleImageView.ORIENTATION_180;
                        break;
                    case 5:
                    case 6:
                        i15 = 90;
                        break;
                    case 7:
                    case 8:
                        i15 = 270;
                        break;
                    default:
                        i15 = 0;
                        break;
                }
                int i21 = (i == 2 || i == 7 || i == 4 || i == 5) ? -1 : 1;
                if (i15 != 0) {
                    matrix.preRotate(i15);
                    if (i15 == 90 || i15 == 270) {
                        i19 = i18;
                        i18 = i19;
                    }
                }
                if (i21 != 1) {
                    matrix.postScale(i21, 1.0f);
                }
            }
            if (k0Var.f) {
                if (i18 != 0) {
                    f12 = i18;
                    f13 = width;
                } else {
                    f12 = i19;
                    f13 = height;
                }
                float f16 = f12 / f13;
                if (i19 != 0) {
                    f14 = i19;
                    f15 = height;
                } else {
                    f14 = i18;
                    f15 = width;
                }
                float f17 = f14 / f15;
                if (f16 > f17) {
                    int iCeil = (int) Math.ceil((f17 / f16) * height);
                    int i22 = (i16 & 48) == 48 ? 0 : (i16 & 80) == 80 ? height - iCeil : (height - iCeil) / 2;
                    height = iCeil;
                    f17 = i19 / iCeil;
                    i10 = i22;
                } else if (f16 < f17) {
                    int iCeil2 = (int) Math.ceil((f16 / f17) * width);
                    int i23 = (i16 & 3) == 3 ? 0 : (i16 & 5) == 5 ? width - iCeil2 : (width - iCeil2) / 2;
                    width = iCeil2;
                    f16 = i18 / iCeil2;
                    i10 = 0;
                    i20 = i23;
                } else {
                    f16 = f17;
                    i10 = 0;
                }
                matrix.preScale(f16, f17);
                int i24 = height;
                i11 = width;
                i12 = i10;
                i13 = i24;
                i14 = i20;
            } else {
                if ((i18 != 0 || i19 != 0) && (i18 != width || i19 != height)) {
                    if (i18 != 0) {
                        f = i18;
                        f7 = width;
                    } else {
                        f = i19;
                        f7 = height;
                    }
                    float f18 = f / f7;
                    if (i19 != 0) {
                        f10 = i19;
                        f11 = height;
                    } else {
                        f10 = i18;
                        f11 = width;
                    }
                    matrix.preScale(f18, f10 / f11);
                }
                i13 = height;
                i14 = 0;
                i11 = width;
                i12 = 0;
            }
        } else {
            i13 = height;
            i14 = 0;
            i11 = width;
            i12 = 0;
        }
        Bitmap bitmapCreateBitmap = Bitmap.createBitmap(bitmap, i14, i12, i11, i13, matrix, true);
        if (bitmapCreateBitmap == bitmap) {
            return bitmap;
        }
        bitmap.recycle();
        return bitmapCreateBitmap;
    }

    public static void h(k0 k0Var) {
        Uri uri = (Uri) k0Var.f131b;
        String strValueOf = uri != null ? String.valueOf(uri.getPath()) : Integer.toHexString(k0Var.f132c);
        StringBuilder sb = (StringBuilder) C.get();
        sb.ensureCapacity(strValueOf.length() + 8);
        sb.replace(8, sb.length(), strValueOf);
        Thread.currentThread().setName(sb.toString());
    }

    public final boolean b() {
        ArrayList arrayList;
        Future future;
        return this.f113s == null && ((arrayList = this.f114t) == null || arrayList.isEmpty()) && (future = this.v) != null && future.cancel(false);
    }

    public final void d(b bVar) {
        boolean zRemove;
        if (this.f113s == bVar) {
            this.f113s = null;
            zRemove = true;
        } else {
            ArrayList arrayList = this.f114t;
            zRemove = arrayList != null ? arrayList.remove(bVar) : false;
        }
        if (zRemove && bVar.f73b.h == this.A) {
            ArrayList arrayList2 = this.f114t;
            boolean z9 = (arrayList2 == null || arrayList2.isEmpty()) ? false : true;
            b bVar2 = this.f113s;
            if (bVar2 != null || z9) {
                i = bVar2 != null ? bVar2.f73b.h : 1;
                if (z9) {
                    int size = this.f114t.size();
                    for (int i = 0; i < size; i++) {
                        int i10 = ((b) this.f114t.get(i)).f73b.h;
                        if (c.i.c(i10) > c.i.c(i)) {
                            i = i10;
                        }
                    }
                }
            }
            this.A = i;
        }
        this.f105b.getClass();
    }

    public final Bitmap f() throws IOException {
        v vVar = (v) ((u) this.f107m.f67b).get(this.f109o);
        Bitmap bitmapG = vVar != null ? vVar.f184a : null;
        boolean z9 = true;
        if (bitmapG != null) {
            this.f108n.f152b.sendEmptyMessage(0);
            this.f116w = 1;
            this.f105b.getClass();
            return bitmapG;
        }
        int i = this.f119z == 0 ? 4 : this.f111q;
        this.f111q = i;
        m0 m0VarE = this.f112r.e(this.f110p, i);
        if (m0VarE != null) {
            this.f116w = m0VarE.f145a;
            this.f118y = m0VarE.f148d;
            bitmapG = m0VarE.f146b;
            if (bitmapG == null) {
                a9.g0 g0Var = m0VarE.f147c;
                try {
                    bitmapG = c(g0Var, this.f110p);
                } finally {
                    try {
                        g0Var.close();
                    } catch (IOException unused) {
                    }
                }
            }
        }
        if (bitmapG != null) {
            this.f105b.getClass();
            o0 o0Var = this.f108n;
            o0Var.getClass();
            StringBuilder sb = t0.f181a;
            int allocationByteCount = bitmapG.getAllocationByteCount();
            if (allocationByteCount < 0) {
                a3.b.k(bitmapG, "Negative size: ");
                return null;
            }
            n nVar = o0Var.f152b;
            nVar.sendMessage(nVar.obtainMessage(2, allocationByteCount, 0));
            k0 k0Var = this.f110p;
            if (k0Var.d() || ((List) k0Var.i) != null || this.f118y != 0) {
                synchronized (B) {
                    try {
                        if (this.f110p.d() || this.f118y != 0) {
                            bitmapG = g(this.f110p, bitmapG, this.f118y);
                            this.f105b.getClass();
                        }
                        List list = (List) this.f110p.i;
                        if (list == null) {
                            z9 = false;
                        }
                        if (z9) {
                            bitmapG = a(list, bitmapG);
                            this.f105b.getClass();
                        }
                    } catch (Throwable th) {
                        throw th;
                    }
                }
                if (bitmapG != null) {
                    o0 o0Var2 = this.f108n;
                    o0Var2.getClass();
                    int allocationByteCount2 = bitmapG.getAllocationByteCount();
                    if (allocationByteCount2 < 0) {
                        a3.b.k(bitmapG, "Negative size: ");
                        return null;
                    }
                    n nVar2 = o0Var2.f152b;
                    nVar2.sendMessage(nVar2.obtainMessage(3, allocationByteCount2, 0));
                }
            }
        }
        return bitmapG;
    }

    @Override // java.lang.Runnable
    public final void run() {
        q qVar = this.f106l;
        try {
            try {
                try {
                    h(this.f110p);
                    this.f105b.getClass();
                    Bitmap bitmapF = f();
                    this.f115u = bitmapF;
                    if (bitmapF == null) {
                        n nVar = qVar.h;
                        nVar.sendMessage(nVar.obtainMessage(6, this));
                    } else {
                        qVar.b(this);
                    }
                } catch (IOException e5) {
                    this.f117x = e5;
                    n nVar2 = qVar.h;
                    nVar2.sendMessageDelayed(nVar2.obtainMessage(5, this), 500L);
                } catch (OutOfMemoryError e8) {
                    StringWriter stringWriter = new StringWriter();
                    this.f108n.a().a(new PrintWriter(stringWriter));
                    this.f117x = new RuntimeException(stringWriter.toString(), e8);
                    n nVar3 = qVar.h;
                    nVar3.sendMessage(nVar3.obtainMessage(6, this));
                }
            } catch (a0 e10) {
                this.f117x = e10;
                n nVar4 = qVar.h;
                nVar4.sendMessage(nVar4.obtainMessage(6, this));
            } catch (Exception e11) {
                this.f117x = e11;
                n nVar5 = qVar.h;
                nVar5.sendMessage(nVar5.obtainMessage(6, this));
            }
        } finally {
            Thread.currentThread().setName("Picasso-Idle");
        }
    }
}
