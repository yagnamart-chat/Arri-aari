package a4;

import android.graphics.Bitmap;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import java.util.ArrayList;
import java.util.List;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public class c0 extends Handler {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f82a;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public c0(Looper looper, int i) {
        super(looper);
        this.f82a = i;
        switch (i) {
            case 4:
                super(looper);
                Looper.getMainLooper();
                break;
            case 5:
            default:
                Looper.getMainLooper();
                break;
            case 6:
                super(looper);
                Looper.getMainLooper();
                break;
        }
    }

    @Override // android.os.Handler
    public void handleMessage(Message message) {
        switch (this.f82a) {
            case 0:
                int i = message.what;
                if (i == 3) {
                    b bVar = (b) message.obj;
                    bVar.f72a.a(bVar.d());
                    return;
                }
                if (i != 8) {
                    if (i != 13) {
                        throw new AssertionError("Unknown handler message received: " + message.what);
                    }
                    List list = (List) message.obj;
                    int size = list.size();
                    for (int i10 = 0; i10 < size; i10++) {
                        b bVar2 = (b) list.get(i10);
                        g0 g0Var = bVar2.f72a;
                        Bitmap bitmapG = g0Var.g(bVar2.f75d);
                        if (bitmapG != null) {
                            g0Var.b(bitmapG, 1, bVar2, null);
                        } else {
                            g0Var.c(bVar2);
                        }
                    }
                    return;
                }
                List list2 = (List) message.obj;
                int size2 = list2.size();
                for (int i11 = 0; i11 < size2; i11++) {
                    h hVar = (h) list2.get(i11);
                    g0 g0Var2 = hVar.f105b;
                    g0Var2.getClass();
                    b bVar3 = hVar.f113s;
                    ArrayList arrayList = hVar.f114t;
                    boolean z9 = (arrayList == null || arrayList.isEmpty()) ? false : true;
                    if (bVar3 != null || z9) {
                        Object obj = hVar.f110p.f131b;
                        Exception exc = hVar.f117x;
                        Bitmap bitmap = hVar.f115u;
                        int i12 = hVar.f116w;
                        if (bVar3 != null) {
                            g0Var2.b(bitmap, i12, bVar3, exc);
                        }
                        if (z9) {
                            int size3 = arrayList.size();
                            for (int i13 = 0; i13 < size3; i13++) {
                                g0Var2.b(bitmap, i12, (b) arrayList.get(i13), exc);
                            }
                        }
                    }
                }
                return;
            case 1:
                sendMessageDelayed(obtainMessage(), 1000L);
                return;
            default:
                super.handleMessage(message);
                return;
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ c0(Looper looper, Handler.Callback callback, int i) {
        super(looper, callback);
        this.f82a = i;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ c0(Looper looper, int i, boolean z9) {
        super(looper);
        this.f82a = i;
    }
}
