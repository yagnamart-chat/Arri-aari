package a4;

import android.os.Message;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public final class m implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f143a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Message f144b;

    public /* synthetic */ m(Message message, int i) {
        this.f143a = i;
        this.f144b = message;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.f143a) {
            case 0:
                throw new AssertionError("Unknown handler message received: " + this.f144b.what);
            default:
                throw new AssertionError("Unhandled stats message." + this.f144b.what);
        }
    }
}
