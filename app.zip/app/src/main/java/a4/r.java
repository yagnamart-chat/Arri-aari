package a4;

import android.graphics.Bitmap;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public final class r extends b {
    public final Object h;
    public i i;

    public r(g0 g0Var, k0 k0Var, String str, i iVar) {
        super(g0Var, null, k0Var, str);
        this.h = new Object();
        this.i = iVar;
    }

    @Override // a4.b
    public final void a() {
        this.g = true;
        this.i = null;
    }

    @Override // a4.b
    public final void b(Bitmap bitmap, int i) {
        i iVar = this.i;
        if (iVar != null) {
            iVar.onSuccess();
        }
    }

    @Override // a4.b
    public final void c(Exception exc) {
        i iVar = this.i;
        if (iVar != null) {
            iVar.d(exc);
        }
    }

    @Override // a4.b
    public final Object d() {
        return this.h;
    }
}
