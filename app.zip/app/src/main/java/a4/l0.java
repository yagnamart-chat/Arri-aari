package a4;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.Animatable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Looper;
import android.widget.ImageView;
import java.util.ArrayList;
import java.util.WeakHashMap;
import java.util.concurrent.atomic.AtomicInteger;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public final class l0 {
    public static final AtomicInteger f = new AtomicInteger();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final g0 f138a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final k0 f139b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public boolean f140c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f141d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public Drawable f142e;

    public l0(g0 g0Var, Uri uri, int i) {
        this.f138a = g0Var;
        k0 k0Var = new k0();
        k0Var.f131b = uri;
        k0Var.f132c = i;
        this.f139b = k0Var;
    }

    public final k0 a(long j) {
        f.getAndIncrement();
        k0 k0Var = this.f139b;
        boolean z9 = k0Var.f;
        if (z9 && k0Var.f133d == 0 && k0Var.f134e == 0) {
            androidx.window.layout.c.g("Center crop requires calling resize with positive width and height.");
            return null;
        }
        if (k0Var.h == 0) {
            k0Var.h = 2;
        }
        k0 k0Var2 = new k0((Uri) k0Var.f131b, k0Var.f132c, (ArrayList) k0Var.i, k0Var.f133d, k0Var.f134e, z9, k0Var.g, k0Var.h);
        this.f138a.f99a.getClass();
        return k0Var2;
    }

    public final void b(i iVar) {
        long jNanoTime = System.nanoTime();
        if (this.f140c) {
            androidx.window.layout.c.g("Fit cannot be used with fetch.");
            return;
        }
        k0 k0Var = this.f139b;
        if (((Uri) k0Var.f131b) == null && k0Var.f132c == 0) {
            return;
        }
        int i = k0Var.h;
        if (i == 0) {
            if (i != 0) {
                androidx.window.layout.c.g("Priority already set.");
                return;
            }
            k0Var.h = 1;
        }
        k0 k0VarA = a(jNanoTime);
        String strA = t0.a(k0VarA, new StringBuilder());
        g0 g0Var = this.f138a;
        if (g0Var.g(strA) != null) {
            if (iVar != null) {
                iVar.onSuccess();
            }
        } else {
            r rVar = new r(g0Var, k0VarA, strA, iVar);
            n nVar = g0Var.f102d.h;
            nVar.sendMessage(nVar.obtainMessage(1, rVar));
        }
    }

    public final Bitmap c() {
        long jNanoTime = System.nanoTime();
        StringBuilder sb = t0.f181a;
        if (Looper.getMainLooper().getThread() == Thread.currentThread()) {
            androidx.window.layout.c.g("Method call should not happen from the main thread.");
            return null;
        }
        if (this.f140c) {
            androidx.window.layout.c.g("Fit cannot be used with get.");
            return null;
        }
        k0 k0Var = this.f139b;
        Object obj = null;
        if (((Uri) k0Var.f131b) == null && k0Var.f132c == 0) {
            return null;
        }
        k0 k0VarA = a(jNanoTime);
        g0 g0Var = this.f138a;
        return h.e(g0Var, g0Var.f102d, g0Var.f103e, g0Var.f, new s(g0Var, obj, k0VarA, t0.a(k0VarA, new StringBuilder()), 0)).f();
    }

    public final Drawable d() {
        int i = this.f141d;
        return i != 0 ? this.f138a.f101c.getDrawable(i) : this.f142e;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final void e(ImageView imageView, i iVar) {
        long jNanoTime = System.nanoTime();
        StringBuilder sb = t0.f181a;
        if (Looper.getMainLooper().getThread() != Thread.currentThread()) {
            androidx.window.layout.c.g("Method call should happen from the main thread.");
            return;
        }
        if (imageView == null) {
            com.google.android.material.drawable.a.l("Target must not be null.");
            return;
        }
        k0 k0Var = this.f139b;
        Uri uri = (Uri) k0Var.f131b;
        g0 g0Var = this.f138a;
        if (uri == null && k0Var.f132c == 0) {
            g0Var.a(imageView);
            h0.a(imageView, d());
            return;
        }
        if (this.f140c) {
            if (k0Var.f133d != 0 || k0Var.f134e != 0) {
                androidx.window.layout.c.g("Fit cannot be used with resize.");
                return;
            }
            int width = imageView.getWidth();
            int height = imageView.getHeight();
            if (width == 0 || height == 0) {
                h0.a(imageView, d());
                l lVar = new l(this, imageView, iVar);
                WeakHashMap weakHashMap = g0Var.h;
                if (weakHashMap.containsKey(imageView)) {
                    g0Var.a(imageView);
                }
                weakHashMap.put(imageView, lVar);
                return;
            }
            k0Var.e(width, height);
        }
        k0 k0VarA = a(jNanoTime);
        StringBuilder sb2 = t0.f181a;
        String strA = t0.a(k0VarA, sb2);
        sb2.setLength(0);
        Bitmap bitmapG = g0Var.g(strA);
        if (bitmapG == null) {
            h0.a(imageView, d());
            t tVar = new t(g0Var, imageView, k0VarA, strA);
            tVar.h = iVar;
            g0Var.c(tVar);
            return;
        }
        g0Var.a(imageView);
        Context context = g0Var.f101c;
        int i = h0.f120e;
        Drawable drawable = imageView.getDrawable();
        if (drawable instanceof Animatable) {
            ((Animatable) drawable).stop();
        }
        imageView.setImageDrawable(new h0(context, bitmapG, drawable, 1));
        if (iVar != null) {
            iVar.onSuccess();
        }
    }

    public final void f(int i) {
        if (i == 0) {
            com.google.android.material.drawable.a.l("Placeholder image resource invalid.");
        } else if (this.f142e == null) {
            this.f141d = i;
        } else {
            androidx.window.layout.c.g("Placeholder image already set.");
        }
    }

    public final void g(Drawable drawable) {
        if (this.f141d == 0) {
            this.f142e = drawable;
        } else {
            androidx.window.layout.c.g("Placeholder image already set.");
        }
    }

    public final void h(q0 q0Var) {
        q0Var.b();
        k0 k0Var = this.f139b;
        if (((ArrayList) k0Var.i) == null) {
            k0Var.i = new ArrayList(2);
        }
        ((ArrayList) k0Var.i).add(q0Var);
    }
}
