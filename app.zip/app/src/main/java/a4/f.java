package a4;

import android.util.Log;
import com.uptodown.activities.AppDetailActivity;
import e1.c1;
import e1.u4;
import e1.v4;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public final class f implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f93a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Object f94b;

    public f(j0.k kVar, c9.a aVar) {
        this.f93a = 17;
        this.f94b = aVar;
    }

    private final void a() {
        i1.a aVar = (i1.a) this.f94b;
        synchronized (aVar.f5439a) {
            try {
                if (aVar.b()) {
                    Log.e("WakeLock", String.valueOf(aVar.j).concat(" ** IS FORCE-RELEASED ON TIMEOUT **"));
                    aVar.d();
                    if (aVar.b()) {
                        aVar.f5441c = 1;
                        aVar.e();
                    }
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    private final void b() {
        j1.m mVar = (j1.m) this.f94b;
        synchronized (mVar.f6360l) {
            try {
                j1.c cVar = (j1.c) mVar.f6361m;
                if (cVar != null) {
                    cVar.c();
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    private final void c() {
        while (true) {
            long jA = ((q8.m) this.f94b).a(System.nanoTime());
            if (jA == -1) {
                return;
            }
            if (jA > 0) {
                long j = jA / 1000000;
                long j10 = jA - (1000000 * j);
                synchronized (((q8.m) this.f94b)) {
                    try {
                        ((q8.m) this.f94b).wait(j, (int) j10);
                    } catch (InterruptedException unused) {
                    }
                }
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:91:0x0321  */
    @Override // java.lang.Runnable
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void run() {
        /*
            Method dump skipped, instruction units count: 1104
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: a4.f.run():void");
    }

    public /* synthetic */ f(Object obj, int i) {
        this.f93a = i;
        this.f94b = obj;
    }

    public f(c1 c1Var, boolean z9) {
        this.f93a = 5;
        this.f94b = c1Var;
    }

    public f(u4 u4Var, v4 v4Var) {
        this.f93a = 9;
        this.f94b = u4Var;
    }

    public f(AppDetailActivity appDetailActivity, String str, int i) {
        this.f93a = 2;
        this.f94b = appDetailActivity;
    }
}
