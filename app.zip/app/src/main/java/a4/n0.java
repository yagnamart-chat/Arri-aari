package a4;

import android.graphics.BitmapFactory;
import android.net.NetworkInfo;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public abstract class n0 {
    public static void a(int i, int i10, int i11, int i12, BitmapFactory.Options options, k0 k0Var) {
        int iMin;
        double dFloor;
        if (i12 > i10 || i11 > i) {
            if (i10 == 0) {
                dFloor = Math.floor(i11 / i);
            } else if (i == 0) {
                dFloor = Math.floor(i12 / i10);
            } else {
                int iFloor = (int) Math.floor(i12 / i10);
                int iFloor2 = (int) Math.floor(i11 / i);
                k0Var.getClass();
                iMin = Math.min(iFloor, iFloor2);
            }
            iMin = (int) dFloor;
        } else {
            iMin = 1;
        }
        options.inSampleSize = iMin;
        options.inJustDecodeBounds = false;
    }

    public static BitmapFactory.Options c(k0 k0Var) {
        boolean zB = k0Var.b();
        if (!zB) {
            return null;
        }
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = zB;
        options.inInputShareable = false;
        options.inPurgeable = false;
        return options;
    }

    public abstract boolean b(k0 k0Var);

    public int d() {
        return 0;
    }

    public abstract m0 e(k0 k0Var, int i);

    public boolean f(NetworkInfo networkInfo) {
        return false;
    }
}
