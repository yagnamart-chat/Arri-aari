package a4;

import android.net.Uri;
import java.util.List;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public abstract class t0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final StringBuilder f181a = new StringBuilder();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final a9.k f182b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final a9.k f183c;

    static {
        a9.k kVar = a9.k.f259m;
        f182b = a.a.p("RIFF");
        f183c = a.a.p("WEBP");
    }

    public static String a(k0 k0Var, StringBuilder sb) {
        List list = (List) k0Var.i;
        Uri uri = (Uri) k0Var.f131b;
        if (uri != null) {
            String string = uri.toString();
            sb.ensureCapacity(string.length() + 50);
            sb.append(string);
        } else {
            sb.ensureCapacity(50);
            sb.append(k0Var.f132c);
        }
        sb.append('\n');
        if (k0Var.b()) {
            sb.append("resize:");
            sb.append(k0Var.f133d);
            sb.append('x');
            sb.append(k0Var.f134e);
            sb.append('\n');
        }
        if (k0Var.f) {
            sb.append("centerCrop:");
            sb.append(k0Var.g);
            sb.append('\n');
        }
        if (list != null) {
            int size = list.size();
            for (int i = 0; i < size; i++) {
                sb.append(((q0) list.get(i)).b());
                sb.append('\n');
            }
        }
        return sb.toString();
    }
}
