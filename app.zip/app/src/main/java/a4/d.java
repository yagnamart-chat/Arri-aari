package a4;

import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.Random;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public final class d extends ThreadLocal {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f83a;

    @Override // java.lang.ThreadLocal
    public final Object initialValue() {
        switch (this.f83a) {
            case 0:
                return new StringBuilder("Picasso-");
            case 1:
                return Boolean.FALSE;
            case 2:
                return new Random();
            case 3:
                return 0L;
            default:
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss 'GMT'", Locale.US);
                simpleDateFormat.setLenient(false);
                simpleDateFormat.setTimeZone(r8.c.f8743e);
                return simpleDateFormat;
        }
    }
}
