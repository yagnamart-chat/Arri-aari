package a4;

import java.io.PrintWriter;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public final class p0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f163a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int f164b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final long f165c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final long f166d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final long f167e;
    public final long f;
    public final long g;
    public final long h;
    public final long i;
    public final long j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final int f168k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final int f169l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final int f170m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final long f171n;

    public p0(int i, int i10, long j, long j10, long j11, long j12, long j13, long j14, long j15, long j16, int i11, int i12, int i13, long j17) {
        this.f163a = i;
        this.f164b = i10;
        this.f165c = j;
        this.f166d = j10;
        this.f167e = j11;
        this.f = j12;
        this.g = j13;
        this.h = j14;
        this.i = j15;
        this.j = j16;
        this.f168k = i11;
        this.f169l = i12;
        this.f170m = i13;
        this.f171n = j17;
    }

    public final void a(PrintWriter printWriter) {
        printWriter.println("===============BEGIN PICASSO STATS ===============");
        printWriter.println("Memory Cache Stats");
        printWriter.print("  Max Cache Size: ");
        printWriter.println(this.f163a);
        printWriter.print("  Cache Size: ");
        printWriter.println(this.f164b);
        printWriter.print("  Cache % Full: ");
        printWriter.println((int) Math.ceil((r1 / r0) * 100.0f));
        printWriter.print("  Cache Hits: ");
        printWriter.println(this.f165c);
        printWriter.print("  Cache Misses: ");
        printWriter.println(this.f166d);
        printWriter.println("Network Stats");
        printWriter.print("  Download Count: ");
        printWriter.println(this.f168k);
        printWriter.print("  Total Download Size: ");
        printWriter.println(this.f167e);
        printWriter.print("  Average Download Size: ");
        printWriter.println(this.h);
        printWriter.println("Bitmap Stats");
        printWriter.print("  Total Bitmaps Decoded: ");
        printWriter.println(this.f169l);
        printWriter.print("  Total Bitmap Size: ");
        printWriter.println(this.f);
        printWriter.print("  Total Transformed Bitmaps: ");
        printWriter.println(this.f170m);
        printWriter.print("  Total Transformed Bitmap Size: ");
        printWriter.println(this.g);
        printWriter.print("  Average Bitmap Size: ");
        printWriter.println(this.i);
        printWriter.print("  Average Transformed Bitmap Size: ");
        printWriter.println(this.j);
        printWriter.println("===============END PICASSO STATS ===============");
        printWriter.flush();
    }

    public final String toString() {
        return "StatsSnapshot{maxSize=" + this.f163a + ", size=" + this.f164b + ", cacheHits=" + this.f165c + ", cacheMisses=" + this.f166d + ", downloadCount=" + this.f168k + ", totalDownloadSize=" + this.f167e + ", averageDownloadSize=" + this.h + ", totalOriginalBitmapSize=" + this.f + ", totalTransformedBitmapSize=" + this.g + ", averageOriginalBitmapSize=" + this.i + ", averageTransformedBitmapSize=" + this.j + ", originalBitmapCount=" + this.f169l + ", transformedBitmapCount=" + this.f170m + ", timeStamp=" + this.f171n + '}';
    }
}
