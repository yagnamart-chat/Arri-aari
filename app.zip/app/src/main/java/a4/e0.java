package a4;

import android.os.Handler;
import android.os.Message;
import android.os.Process;
import androidx.core.view.accessibility.AccessibilityNodeInfoCompat;
import java.io.IOException;
import java.lang.ref.ReferenceQueue;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public final class e0 extends Thread {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f90a = 0;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Object f91b;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final Object f92l;

    public e0(ReferenceQueue referenceQueue, Handler handler) {
        this.f91b = referenceQueue;
        this.f92l = handler;
        setDaemon(true);
        setName("Picasso-refQueue");
    }

    @Override // java.lang.Thread, java.lang.Runnable
    public final void run() {
        switch (this.f90a) {
            case 0:
                Handler handler = (Handler) this.f92l;
                Process.setThreadPriority(10);
                while (true) {
                    try {
                        a aVar = (a) ((ReferenceQueue) this.f91b).remove(1000L);
                        Message messageObtainMessage = handler.obtainMessage();
                        if (aVar != null) {
                            messageObtainMessage.what = 3;
                            messageObtainMessage.obj = aVar.f71a;
                            handler.sendMessage(messageObtainMessage);
                        } else {
                            messageObtainMessage.recycle();
                        }
                    } catch (InterruptedException unused) {
                        return;
                    } catch (Exception e5) {
                        handler.post(new f(e5, 1));
                        return;
                    }
                }
                break;
            default:
                o4.a aVar2 = (o4.a) this.f91b;
                aVar2.getClass();
                synchronized (aVar2) {
                    try {
                        ((o4.a) this.f91b).getClass();
                        ((o4.a) this.f91b).getClass();
                        n1.b.D("Command 158 is waiting for: 20000");
                        o4.a aVar3 = (o4.a) this.f91b;
                        aVar3.getClass();
                        aVar3.wait(AccessibilityNodeInfoCompat.EXTRA_DATA_TEXT_CHARACTER_LOCATION_ARG_MAX_LENGTH);
                    } catch (InterruptedException e8) {
                        n1.b.D("Exception: " + e8);
                    }
                    o4.a aVar4 = (o4.a) this.f91b;
                    if (!aVar4.g) {
                        aVar4.getClass();
                        n1.b.D("Timeout Exception has occurred for command: 158.");
                        o4.a aVar5 = (o4.a) this.f92l;
                        try {
                            n1.b.D("Request to close all shells!");
                            n1.b.D("Request to close normal shell!");
                            q4.c.d();
                            n1.b.D("Request to close custom shell!");
                            n1.b.D("Terminating all shells.");
                            aVar5.f("Timeout Exception");
                            break;
                        } catch (IOException unused2) {
                        }
                    }
                    break;
                }
                return;
        }
    }

    public e0(o4.a aVar, o4.a aVar2) {
        this.f92l = aVar;
        this.f91b = aVar2;
    }
}
