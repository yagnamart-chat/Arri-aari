package androidx.activity.contextaware;

import android.content.Context;
import h7.l;
import s7.j;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes.dex */
public final class ContextAwareKt$withContextAvailable$2$listener$1 implements OnContextAvailableListener {
    final /* synthetic */ j $co;
    final /* synthetic */ l $onContextAvailable;

    public ContextAwareKt$withContextAvailable$2$listener$1(j jVar, l lVar) {
        this.$co = jVar;
        this.$onContextAvailable = lVar;
    }

    @Override // androidx.activity.contextaware.OnContextAvailableListener
    public void onContextAvailable(Context context) {
        Object jVar;
        context.getClass();
        j jVar2 = this.$co;
        try {
            jVar = this.$onContextAvailable.invoke(context);
        } catch (Throwable th) {
            jVar = new t6.j(th);
        }
        jVar2.resumeWith(jVar);
    }
}
