package androidx.activity;

import androidx.annotation.ColorInt;
import h7.l;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes.dex */
public final class SystemBarStyle {
    public static final Companion Companion = new Companion(null);
    private final int darkScrim;
    private final l detectDarkMode;
    private final int lightScrim;
    private final int nightMode;

    private SystemBarStyle(int i, int i10, int i11, l lVar) {
        this.lightScrim = i;
        this.darkScrim = i10;
        this.nightMode = i11;
        this.detectDarkMode = lVar;
    }

    public static final SystemBarStyle auto(@ColorInt int i, @ColorInt int i10) {
        return Companion.auto(i, i10);
    }

    public static final SystemBarStyle dark(@ColorInt int i) {
        return Companion.dark(i);
    }

    public static final SystemBarStyle light(@ColorInt int i, @ColorInt int i10) {
        return Companion.light(i, i10);
    }

    public final int getDarkScrim$activity_release() {
        return this.darkScrim;
    }

    public final l getDetectDarkMode$activity_release() {
        return this.detectDarkMode;
    }

    public final int getNightMode$activity_release() {
        return this.nightMode;
    }

    public final int getScrim$activity_release(boolean z9) {
        return z9 ? this.darkScrim : this.lightScrim;
    }

    public final int getScrimWithEnforcedContrast$activity_release(boolean z9) {
        if (this.nightMode == 0) {
            return 0;
        }
        return z9 ? this.darkScrim : this.lightScrim;
    }

    /* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
    public static final class Companion {
        public /* synthetic */ Companion(kotlin.jvm.internal.g gVar) {
            this();
        }

        public static /* synthetic */ SystemBarStyle auto$default(Companion companion, int i, int i10, l lVar, int i11, Object obj) {
            if ((i11 & 4) != 0) {
                lVar = SystemBarStyle$Companion$auto$1.INSTANCE;
            }
            return companion.auto(i, i10, lVar);
        }

        public final SystemBarStyle auto(@ColorInt int i, @ColorInt int i10, l lVar) {
            lVar.getClass();
            return new SystemBarStyle(i, i10, 0, lVar, null);
        }

        public final SystemBarStyle dark(@ColorInt int i) {
            return new SystemBarStyle(i, i, 2, SystemBarStyle$Companion$dark$1.INSTANCE, null);
        }

        public final SystemBarStyle light(@ColorInt int i, @ColorInt int i10) {
            return new SystemBarStyle(i, i10, 1, SystemBarStyle$Companion$light$1.INSTANCE, null);
        }

        private Companion() {
        }

        public final SystemBarStyle auto(@ColorInt int i, @ColorInt int i10) {
            return auto$default(this, i, i10, null, 4, null);
        }
    }

    public static final SystemBarStyle auto(@ColorInt int i, @ColorInt int i10, l lVar) {
        return Companion.auto(i, i10, lVar);
    }

    public /* synthetic */ SystemBarStyle(int i, int i10, int i11, l lVar, kotlin.jvm.internal.g gVar) {
        this(i, i10, i11, lVar);
    }
}
