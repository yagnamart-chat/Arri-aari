package androidx.activity;

import android.view.View;
import o7.i;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes.dex */
public final class ViewTreeFullyDrawnReporterOwner {
    public static final FullyDrawnReporterOwner get(View view) {
        view.getClass();
        o7.f fVarJ = i.J(ViewTreeFullyDrawnReporterOwner$findViewTreeFullyDrawnReporterOwner$1.INSTANCE, view);
        ViewTreeFullyDrawnReporterOwner$findViewTreeFullyDrawnReporterOwner$2 viewTreeFullyDrawnReporterOwner$findViewTreeFullyDrawnReporterOwner$2 = ViewTreeFullyDrawnReporterOwner$findViewTreeFullyDrawnReporterOwner$2.INSTANCE;
        viewTreeFullyDrawnReporterOwner$findViewTreeFullyDrawnReporterOwner$2.getClass();
        o7.c cVar = new o7.c(new o7.d(new o7.d(fVarJ, viewTreeFullyDrawnReporterOwner$findViewTreeFullyDrawnReporterOwner$2), new androidx.room.f(27)));
        return (FullyDrawnReporterOwner) (!cVar.hasNext() ? null : cVar.next());
    }

    public static final void set(View view, FullyDrawnReporterOwner fullyDrawnReporterOwner) {
        view.getClass();
        fullyDrawnReporterOwner.getClass();
        view.setTag(R.id.report_drawn, fullyDrawnReporterOwner);
    }
}
