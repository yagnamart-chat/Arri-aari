package androidx.activity.result;

import h7.l;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class a implements ActivityResultCallback {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f376a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ l f377b;

    public /* synthetic */ a(int i, l lVar) {
        this.f376a = i;
        this.f377b = lVar;
    }

    @Override // androidx.activity.result.ActivityResultCallback
    public final void onActivityResult(Object obj) {
        switch (this.f376a) {
            case 0:
                this.f377b.invoke(obj);
                break;
            default:
                this.f377b.invoke(obj);
                break;
        }
    }
}
