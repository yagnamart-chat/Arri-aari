package androidx.activity;

import android.content.res.Resources;
import h7.l;
import kotlin.jvm.internal.m;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes.dex */
public final class SystemBarStyle$Companion$light$1 extends m implements l {
    public static final SystemBarStyle$Companion$light$1 INSTANCE = new SystemBarStyle$Companion$light$1();

    public SystemBarStyle$Companion$light$1() {
        super(1);
    }

    @Override // h7.l
    public final Boolean invoke(Resources resources) {
        resources.getClass();
        return Boolean.FALSE;
    }
}
