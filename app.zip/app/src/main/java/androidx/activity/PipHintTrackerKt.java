package androidx.activity;

import android.app.Activity;
import android.graphics.Rect;
import android.view.View;
import androidx.annotation.RequiresApi;
import t6.x;
import v7.i;
import v7.k0;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes.dex */
public final class PipHintTrackerKt {
    @RequiresApi(26)
    public static final Object trackPipAnimationHintView(final Activity activity, View view, x6.c cVar) {
        Object objCollect = k0.e(new PipHintTrackerKt$trackPipAnimationHintView$flow$1(view, null)).collect(new i() { // from class: androidx.activity.PipHintTrackerKt.trackPipAnimationHintView.2
            @Override // v7.i
            public final Object emit(Rect rect, x6.c cVar2) {
                Api26Impl.INSTANCE.setPipParamsSourceRectHint(activity, rect);
                return x.f9993a;
            }
        }, cVar);
        return objCollect == y6.a.f11755a ? objCollect : x.f9993a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Rect trackPipAnimationHintView$positionInWindow(View view) {
        Rect rect = new Rect();
        view.getGlobalVisibleRect(rect);
        return rect;
    }
}
