package androidx.activity;

import android.view.View;
import o7.i;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes.dex */
public final class ViewTreeOnBackPressedDispatcherOwner {
    public static final OnBackPressedDispatcherOwner get(View view) {
        view.getClass();
        o7.f fVarJ = i.J(ViewTreeOnBackPressedDispatcherOwner$findViewTreeOnBackPressedDispatcherOwner$1.INSTANCE, view);
        ViewTreeOnBackPressedDispatcherOwner$findViewTreeOnBackPressedDispatcherOwner$2 viewTreeOnBackPressedDispatcherOwner$findViewTreeOnBackPressedDispatcherOwner$2 = ViewTreeOnBackPressedDispatcherOwner$findViewTreeOnBackPressedDispatcherOwner$2.INSTANCE;
        viewTreeOnBackPressedDispatcherOwner$findViewTreeOnBackPressedDispatcherOwner$2.getClass();
        o7.c cVar = new o7.c(new o7.d(new o7.d(fVarJ, viewTreeOnBackPressedDispatcherOwner$findViewTreeOnBackPressedDispatcherOwner$2), new androidx.room.f(27)));
        return (OnBackPressedDispatcherOwner) (!cVar.hasNext() ? null : cVar.next());
    }

    public static final void set(View view, OnBackPressedDispatcherOwner onBackPressedDispatcherOwner) {
        view.getClass();
        onBackPressedDispatcherOwner.getClass();
        view.setTag(R.id.view_tree_on_back_pressed_dispatcher_owner, onBackPressedDispatcherOwner);
    }
}
