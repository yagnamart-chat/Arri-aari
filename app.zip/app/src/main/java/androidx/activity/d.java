package androidx.activity;

import androidx.activity.ComponentActivity;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class d implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f370a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f371b;

    public /* synthetic */ d(Object obj, int i) {
        this.f370a = i;
        this.f371b = obj;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.f370a) {
            case 0:
                ((ComponentActivity.ReportFullyDrawnExecutorApi16Impl) this.f371b).lambda$execute$0();
                break;
            case 1:
                ((ComponentActivity) this.f371b).invalidateMenu();
                break;
            case 2:
                ComponentDialog.onBackPressedDispatcher$lambda$1((ComponentDialog) this.f371b);
                break;
            default:
                FullyDrawnReporter.reportRunnable$lambda$2((FullyDrawnReporter) this.f371b);
                break;
        }
    }
}
