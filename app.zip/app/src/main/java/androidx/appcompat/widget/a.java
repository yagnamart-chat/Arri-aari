package androidx.appcompat.widget;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class a implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f386a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Toolbar f387b;

    public /* synthetic */ a(Toolbar toolbar, int i) {
        this.f386a = i;
        this.f387b = toolbar;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.f386a) {
            case 0:
                this.f387b.collapseActionView();
                break;
            default:
                this.f387b.invalidateMenu();
                break;
        }
    }
}
