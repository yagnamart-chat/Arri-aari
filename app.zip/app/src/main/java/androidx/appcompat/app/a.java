package androidx.appcompat.app;

import android.content.Context;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class a implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f380a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Context f381b;

    public /* synthetic */ a(Context context, int i) {
        this.f380a = i;
        this.f381b = context;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.f380a) {
            case 0:
                AppCompatDelegate.lambda$syncRequestedAndStoredLocales$1(this.f381b);
                break;
            default:
                AppCompatDelegate.syncRequestedAndStoredLocales(this.f381b);
                break;
        }
    }
}
