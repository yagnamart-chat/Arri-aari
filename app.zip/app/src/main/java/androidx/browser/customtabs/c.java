package androidx.browser.customtabs;

import android.os.Bundle;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class c implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f398a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ EngagementSignalsCallback f399b;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ int f400l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ Bundle f401m;

    public /* synthetic */ c(EngagementSignalsCallback engagementSignalsCallback, int i, Bundle bundle, int i10) {
        this.f398a = i10;
        this.f399b = engagementSignalsCallback;
        this.f400l = i;
        this.f401m = bundle;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.f398a) {
            case 0:
                this.f399b.onGreatestScrollPercentageIncreased(this.f400l, this.f401m);
                break;
            default:
                this.f399b.onGreatestScrollPercentageIncreased(this.f400l, this.f401m);
                break;
        }
    }
}
