package androidx.browser.customtabs;

import android.os.Bundle;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class b implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f394a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ EngagementSignalsCallback f395b;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ boolean f396l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ Bundle f397m;

    public /* synthetic */ b(EngagementSignalsCallback engagementSignalsCallback, boolean z9, Bundle bundle, int i) {
        this.f394a = i;
        this.f395b = engagementSignalsCallback;
        this.f396l = z9;
        this.f397m = bundle;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.f394a) {
            case 0:
                this.f395b.onSessionEnded(this.f396l, this.f397m);
                break;
            case 1:
                this.f395b.onVerticalScrollEvent(this.f396l, this.f397m);
                break;
            case 2:
                this.f395b.onVerticalScrollEvent(this.f396l, this.f397m);
                break;
            default:
                this.f395b.onSessionEnded(this.f396l, this.f397m);
                break;
        }
    }
}
