package a9;

import java.util.concurrent.locks.ReentrantLock;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public final class m implements g0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final u f266a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public long f267b;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public boolean f268l;

    public m(u uVar, long j) {
        this.f266a = uVar;
        this.f267b = j;
    }

    @Override // a9.g0
    public final i0 a() {
        return i0.f251d;
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public final void close() {
        u uVar = this.f266a;
        if (this.f268l) {
            return;
        }
        this.f268l = true;
        ReentrantLock reentrantLock = uVar.f290m;
        reentrantLock.lock();
        try {
            int i = uVar.f289l - 1;
            uVar.f289l = i;
            if (i == 0) {
                if (uVar.f288b) {
                    synchronized (uVar) {
                        uVar.f291n.close();
                    }
                }
            }
        } finally {
            reentrantLock.unlock();
        }
    }

    @Override // a9.g0
    public final long l(h hVar, long j) {
        long j10;
        long j11;
        int i;
        hVar.getClass();
        if (this.f268l) {
            androidx.window.layout.c.g("closed");
            return 0L;
        }
        u uVar = this.f266a;
        long j12 = this.f267b;
        if (j < 0) {
            a3.b.q(a4.x.h(j, "byteCount < 0: "));
            return 0L;
        }
        long j13 = j + j12;
        long j14 = j12;
        while (true) {
            if (j14 >= j13) {
                j10 = -1;
                break;
            }
            b0 b0VarT = hVar.t(1);
            byte[] bArr = b0VarT.f228a;
            int i10 = b0VarT.f230c;
            j10 = -1;
            int iMin = (int) Math.min(j13 - j14, 8192 - i10);
            synchronized (uVar) {
                bArr.getClass();
                uVar.f291n.seek(j14);
                i = 0;
                while (true) {
                    if (i >= iMin) {
                        break;
                    }
                    int i11 = uVar.f291n.read(bArr, i10, iMin - i);
                    if (i11 != -1) {
                        i += i11;
                    } else if (i == 0) {
                        i = -1;
                    }
                }
            }
            if (i == -1) {
                if (b0VarT.f229b == b0VarT.f230c) {
                    hVar.f249a = b0VarT.a();
                    c0.a(b0VarT);
                }
                if (j12 == j14) {
                    j11 = -1;
                }
            } else {
                b0VarT.f230c += i;
                long j15 = i;
                j14 += j15;
                hVar.f250b += j15;
            }
        }
        j11 = j14 - j12;
        if (j11 != j10) {
            this.f267b += j11;
        }
        return j11;
    }
}
