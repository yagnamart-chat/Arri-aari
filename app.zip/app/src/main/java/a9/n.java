package a9;

import java.util.ArrayList;
import java.util.Map;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public final class n {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final boolean f269a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final boolean f270b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Long f271c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final Long f272d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final Long f273e;
    public final Long f;
    public final Map g = u6.a0.O(u6.u.f10422a);

    public n(boolean z9, boolean z10, Long l6, Long l10, Long l11, Long l12) {
        this.f269a = z9;
        this.f270b = z10;
        this.f271c = l6;
        this.f272d = l10;
        this.f273e = l11;
        this.f = l12;
    }

    public final String toString() {
        ArrayList arrayList = new ArrayList();
        if (this.f269a) {
            arrayList.add("isRegularFile");
        }
        if (this.f270b) {
            arrayList.add("isDirectory");
        }
        Long l6 = this.f271c;
        if (l6 != null) {
            arrayList.add("byteCount=" + l6);
        }
        Long l10 = this.f272d;
        if (l10 != null) {
            arrayList.add("createdAt=" + l10);
        }
        Long l11 = this.f273e;
        if (l11 != null) {
            arrayList.add("lastModifiedAt=" + l11);
        }
        Long l12 = this.f;
        if (l12 != null) {
            arrayList.add("lastAccessedAt=" + l12);
        }
        Map map = this.g;
        if (!map.isEmpty()) {
            arrayList.add("extras=" + map);
        }
        return u6.l.j0(arrayList, ", ", "FileMetadata(", ")", null, 56);
    }
}
