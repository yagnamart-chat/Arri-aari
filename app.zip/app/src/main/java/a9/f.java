package a9;

import java.io.IOException;
import java.io.InputStream;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public final class f extends InputStream {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f244a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ j f245b;

    public /* synthetic */ f(j jVar, int i) {
        this.f244a = i;
        this.f245b = jVar;
    }

    @Override // java.io.InputStream
    public final int available() throws IOException {
        switch (this.f244a) {
            case 0:
                return (int) Math.min(((h) this.f245b).f250b, Integer.MAX_VALUE);
            default:
                a0 a0Var = (a0) this.f245b;
                if (!a0Var.f224l) {
                    return (int) Math.min(a0Var.f223b.f250b, Integer.MAX_VALUE);
                }
                com.google.android.material.drawable.a.k("closed");
                return 0;
        }
    }

    @Override // java.io.InputStream, java.io.Closeable, java.lang.AutoCloseable
    public final void close() {
        switch (this.f244a) {
            case 0:
                break;
            default:
                ((a0) this.f245b).close();
                break;
        }
    }

    @Override // java.io.InputStream
    public final int read() throws IOException {
        switch (this.f244a) {
            case 0:
                h hVar = (h) this.f245b;
                if (hVar.f250b > 0) {
                    return hVar.readByte() & 255;
                }
                return -1;
            default:
                a0 a0Var = (a0) this.f245b;
                h hVar2 = a0Var.f223b;
                if (a0Var.f224l) {
                    com.google.android.material.drawable.a.k("closed");
                    return 0;
                }
                if (hVar2.f250b == 0 && a0Var.f222a.l(hVar2, 8192L) == -1) {
                    return -1;
                }
                return hVar2.readByte() & 255;
        }
    }

    public final String toString() {
        switch (this.f244a) {
            case 0:
                return ((h) this.f245b) + ".inputStream()";
            default:
                return ((a0) this.f245b) + ".inputStream()";
        }
    }

    private final void b() {
    }

    @Override // java.io.InputStream
    public final int read(byte[] bArr, int i, int i10) throws IOException {
        int i11 = this.f244a;
        bArr.getClass();
        switch (i11) {
            case 0:
                return ((h) this.f245b).read(bArr, i, i10);
            default:
                a0 a0Var = (a0) this.f245b;
                h hVar = a0Var.f223b;
                if (!a0Var.f224l) {
                    n1.b.i(bArr.length, i, i10);
                    if (hVar.f250b == 0 && a0Var.f222a.l(hVar, 8192L) == -1) {
                        return -1;
                    }
                    return hVar.read(bArr, i, i10);
                }
                com.google.android.material.drawable.a.k("closed");
                return 0;
        }
    }
}
