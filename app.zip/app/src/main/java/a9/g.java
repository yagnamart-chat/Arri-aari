package a9;

import java.io.IOException;
import java.io.OutputStream;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public final class g extends OutputStream {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f247a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ i f248b;

    public /* synthetic */ g(i iVar, int i) {
        this.f247a = i;
        this.f248b = iVar;
    }

    @Override // java.io.OutputStream, java.io.Closeable, java.lang.AutoCloseable
    public final void close() {
        switch (this.f247a) {
            case 0:
                break;
            default:
                ((z) this.f248b).close();
                break;
        }
    }

    @Override // java.io.OutputStream, java.io.Flushable
    public final void flush() {
        switch (this.f247a) {
            case 0:
                break;
            default:
                z zVar = (z) this.f248b;
                if (!zVar.f297l) {
                    zVar.flush();
                }
                break;
        }
    }

    public final String toString() {
        switch (this.f247a) {
            case 0:
                return ((h) this.f248b) + ".outputStream()";
            default:
                return ((z) this.f248b) + ".outputStream()";
        }
    }

    @Override // java.io.OutputStream
    public final void write(byte[] bArr, int i, int i10) throws IOException {
        int i11 = this.f247a;
        bArr.getClass();
        switch (i11) {
            case 0:
                ((h) this.f248b).write(bArr, i, i10);
                break;
            default:
                z zVar = (z) this.f248b;
                if (!zVar.f297l) {
                    zVar.f296b.write(bArr, i, i10);
                    zVar.b();
                } else {
                    com.google.android.material.drawable.a.k("closed");
                }
                break;
        }
    }

    private final void b() {
    }

    private final void c() {
    }

    @Override // java.io.OutputStream
    public final void write(int i) throws IOException {
        switch (this.f247a) {
            case 0:
                ((h) this.f248b).A(i);
                break;
            default:
                z zVar = (z) this.f248b;
                if (!zVar.f297l) {
                    zVar.f296b.A((byte) i);
                    zVar.b();
                } else {
                    com.google.android.material.drawable.a.k("closed");
                }
                break;
        }
    }
}
