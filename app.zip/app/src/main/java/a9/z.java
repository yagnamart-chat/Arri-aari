package a9;

import java.io.OutputStream;
import java.nio.ByteBuffer;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public final class z implements i {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final e0 f295a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final h f296b;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public boolean f297l;

    public z(e0 e0Var) {
        e0Var.getClass();
        this.f295a = e0Var;
        this.f296b = new h();
    }

    @Override // a9.e0
    public final i0 a() {
        return this.f295a.a();
    }

    public final i b() {
        if (this.f297l) {
            androidx.window.layout.c.g("closed");
            return null;
        }
        h hVar = this.f296b;
        long j = hVar.f250b;
        if (j == 0) {
            j = 0;
        } else {
            b0 b0Var = hVar.f249a;
            b0Var.getClass();
            b0 b0Var2 = b0Var.g;
            b0Var2.getClass();
            int i = b0Var2.f230c;
            if (i < 8192 && b0Var2.f232e) {
                j -= (long) (i - b0Var2.f229b);
            }
        }
        if (j > 0) {
            this.f295a.i(hVar, j);
        }
        return this;
    }

    public final i c(long j) {
        if (this.f297l) {
            androidx.window.layout.c.g("closed");
            return null;
        }
        this.f296b.B(j);
        b();
        return this;
    }

    @Override // a9.e0, java.io.Closeable, java.lang.AutoCloseable
    public final void close() {
        e0 e0Var = this.f295a;
        if (this.f297l) {
            return;
        }
        try {
            h hVar = this.f296b;
            long j = hVar.f250b;
            if (j > 0) {
                e0Var.i(hVar, j);
            }
            th = null;
        } catch (Throwable th) {
            th = th;
        }
        try {
            e0Var.close();
        } catch (Throwable th2) {
            if (th == null) {
                th = th2;
            }
        }
        this.f297l = true;
        if (th != null) {
            throw th;
        }
    }

    @Override // a9.i, a9.e0, java.io.Flushable
    public final void flush() {
        if (this.f297l) {
            androidx.window.layout.c.g("closed");
            return;
        }
        h hVar = this.f296b;
        long j = hVar.f250b;
        e0 e0Var = this.f295a;
        if (j > 0) {
            e0Var.i(hVar, j);
        }
        e0Var.flush();
    }

    @Override // a9.e0
    public final void i(h hVar, long j) {
        hVar.getClass();
        if (this.f297l) {
            androidx.window.layout.c.g("closed");
        } else {
            this.f296b.i(hVar, j);
            b();
        }
    }

    @Override // java.nio.channels.Channel
    public final boolean isOpen() {
        return !this.f297l;
    }

    @Override // a9.i
    public final i m(String str) {
        str.getClass();
        if (this.f297l) {
            androidx.window.layout.c.g("closed");
            return null;
        }
        this.f296b.G(str);
        b();
        return this;
    }

    @Override // a9.i
    public final i p(long j) {
        if (this.f297l) {
            androidx.window.layout.c.g("closed");
            return null;
        }
        this.f296b.C(j);
        b();
        return this;
    }

    public final String toString() {
        return "buffer(" + this.f295a + ')';
    }

    @Override // a9.i
    public final OutputStream v() {
        return new g(this, 1);
    }

    @Override // java.nio.channels.WritableByteChannel
    public final int write(ByteBuffer byteBuffer) {
        byteBuffer.getClass();
        if (this.f297l) {
            androidx.window.layout.c.g("closed");
            return 0;
        }
        int iWrite = this.f296b.write(byteBuffer);
        b();
        return iWrite;
    }

    @Override // a9.i
    public final i writeByte(int i) {
        if (this.f297l) {
            androidx.window.layout.c.g("closed");
            return null;
        }
        this.f296b.A(i);
        b();
        return this;
    }

    @Override // a9.i
    public final i writeInt(int i) {
        if (this.f297l) {
            androidx.window.layout.c.g("closed");
            return null;
        }
        this.f296b.D(i);
        b();
        return this;
    }

    @Override // a9.i
    public final i writeShort(int i) {
        if (this.f297l) {
            androidx.window.layout.c.g("closed");
            return null;
        }
        this.f296b.E(i);
        b();
        return this;
    }

    @Override // a9.i
    public final i write(byte[] bArr) {
        if (!this.f297l) {
            this.f296b.write(bArr, 0, bArr.length);
            b();
            return this;
        }
        androidx.window.layout.c.g("closed");
        return null;
    }
}
