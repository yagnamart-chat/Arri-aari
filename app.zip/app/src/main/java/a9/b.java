package a9;

import java.io.IOException;
import java.io.OutputStream;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public final class b implements e0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f225a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Object f226b;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final Object f227l;

    public /* synthetic */ b(int i, Object obj, Object obj2) {
        this.f225a = i;
        this.f226b = obj;
        this.f227l = obj2;
    }

    @Override // a9.e0
    public final i0 a() {
        switch (this.f225a) {
            case 0:
                return (f0) this.f226b;
            default:
                return (i0) this.f227l;
        }
    }

    @Override // a9.e0, java.io.Closeable, java.lang.AutoCloseable
    public final void close() throws IOException {
        switch (this.f225a) {
            case 0:
                f0 f0Var = (f0) this.f226b;
                b bVar = (b) this.f227l;
                f0Var.h();
                try {
                    bVar.close();
                    if (f0Var.i()) {
                        throw f0Var.k(null);
                    }
                    return;
                } catch (IOException e5) {
                    if (!f0Var.i()) {
                        throw e5;
                    }
                    throw f0Var.k(e5);
                } finally {
                    f0Var.i();
                }
            default:
                ((OutputStream) this.f226b).close();
                return;
        }
    }

    @Override // a9.e0, java.io.Flushable
    public final void flush() throws IOException {
        switch (this.f225a) {
            case 0:
                f0 f0Var = (f0) this.f226b;
                b bVar = (b) this.f227l;
                f0Var.h();
                try {
                    bVar.flush();
                    if (f0Var.i()) {
                        throw f0Var.k(null);
                    }
                    return;
                } catch (IOException e5) {
                    if (!f0Var.i()) {
                        throw e5;
                    }
                    throw f0Var.k(e5);
                } finally {
                    f0Var.i();
                }
            default:
                ((OutputStream) this.f226b).flush();
                return;
        }
    }

    @Override // a9.e0
    public final void i(h hVar, long j) throws IOException {
        switch (this.f225a) {
            case 0:
                n1.b.i(hVar.f250b, 0L, j);
                long j10 = j;
                while (true) {
                    long j11 = 0;
                    if (j10 <= 0) {
                        return;
                    }
                    b0 b0Var = hVar.f249a;
                    b0Var.getClass();
                    while (true) {
                        if (j11 < 65536) {
                            j11 += (long) (b0Var.f230c - b0Var.f229b);
                            if (j11 >= j10) {
                                j11 = j10;
                            } else {
                                b0Var = b0Var.f;
                                b0Var.getClass();
                            }
                        }
                    }
                    f0 f0Var = (f0) this.f226b;
                    b bVar = (b) this.f227l;
                    f0Var.h();
                    try {
                        try {
                            bVar.i(hVar, j11);
                            if (f0Var.i()) {
                                throw f0Var.k(null);
                            }
                            j10 -= j11;
                        } catch (IOException e5) {
                            if (!f0Var.i()) {
                                throw e5;
                            }
                            throw f0Var.k(e5);
                        }
                    } catch (Throwable th) {
                        f0Var.i();
                        throw th;
                    }
                }
                break;
            default:
                n1.b.i(hVar.f250b, 0L, j);
                while (j > 0) {
                    ((i0) this.f227l).f();
                    b0 b0Var2 = hVar.f249a;
                    b0Var2.getClass();
                    int iMin = (int) Math.min(j, b0Var2.f230c - b0Var2.f229b);
                    ((OutputStream) this.f226b).write(b0Var2.f228a, b0Var2.f229b, iMin);
                    int i = b0Var2.f229b + iMin;
                    b0Var2.f229b = i;
                    long j12 = iMin;
                    j -= j12;
                    hVar.f250b -= j12;
                    if (i == b0Var2.f230c) {
                        hVar.f249a = b0Var2.a();
                        c0.a(b0Var2);
                    }
                }
                return;
        }
    }

    public final String toString() {
        switch (this.f225a) {
            case 0:
                return "AsyncTimeout.sink(" + ((b) this.f227l) + ')';
            default:
                return "sink(" + ((OutputStream) this.f226b) + ')';
        }
    }
}
