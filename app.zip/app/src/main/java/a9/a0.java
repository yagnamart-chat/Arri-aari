package a9;

import androidx.core.location.LocationRequestCompat;
import com.google.android.gms.internal.measurement.j5;
import java.io.EOFException;
import java.io.InputStream;
import java.nio.ByteBuffer;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public final class a0 implements j {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final g0 f222a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final h f223b;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public boolean f224l;

    public a0(g0 g0Var) {
        g0Var.getClass();
        this.f222a = g0Var;
        this.f223b = new h();
    }

    @Override // a9.g0
    public final i0 a() {
        return this.f222a.a();
    }

    public final boolean b() {
        if (this.f224l) {
            androidx.window.layout.c.g("closed");
            return false;
        }
        h hVar = this.f223b;
        return hVar.c() && this.f222a.l(hVar, 8192L) == -1;
    }

    public final long c(byte b10, long j, long j10) {
        if (this.f224l) {
            androidx.window.layout.c.g("closed");
            return 0L;
        }
        if (0 > j10) {
            a3.b.q(a4.x.h(j10, "fromIndex=0 toIndex="));
            return 0L;
        }
        long jMax = 0;
        while (jMax < j10) {
            h hVar = this.f223b;
            byte b11 = b10;
            long j11 = j10;
            long jE = hVar.e(b11, jMax, j11);
            if (jE != -1) {
                return jE;
            }
            long j12 = hVar.f250b;
            if (j12 >= j11 || this.f222a.l(hVar, 8192L) == -1) {
                break;
            }
            jMax = Math.max(jMax, j12);
            b10 = b11;
            j10 = j11;
        }
        return -1L;
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable, java.nio.channels.Channel
    public final void close() {
        if (this.f224l) {
            return;
        }
        this.f224l = true;
        this.f222a.close();
        h hVar = this.f223b;
        hVar.skip(hVar.f250b);
    }

    public final boolean d(long j, k kVar) {
        kVar.getClass();
        int iF = kVar.f();
        if (this.f224l) {
            androidx.window.layout.c.g("closed");
            return false;
        }
        if (j >= 0 && iF >= 0 && kVar.f() >= iF) {
            for (int i = 0; i < iF; i++) {
                long j10 = ((long) i) + j;
                if (o(1 + j10) && this.f223b.d(j10) == kVar.k(i)) {
                }
            }
            return true;
        }
        return false;
    }

    public final void e(byte[] bArr) throws EOFException {
        h hVar = this.f223b;
        int i = 0;
        try {
            u(bArr.length);
            while (i < bArr.length) {
                int i10 = hVar.read(bArr, i, bArr.length - i);
                if (i10 == -1) {
                    a3.b.e();
                    return;
                }
                i += i10;
            }
        } catch (EOFException e5) {
            while (true) {
                long j = hVar.f250b;
                if (j <= 0) {
                    throw e5;
                }
                int i11 = hVar.read(bArr, i, (int) j);
                if (i11 == -1) {
                    throw new AssertionError();
                }
                i += i11;
            }
        }
    }

    @Override // a9.j
    public final k f(long j) {
        u(j);
        return this.f223b.f(j);
    }

    public final int g() {
        u(4L);
        int i = this.f223b.readInt();
        return ((i & 255) << 24) | (((-16777216) & i) >>> 24) | ((16711680 & i) >>> 8) | ((65280 & i) << 8);
    }

    public final long h() throws EOFException {
        char c10;
        char c11;
        char c12;
        char c13;
        long j;
        u(8L);
        h hVar = this.f223b;
        if (hVar.f250b < 8) {
            a3.b.e();
            return 0L;
        }
        b0 b0Var = hVar.f249a;
        b0Var.getClass();
        int i = b0Var.f229b;
        int i10 = b0Var.f230c;
        if (i10 - i < 8) {
            j = ((((long) hVar.readInt()) & 4294967295L) << 32) | (4294967295L & ((long) hVar.readInt()));
            c12 = '8';
            c13 = '\b';
            c10 = 24;
            c11 = '(';
        } else {
            byte[] bArr = b0Var.f228a;
            c10 = 24;
            c11 = '(';
            c12 = '8';
            c13 = '\b';
            int i11 = i + 7;
            long j10 = ((((long) bArr[i]) & 255) << 56) | ((((long) bArr[i + 1]) & 255) << 48) | ((((long) bArr[i + 2]) & 255) << 40) | ((((long) bArr[i + 3]) & 255) << 32) | ((((long) bArr[i + 4]) & 255) << 24) | ((((long) bArr[i + 5]) & 255) << 16) | ((((long) bArr[i + 6]) & 255) << 8);
            int i12 = i + 8;
            long j11 = j10 | (((long) bArr[i11]) & 255);
            hVar.f250b -= 8;
            if (i12 == i10) {
                hVar.f249a = b0Var.a();
                c0.a(b0Var);
            } else {
                b0Var.f229b = i12;
            }
            j = j11;
        }
        return ((j & 255) << c12) | (((-72057594037927936L) & j) >>> c12) | ((71776119061217280L & j) >>> c11) | ((280375465082880L & j) >>> c10) | ((1095216660480L & j) >>> c13) | ((4278190080L & j) << c13) | ((16711680 & j) << c10) | ((65280 & j) << c11);
    }

    @Override // java.nio.channels.Channel
    public final boolean isOpen() {
        return !this.f224l;
    }

    public final short j() {
        u(2L);
        return this.f223b.o();
    }

    @Override // a9.j
    public final String k(long j) {
        if (j < 0) {
            a3.b.q(a4.x.h(j, "limit < 0: "));
            return null;
        }
        long j10 = j == LocationRequestCompat.PASSIVE_INTERVAL ? Long.MAX_VALUE : j + 1;
        long jC = c((byte) 10, 0L, j10);
        h hVar = this.f223b;
        if (jC != -1) {
            return b9.a.a(hVar, jC);
        }
        if (j10 < LocationRequestCompat.PASSIVE_INTERVAL && o(j10) && hVar.d(j10 - 1) == 13 && o(j10 + 1) && hVar.d(j10) == 10) {
            return b9.a.a(hVar, j10);
        }
        h hVar2 = new h();
        hVar.b(hVar2, 0L, Math.min(32, hVar.f250b));
        throw new EOFException("\\n not found: limit=" + Math.min(hVar.f250b, j) + " content=" + hVar2.f(hVar2.f250b).g() + (char) 8230);
    }

    @Override // a9.g0
    public final long l(h hVar, long j) {
        hVar.getClass();
        if (j < 0) {
            a3.b.q(a4.x.h(j, "byteCount < 0: "));
            return 0L;
        }
        if (this.f224l) {
            androidx.window.layout.c.g("closed");
            return 0L;
        }
        h hVar2 = this.f223b;
        if (hVar2.f250b == 0 && this.f222a.l(hVar2, 8192L) == -1) {
            return -1L;
        }
        return hVar2.l(hVar, Math.min(j, hVar2.f250b));
    }

    public final String n(long j) {
        u(j);
        return this.f223b.q(j, p7.a.f7743a);
    }

    public final boolean o(long j) {
        h hVar;
        if (j < 0) {
            a3.b.q(a4.x.h(j, "byteCount < 0: "));
            return false;
        }
        if (this.f224l) {
            androidx.window.layout.c.g("closed");
            return false;
        }
        do {
            hVar = this.f223b;
            if (hVar.f250b >= j) {
                return true;
            }
        } while (this.f222a.l(hVar, 8192L) != -1);
        return false;
    }

    @Override // java.nio.channels.ReadableByteChannel
    public final int read(ByteBuffer byteBuffer) {
        byteBuffer.getClass();
        h hVar = this.f223b;
        if (hVar.f250b == 0 && this.f222a.l(hVar, 8192L) == -1) {
            return -1;
        }
        return hVar.read(byteBuffer);
    }

    @Override // a9.j
    public final byte readByte() {
        u(1L);
        return this.f223b.readByte();
    }

    @Override // a9.j
    public final int readInt() {
        u(4L);
        return this.f223b.readInt();
    }

    @Override // a9.j
    public final short readShort() {
        u(2L);
        return this.f223b.readShort();
    }

    @Override // a9.j
    public final String s() {
        return k(LocationRequestCompat.PASSIVE_INTERVAL);
    }

    @Override // a9.j
    public final void skip(long j) {
        if (this.f224l) {
            androidx.window.layout.c.g("closed");
            return;
        }
        while (j > 0) {
            h hVar = this.f223b;
            if (hVar.f250b == 0 && this.f222a.l(hVar, 8192L) == -1) {
                a3.b.e();
                return;
            } else {
                long jMin = Math.min(j, hVar.f250b);
                hVar.skip(jMin);
                j -= jMin;
            }
        }
    }

    public final String toString() {
        return "buffer(" + this.f222a + ')';
    }

    @Override // a9.j
    public final void u(long j) {
        if (o(j)) {
            return;
        }
        a3.b.e();
    }

    @Override // a9.j
    public final long w() {
        h hVar;
        byte bD;
        u(1L);
        int i = 0;
        while (true) {
            int i10 = i + 1;
            boolean zO = o(i10);
            hVar = this.f223b;
            if (!zO) {
                break;
            }
            bD = hVar.d(i);
            if ((bD < 48 || bD > 57) && ((bD < 97 || bD > 102) && (bD < 65 || bD > 70))) {
                break;
            }
            i = i10;
        }
        if (i == 0) {
            j5.o(16);
            j5.o(16);
            String string = Integer.toString(bD, 16);
            string.getClass();
            throw new NumberFormatException("Expected leading [0-9a-fA-F] character but was 0x".concat(string));
        }
        return hVar.w();
    }

    @Override // a9.j
    public final InputStream x() {
        return new f(this, 1);
    }
}
