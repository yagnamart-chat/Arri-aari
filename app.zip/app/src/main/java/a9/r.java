package a9;

import java.io.InterruptedIOException;
import java.util.concurrent.TimeUnit;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public final class r extends i0 {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public i0 f277e;

    public r(i0 i0Var) {
        i0Var.getClass();
        this.f277e = i0Var;
    }

    @Override // a9.i0
    public final i0 a() {
        return this.f277e.a();
    }

    @Override // a9.i0
    public final i0 b() {
        return this.f277e.b();
    }

    @Override // a9.i0
    public final long c() {
        return this.f277e.c();
    }

    @Override // a9.i0
    public final i0 d(long j) {
        return this.f277e.d(j);
    }

    @Override // a9.i0
    public final boolean e() {
        return this.f277e.e();
    }

    @Override // a9.i0
    public final void f() throws InterruptedIOException {
        this.f277e.f();
    }

    @Override // a9.i0
    public final i0 g(long j) {
        TimeUnit.MILLISECONDS.getClass();
        return this.f277e.g(j);
    }
}
