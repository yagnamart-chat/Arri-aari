package a9;

import java.io.EOFException;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public final class e implements e0 {
    @Override // a9.e0
    public final i0 a() {
        return i0.f251d;
    }

    @Override // a9.e0
    public final void i(h hVar, long j) throws EOFException {
        hVar.skip(j);
    }

    @Override // a9.e0, java.io.Closeable, java.lang.AutoCloseable
    public final void close() {
    }

    @Override // a9.e0, java.io.Flushable
    public final void flush() {
    }
}
