package a9;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public abstract class p implements e0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final e0 f275a;

    public p(e0 e0Var) {
        e0Var.getClass();
        this.f275a = e0Var;
    }

    @Override // a9.e0
    public final i0 a() {
        return this.f275a.a();
    }

    @Override // a9.e0, java.io.Closeable, java.lang.AutoCloseable
    public void close() {
        this.f275a.close();
    }

    @Override // a9.e0, java.io.Flushable
    public void flush() {
        this.f275a.flush();
    }

    @Override // a9.e0
    public void i(h hVar, long j) {
        this.f275a.i(hVar, j);
    }

    public final String toString() {
        return getClass().getSimpleName() + '(' + this.f275a + ')';
    }
}
