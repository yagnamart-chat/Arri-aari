package a9;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.zip.Inflater;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public final class j0 extends o {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final y f255e;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final y f256b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final o f257c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final LinkedHashMap f258d;

    static {
        String str = y.f293b;
        f255e = q2.e.g("/", false);
    }

    public j0(y yVar, o oVar, LinkedHashMap linkedHashMap) {
        oVar.getClass();
        this.f256b = yVar;
        this.f257c = oVar;
        this.f258d = linkedHashMap;
    }

    @Override // a9.o
    public final void a(y yVar, y yVar2) throws IOException {
        yVar2.getClass();
        throw new IOException("zip file systems are read-only");
    }

    @Override // a9.o
    public final void b(y yVar) throws IOException {
        throw new IOException("zip file systems are read-only");
    }

    @Override // a9.o
    public final void c(y yVar) throws IOException {
        throw new IOException("zip file systems are read-only");
    }

    @Override // a9.o
    public final n e(y yVar) throws Throwable {
        a0 a0Var;
        yVar.getClass();
        y yVar2 = f255e;
        yVar2.getClass();
        b9.h hVar = (b9.h) this.f258d.get(b9.c.b(yVar2, yVar, true));
        Throwable th = null;
        if (hVar == null) {
            return null;
        }
        long j = hVar.g;
        boolean z9 = hVar.f1168b;
        n nVar = new n(!z9, z9, z9 ? null : Long.valueOf(hVar.f1170d), null, hVar.f, null);
        if (j == -1) {
            return nVar;
        }
        u uVarF = this.f257c.f(this.f256b);
        try {
            a0Var = new a0(uVarF.c(j));
            try {
                uVarF.close();
            } catch (Throwable th2) {
                th = th2;
            }
        } catch (Throwable th3) {
            if (uVarF != null) {
                try {
                    uVarF.close();
                } catch (Throwable th4) {
                    t6.a.a(th3, th4);
                }
            }
            a0Var = null;
            th = th3;
        }
        if (th != null) {
            throw th;
        }
        a0Var.getClass();
        n nVarF = b9.b.f(a0Var, nVar);
        nVarF.getClass();
        return nVarF;
    }

    @Override // a9.o
    public final u f(y yVar) {
        throw new UnsupportedOperationException("not implemented yet!");
    }

    @Override // a9.o
    public final u g(y yVar) throws IOException {
        throw new IOException("zip entries are not writable");
    }

    @Override // a9.o
    public final g0 h(y yVar) throws Throwable {
        a0 a0Var;
        Throwable th;
        yVar.getClass();
        y yVar2 = f255e;
        yVar2.getClass();
        b9.h hVar = (b9.h) this.f258d.get(b9.c.b(yVar2, yVar, true));
        if (hVar == null) {
            a3.b.v(yVar, "no such file: ");
            return null;
        }
        long j = hVar.f1170d;
        u uVarF = this.f257c.f(this.f256b);
        try {
            a0Var = new a0(uVarF.c(hVar.g));
            try {
                uVarF.close();
                th = null;
            } catch (Throwable th2) {
                th = th2;
            }
        } catch (Throwable th3) {
            if (uVarF != null) {
                try {
                    uVarF.close();
                } catch (Throwable th4) {
                    t6.a.a(th3, th4);
                }
            }
            a0Var = null;
            th = th3;
        }
        if (th != null) {
            throw th;
        }
        a0Var.getClass();
        b9.b.f(a0Var, null);
        if (hVar.f1171e == 0) {
            return new b9.e(a0Var, j, true);
        }
        return new b9.e(new t(new a0(new b9.e(a0Var, hVar.f1169c, true)), new Inflater(true)), j, false);
    }
}
