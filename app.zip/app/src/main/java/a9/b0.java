package a9;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public final class b0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final byte[] f228a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f229b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f230c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f231d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final boolean f232e;
    public b0 f;
    public b0 g;

    public b0(byte[] bArr, int i, int i10, boolean z9) {
        bArr.getClass();
        this.f228a = bArr;
        this.f229b = i;
        this.f230c = i10;
        this.f231d = z9;
        this.f232e = false;
    }

    public final b0 a() {
        b0 b0Var = this.f;
        if (b0Var == this) {
            b0Var = null;
        }
        b0 b0Var2 = this.g;
        b0Var2.getClass();
        b0Var2.f = this.f;
        b0 b0Var3 = this.f;
        b0Var3.getClass();
        b0Var3.g = this.g;
        this.f = null;
        this.g = null;
        return b0Var;
    }

    public final void b(b0 b0Var) {
        b0Var.getClass();
        b0Var.g = this;
        b0Var.f = this.f;
        b0 b0Var2 = this.f;
        b0Var2.getClass();
        b0Var2.g = b0Var;
        this.f = b0Var;
    }

    public final b0 c() {
        this.f231d = true;
        return new b0(this.f228a, this.f229b, this.f230c, true);
    }

    public final void d(b0 b0Var, int i) {
        b0Var.getClass();
        byte[] bArr = b0Var.f228a;
        if (!b0Var.f232e) {
            androidx.window.layout.c.g("only owner can write");
            return;
        }
        int i10 = b0Var.f230c;
        int i11 = i10 + i;
        if (i11 > 8192) {
            if (b0Var.f231d) {
                a3.b.p();
                return;
            }
            int i12 = b0Var.f229b;
            if (i11 - i12 > 8192) {
                a3.b.p();
                return;
            } else {
                u6.j.V(bArr, 0, bArr, i12, i10);
                b0Var.f230c -= b0Var.f229b;
                b0Var.f229b = 0;
            }
        }
        int i13 = b0Var.f230c;
        int i14 = this.f229b;
        u6.j.V(this.f228a, i13, bArr, i14, i14 + i);
        b0Var.f230c += i;
        this.f229b += i;
    }

    public b0() {
        this.f228a = new byte[8192];
        this.f232e = true;
        this.f231d = false;
    }
}
