package a9;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public abstract class o {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final v f274a;

    static {
        v vVar;
        try {
            Class.forName("java.nio.file.Files");
            vVar = new w();
        } catch (ClassNotFoundException unused) {
            vVar = new v();
        }
        f274a = vVar;
        String str = y.f293b;
        String property = System.getProperty("java.io.tmpdir");
        property.getClass();
        q2.e.g(property, false);
        ClassLoader classLoader = b9.g.class.getClassLoader();
        classLoader.getClass();
        new b9.g(classLoader);
    }

    public abstract void a(y yVar, y yVar2);

    public abstract void b(y yVar);

    public abstract void c(y yVar);

    public final boolean d(y yVar) {
        yVar.getClass();
        return e(yVar) != null;
    }

    public abstract n e(y yVar);

    public abstract u f(y yVar);

    public abstract u g(y yVar);

    public abstract g0 h(y yVar);
}
