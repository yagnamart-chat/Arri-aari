package a9;

import a4.r0;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public class d extends i0 {
    public static final ReentrantLock h;
    public static final Condition i;
    public static final long j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public static final long f239k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public static d f240l;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public boolean f241e;
    public d f;
    public long g;

    static {
        ReentrantLock reentrantLock = new ReentrantLock();
        h = reentrantLock;
        Condition conditionNewCondition = reentrantLock.newCondition();
        conditionNewCondition.getClass();
        i = conditionNewCondition;
        j = 60000L;
        f239k = 60000000000L;
    }

    public final void h() {
        d dVar;
        long j10 = this.f254c;
        boolean z9 = this.f252a;
        if (j10 != 0 || z9) {
            ReentrantLock reentrantLock = h;
            reentrantLock.lock();
            try {
                if (this.f241e) {
                    throw new IllegalStateException("Unbalanced enter/exit");
                }
                this.f241e = true;
                if (f240l == null) {
                    f240l = new d();
                    r0 r0Var = new r0("Okio Watchdog");
                    r0Var.setDaemon(true);
                    r0Var.start();
                }
                long jNanoTime = System.nanoTime();
                if (j10 != 0 && z9) {
                    this.g = Math.min(j10, c() - jNanoTime) + jNanoTime;
                } else if (j10 != 0) {
                    this.g = j10 + jNanoTime;
                } else {
                    if (!z9) {
                        throw new AssertionError();
                    }
                    this.g = c();
                }
                long j11 = this.g - jNanoTime;
                d dVar2 = f240l;
                dVar2.getClass();
                while (true) {
                    dVar = dVar2.f;
                    if (dVar == null || j11 < dVar.g - jNanoTime) {
                        break;
                    } else {
                        dVar2 = dVar;
                    }
                }
                this.f = dVar;
                dVar2.f = this;
                if (dVar2 == f240l) {
                    i.signal();
                }
                reentrantLock.unlock();
            } catch (Throwable th) {
                reentrantLock.unlock();
                throw th;
            }
        }
    }

    public final boolean i() {
        ReentrantLock reentrantLock = h;
        reentrantLock.lock();
        try {
            if (!this.f241e) {
                return false;
            }
            this.f241e = false;
            d dVar = f240l;
            while (dVar != null) {
                d dVar2 = dVar.f;
                if (dVar2 == this) {
                    dVar.f = this.f;
                    this.f = null;
                    return false;
                }
                dVar = dVar2;
            }
            reentrantLock.unlock();
            return true;
        } finally {
            reentrantLock.unlock();
        }
    }

    public void j() {
    }
}
