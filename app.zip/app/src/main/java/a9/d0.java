package a9;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public final class d0 extends k {

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final transient byte[][] f242n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final transient int[] f243o;

    public d0(byte[][] bArr, int[] iArr) {
        super(k.f259m.f260a);
        this.f242n = bArr;
        this.f243o = iArr;
    }

    @Override // a9.k
    public final String a() {
        throw null;
    }

    @Override // a9.k
    public final k e(String str) throws NoSuchAlgorithmException {
        MessageDigest messageDigest = MessageDigest.getInstance(str);
        byte[][] bArr = this.f242n;
        int length = bArr.length;
        int i = 0;
        int i10 = 0;
        while (i < length) {
            int[] iArr = this.f243o;
            int i11 = iArr[length + i];
            int i12 = iArr[i];
            messageDigest.update(bArr[i], i11, i12 - i10);
            i++;
            i10 = i12;
        }
        byte[] bArrDigest = messageDigest.digest();
        bArrDigest.getClass();
        return new k(bArrDigest);
    }

    @Override // a9.k
    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj instanceof k) {
            k kVar = (k) obj;
            if (kVar.f() == f() && o(0, kVar, f())) {
                return true;
            }
        }
        return false;
    }

    @Override // a9.k
    public final int f() {
        return this.f243o[this.f242n.length - 1];
    }

    @Override // a9.k
    public final String g() {
        return w().g();
    }

    @Override // a9.k
    public final int h(int i, byte[] bArr) {
        bArr.getClass();
        return w().h(i, bArr);
    }

    @Override // a9.k
    public final int hashCode() {
        int i = this.f261b;
        if (i != 0) {
            return i;
        }
        byte[][] bArr = this.f242n;
        int length = bArr.length;
        int i10 = 0;
        int i11 = 1;
        int i12 = 0;
        while (i10 < length) {
            int[] iArr = this.f243o;
            int i13 = iArr[length + i10];
            int i14 = iArr[i10];
            byte[] bArr2 = bArr[i10];
            int i15 = (i14 - i12) + i13;
            while (i13 < i15) {
                i11 = (i11 * 31) + bArr2[i13];
                i13++;
            }
            i10++;
            i12 = i14;
        }
        this.f261b = i11;
        return i11;
    }

    @Override // a9.k
    public final byte[] j() {
        return v();
    }

    @Override // a9.k
    public final byte k(int i) {
        byte[][] bArr = this.f242n;
        int length = bArr.length - 1;
        int[] iArr = this.f243o;
        n1.b.i(iArr[length], i, 1L);
        int iG = b9.b.g(this, i);
        return bArr[iG][(i - (iG == 0 ? 0 : iArr[iG - 1])) + iArr[bArr.length + iG]];
    }

    @Override // a9.k
    public final int l(byte[] bArr) {
        bArr.getClass();
        return w().l(bArr);
    }

    @Override // a9.k
    public final boolean o(int i, k kVar, int i10) {
        kVar.getClass();
        if (i >= 0 && i <= f() - i10) {
            int i11 = i10 + i;
            int iG = b9.b.g(this, i);
            int i12 = 0;
            while (i < i11) {
                int[] iArr = this.f243o;
                int i13 = iG == 0 ? 0 : iArr[iG - 1];
                int i14 = iArr[iG] - i13;
                byte[][] bArr = this.f242n;
                int i15 = iArr[bArr.length + iG];
                int iMin = Math.min(i11, i14 + i13) - i;
                if (kVar.p(i12, bArr[iG], (i - i13) + i15, iMin)) {
                    i12 += iMin;
                    i += iMin;
                    iG++;
                }
            }
            return true;
        }
        return false;
    }

    @Override // a9.k
    public final boolean p(int i, byte[] bArr, int i10, int i11) {
        bArr.getClass();
        if (i < 0 || i > f() - i11 || i10 < 0 || i10 > bArr.length - i11) {
            return false;
        }
        int i12 = i11 + i;
        int iG = b9.b.g(this, i);
        while (i < i12) {
            int[] iArr = this.f243o;
            int i13 = iG == 0 ? 0 : iArr[iG - 1];
            int i14 = iArr[iG] - i13;
            byte[][] bArr2 = this.f242n;
            int i15 = iArr[bArr2.length + iG];
            int iMin = Math.min(i12, i14 + i13) - i;
            if (!n1.b.d(bArr2[iG], (i - i13) + i15, bArr, i10, iMin)) {
                return false;
            }
            i10 += iMin;
            i += iMin;
            iG++;
        }
        return true;
    }

    @Override // a9.k
    public final k q(int i, int i10) {
        if (i10 == -1234567890) {
            i10 = f();
        }
        if (i < 0) {
            a3.b.q(a4.x.g(i, "beginIndex=", " < 0"));
            return null;
        }
        if (i10 > f()) {
            StringBuilder sbP = a4.x.p(i10, "endIndex=", " > length(");
            sbP.append(f());
            sbP.append(')');
            throw new IllegalArgumentException(sbP.toString().toString());
        }
        int i11 = i10 - i;
        if (i11 < 0) {
            a3.b.g(i10, i, " < beginIndex=", "endIndex=");
            return null;
        }
        if (i == 0 && i10 == f()) {
            return this;
        }
        if (i == i10) {
            return k.f259m;
        }
        int iG = b9.b.g(this, i);
        int iG2 = b9.b.g(this, i10 - 1);
        byte[][] bArr = this.f242n;
        byte[][] bArr2 = (byte[][]) u6.j.a0(bArr, iG, iG2 + 1);
        int[] iArr = new int[bArr2.length * 2];
        int[] iArr2 = this.f243o;
        if (iG <= iG2) {
            int i12 = iG;
            int i13 = 0;
            while (true) {
                iArr[i13] = Math.min(iArr2[i12] - i, i11);
                int i14 = i13 + 1;
                iArr[i13 + bArr2.length] = iArr2[bArr.length + i12];
                if (i12 == iG2) {
                    break;
                }
                i12++;
                i13 = i14;
            }
        }
        int i15 = iG != 0 ? iArr2[iG - 1] : 0;
        int length = bArr2.length;
        iArr[length] = (i - i15) + iArr[length];
        return new d0(bArr2, iArr);
    }

    @Override // a9.k
    public final k s() {
        return w().s();
    }

    @Override // a9.k
    public final String toString() {
        return w().toString();
    }

    @Override // a9.k
    public final void u(h hVar, int i) {
        int iG = b9.b.g(this, 0);
        int i10 = 0;
        while (i10 < i) {
            int[] iArr = this.f243o;
            int i11 = iG == 0 ? 0 : iArr[iG - 1];
            int i12 = iArr[iG] - i11;
            byte[][] bArr = this.f242n;
            int i13 = iArr[bArr.length + iG];
            int iMin = Math.min(i, i12 + i11) - i10;
            int i14 = (i10 - i11) + i13;
            b0 b0Var = new b0(bArr[iG], i14, i14 + iMin, true);
            b0 b0Var2 = hVar.f249a;
            if (b0Var2 == null) {
                b0Var.g = b0Var;
                b0Var.f = b0Var;
                hVar.f249a = b0Var;
            } else {
                b0 b0Var3 = b0Var2.g;
                b0Var3.getClass();
                b0Var3.b(b0Var);
            }
            i10 += iMin;
            iG++;
        }
        hVar.f250b += (long) i;
    }

    public final byte[] v() {
        byte[] bArr = new byte[f()];
        byte[][] bArr2 = this.f242n;
        int length = bArr2.length;
        int i = 0;
        int i10 = 0;
        int i11 = 0;
        while (i < length) {
            int[] iArr = this.f243o;
            int i12 = iArr[length + i];
            int i13 = iArr[i];
            int i14 = i13 - i10;
            u6.j.V(bArr2[i], i11, bArr, i12, i12 + i14);
            i11 += i14;
            i++;
            i10 = i13;
        }
        return bArr;
    }

    public final k w() {
        return new k(v());
    }
}
