package a9;

import b2.t1;
import java.io.IOException;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.util.logging.Level;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public final class f0 extends d {

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final Socket f246m;

    public f0(Socket socket) {
        socket.getClass();
        this.f246m = socket;
    }

    @Override // a9.d
    public final void j() {
        Socket socket = this.f246m;
        try {
            socket.close();
        } catch (AssertionError e5) {
            if (!t1.J(e5)) {
                throw e5;
            }
            x.f292a.log(Level.WARNING, "Failed to close timed out socket " + socket, (Throwable) e5);
        } catch (Exception e8) {
            x.f292a.log(Level.WARNING, "Failed to close timed out socket " + socket, (Throwable) e8);
        }
    }

    public final IOException k(IOException iOException) {
        SocketTimeoutException socketTimeoutException = new SocketTimeoutException("timeout");
        if (iOException != null) {
            socketTimeoutException.initCause(iOException);
        }
        return socketTimeoutException;
    }
}
