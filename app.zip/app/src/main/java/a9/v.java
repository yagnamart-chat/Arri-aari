package a9;

import b2.t1;
import java.io.File;
import java.io.IOException;
import java.io.InterruptedIOException;
import java.io.RandomAccessFile;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public class v extends o {
    @Override // a9.o
    public void a(y yVar, y yVar2) throws IOException {
        yVar2.getClass();
        if (yVar.toFile().renameTo(yVar2.toFile())) {
            return;
        }
        throw new IOException("failed to move " + yVar + " to " + yVar2);
    }

    @Override // a9.o
    public final void b(y yVar) throws IOException {
        if (yVar.toFile().mkdir()) {
            return;
        }
        n nVarE = e(yVar);
        if (nVarE == null || !nVarE.f270b) {
            a3.b.r(yVar, "failed to create directory: ");
        }
    }

    @Override // a9.o
    public final void c(y yVar) throws IOException {
        if (Thread.interrupted()) {
            throw new InterruptedIOException("interrupted");
        }
        File file = yVar.toFile();
        if (file.delete() || !file.exists()) {
            return;
        }
        a3.b.r(yVar, "failed to delete ");
    }

    @Override // a9.o
    public n e(y yVar) {
        yVar.getClass();
        File file = yVar.toFile();
        boolean zIsFile = file.isFile();
        boolean zIsDirectory = file.isDirectory();
        long jLastModified = file.lastModified();
        long length = file.length();
        if (zIsFile || zIsDirectory || jLastModified != 0 || length != 0 || file.exists()) {
            return new n(zIsFile, zIsDirectory, Long.valueOf(length), null, Long.valueOf(jLastModified), null);
        }
        return null;
    }

    @Override // a9.o
    public final u f(y yVar) {
        return new u(false, new RandomAccessFile(yVar.toFile(), "r"));
    }

    @Override // a9.o
    public final u g(y yVar) {
        return new u(true, new RandomAccessFile(yVar.toFile(), "rw"));
    }

    @Override // a9.o
    public final g0 h(y yVar) {
        yVar.getClass();
        return t1.g0(yVar.toFile());
    }

    public String toString() {
        return "JvmSystemFileSystem";
    }
}
