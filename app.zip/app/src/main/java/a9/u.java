package a9;

import java.io.Closeable;
import java.io.RandomAccessFile;
import java.util.concurrent.locks.ReentrantLock;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public final class u implements Closeable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final boolean f287a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public boolean f288b;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public int f289l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final ReentrantLock f290m = new ReentrantLock();

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final RandomAccessFile f291n;

    public u(boolean z9, RandomAccessFile randomAccessFile) {
        this.f287a = z9;
        this.f291n = randomAccessFile;
    }

    public static l b(u uVar) {
        if (!uVar.f287a) {
            androidx.window.layout.c.g("file handle is read-only");
            return null;
        }
        ReentrantLock reentrantLock = uVar.f290m;
        reentrantLock.lock();
        try {
            if (uVar.f288b) {
                throw new IllegalStateException("closed");
            }
            uVar.f289l++;
            reentrantLock.unlock();
            return new l(uVar);
        } catch (Throwable th) {
            reentrantLock.unlock();
            throw th;
        }
    }

    public final m c(long j) {
        ReentrantLock reentrantLock = this.f290m;
        reentrantLock.lock();
        try {
            if (this.f288b) {
                throw new IllegalStateException("closed");
            }
            this.f289l++;
            reentrantLock.unlock();
            return new m(this, j);
        } catch (Throwable th) {
            reentrantLock.unlock();
            throw th;
        }
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public final void close() {
        ReentrantLock reentrantLock = this.f290m;
        reentrantLock.lock();
        try {
            if (this.f288b) {
                return;
            }
            this.f288b = true;
            if (this.f289l != 0) {
                return;
            }
            synchronized (this) {
                this.f291n.close();
            }
        } finally {
            reentrantLock.unlock();
        }
    }

    public final void flush() {
        if (!this.f287a) {
            androidx.window.layout.c.g("file handle is read-only");
            return;
        }
        ReentrantLock reentrantLock = this.f290m;
        reentrantLock.lock();
        try {
            if (this.f288b) {
                throw new IllegalStateException("closed");
            }
            synchronized (this) {
                this.f291n.getFD().sync();
            }
        } finally {
            reentrantLock.unlock();
        }
    }

    public final long size() {
        long length;
        ReentrantLock reentrantLock = this.f290m;
        reentrantLock.lock();
        try {
            if (this.f288b) {
                throw new IllegalStateException("closed");
            }
            synchronized (this) {
                length = this.f291n.length();
            }
            return length;
        } finally {
            reentrantLock.unlock();
        }
    }
}
