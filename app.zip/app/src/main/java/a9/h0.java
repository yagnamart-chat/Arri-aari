package a9;

import java.util.concurrent.TimeUnit;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public final class h0 extends i0 {
    @Override // a9.i0
    public final i0 g(long j) {
        TimeUnit.MILLISECONDS.getClass();
        return this;
    }

    @Override // a9.i0
    public final void f() {
    }

    @Override // a9.i0
    public final i0 d(long j) {
        return this;
    }
}
