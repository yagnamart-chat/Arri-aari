package a9;

import java.io.InterruptedIOException;
import java.util.concurrent.TimeUnit;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public class i0 {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final h0 f251d = new h0();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public boolean f252a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public long f253b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public long f254c;

    public i0 a() {
        this.f252a = false;
        return this;
    }

    public i0 b() {
        this.f254c = 0L;
        return this;
    }

    public long c() {
        if (this.f252a) {
            return this.f253b;
        }
        androidx.window.layout.c.g("No deadline");
        return 0L;
    }

    public i0 d(long j) {
        this.f252a = true;
        this.f253b = j;
        return this;
    }

    public boolean e() {
        return this.f252a;
    }

    public void f() throws InterruptedIOException {
        if (Thread.currentThread().isInterrupted()) {
            throw new InterruptedIOException("interrupted");
        }
        if (this.f252a && this.f253b - System.nanoTime() <= 0) {
            throw new InterruptedIOException("deadline reached");
        }
    }

    public i0 g(long j) {
        TimeUnit timeUnit = TimeUnit.MILLISECONDS;
        timeUnit.getClass();
        if (j >= 0) {
            this.f254c = timeUnit.toNanos(j);
            return this;
        }
        a3.b.q(a4.x.h(j, "timeout < 0: "));
        return null;
    }
}
