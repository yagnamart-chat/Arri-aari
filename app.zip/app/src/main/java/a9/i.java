package a9;

import java.io.OutputStream;
import java.nio.channels.WritableByteChannel;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public interface i extends e0, WritableByteChannel {
    @Override // a9.e0, java.io.Flushable
    void flush();

    i m(String str);

    i p(long j);

    OutputStream v();

    i write(byte[] bArr);

    i writeByte(int i);

    i writeInt(int i);

    i writeShort(int i);
}
