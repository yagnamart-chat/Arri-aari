package a9;

import androidx.core.location.LocationRequestCompat;
import androidx.work.WorkRequest;
import java.io.EOFException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.channels.ByteChannel;
import java.nio.charset.Charset;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public final class h implements j, i, Cloneable, ByteChannel {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public b0 f249a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public long f250b;

    public final void A(int i) {
        b0 b0VarT = t(1);
        byte[] bArr = b0VarT.f228a;
        int i10 = b0VarT.f230c;
        b0VarT.f230c = i10 + 1;
        bArr[i10] = (byte) i;
        this.f250b++;
    }

    public final void B(long j) {
        boolean z9;
        if (j == 0) {
            A(48);
            return;
        }
        int i = 1;
        if (j < 0) {
            j = -j;
            if (j < 0) {
                G("-9223372036854775808");
                return;
            }
            z9 = true;
        } else {
            z9 = false;
        }
        if (j >= 100000000) {
            i = j < 1000000000000L ? j < 10000000000L ? j < 1000000000 ? 9 : 10 : j < 100000000000L ? 11 : 12 : j < 1000000000000000L ? j < 10000000000000L ? 13 : j < 100000000000000L ? 14 : 15 : j < 100000000000000000L ? j < 10000000000000000L ? 16 : 17 : j < 1000000000000000000L ? 18 : 19;
        } else if (j >= WorkRequest.MIN_BACKOFF_MILLIS) {
            i = j < 1000000 ? j < 100000 ? 5 : 6 : j < 10000000 ? 7 : 8;
        } else if (j >= 100) {
            i = j < 1000 ? 3 : 4;
        } else if (j >= 10) {
            i = 2;
        }
        if (z9) {
            i++;
        }
        b0 b0VarT = t(i);
        byte[] bArr = b0VarT.f228a;
        int i10 = b0VarT.f230c + i;
        while (j != 0) {
            long j10 = 10;
            i10--;
            bArr[i10] = b9.a.f1151a[(int) (j % j10)];
            j /= j10;
        }
        if (z9) {
            bArr[i10 - 1] = 45;
        }
        b0VarT.f230c += i;
        this.f250b += (long) i;
    }

    public final void C(long j) {
        if (j == 0) {
            A(48);
            return;
        }
        long j10 = (j >>> 1) | j;
        long j11 = j10 | (j10 >>> 2);
        long j12 = j11 | (j11 >>> 4);
        long j13 = j12 | (j12 >>> 8);
        long j14 = j13 | (j13 >>> 16);
        long j15 = j14 | (j14 >>> 32);
        long j16 = j15 - ((j15 >>> 1) & 6148914691236517205L);
        long j17 = ((j16 >>> 2) & 3689348814741910323L) + (j16 & 3689348814741910323L);
        long j18 = ((j17 >>> 4) + j17) & 1085102592571150095L;
        long j19 = j18 + (j18 >>> 8);
        long j20 = j19 + (j19 >>> 16);
        int i = (int) ((((j20 & 63) + ((j20 >>> 32) & 63)) + ((long) 3)) / ((long) 4));
        b0 b0VarT = t(i);
        byte[] bArr = b0VarT.f228a;
        int i10 = b0VarT.f230c;
        for (int i11 = (i10 + i) - 1; i11 >= i10; i11--) {
            bArr[i11] = b9.a.f1151a[(int) (15 & j)];
            j >>>= 4;
        }
        b0VarT.f230c += i;
        this.f250b += (long) i;
    }

    public final void D(int i) {
        b0 b0VarT = t(4);
        byte[] bArr = b0VarT.f228a;
        int i10 = b0VarT.f230c;
        bArr[i10] = (byte) ((i >>> 24) & 255);
        bArr[i10 + 1] = (byte) ((i >>> 16) & 255);
        bArr[i10 + 2] = (byte) ((i >>> 8) & 255);
        bArr[i10 + 3] = (byte) (i & 255);
        b0VarT.f230c = i10 + 4;
        this.f250b += 4;
    }

    public final void E(int i) {
        b0 b0VarT = t(2);
        byte[] bArr = b0VarT.f228a;
        int i10 = b0VarT.f230c;
        bArr[i10] = (byte) ((i >>> 8) & 255);
        bArr[i10 + 1] = (byte) (i & 255);
        b0VarT.f230c = i10 + 2;
        this.f250b += 2;
    }

    public final void F(int i, int i10, String str) {
        char cCharAt;
        str.getClass();
        if (i < 0) {
            a3.b.q(androidx.lifecycle.l.u(i, "beginIndex < 0: "));
            return;
        }
        if (i10 < i) {
            a3.b.g(i10, i, " < ", "endIndex < beginIndex: ");
            return;
        }
        if (i10 > str.length()) {
            StringBuilder sbP = a4.x.p(i10, "endIndex > string.length: ", " > ");
            sbP.append(str.length());
            throw new IllegalArgumentException(sbP.toString().toString());
        }
        while (i < i10) {
            char cCharAt2 = str.charAt(i);
            if (cCharAt2 < 128) {
                b0 b0VarT = t(1);
                byte[] bArr = b0VarT.f228a;
                int i11 = b0VarT.f230c - i;
                int iMin = Math.min(i10, 8192 - i11);
                int i12 = i + 1;
                bArr[i + i11] = (byte) cCharAt2;
                while (true) {
                    i = i12;
                    if (i >= iMin || (cCharAt = str.charAt(i)) >= 128) {
                        break;
                    }
                    i12 = i + 1;
                    bArr[i + i11] = (byte) cCharAt;
                }
                int i13 = b0VarT.f230c;
                int i14 = (i11 + i) - i13;
                b0VarT.f230c = i13 + i14;
                this.f250b += (long) i14;
            } else {
                if (cCharAt2 < 2048) {
                    b0 b0VarT2 = t(2);
                    byte[] bArr2 = b0VarT2.f228a;
                    int i15 = b0VarT2.f230c;
                    bArr2[i15] = (byte) ((cCharAt2 >> 6) | 192);
                    bArr2[i15 + 1] = (byte) ((cCharAt2 & '?') | 128);
                    b0VarT2.f230c = i15 + 2;
                    this.f250b += 2;
                } else if (cCharAt2 < 55296 || cCharAt2 > 57343) {
                    b0 b0VarT3 = t(3);
                    byte[] bArr3 = b0VarT3.f228a;
                    int i16 = b0VarT3.f230c;
                    bArr3[i16] = (byte) ((cCharAt2 >> '\f') | 224);
                    bArr3[i16 + 1] = (byte) ((63 & (cCharAt2 >> 6)) | 128);
                    bArr3[i16 + 2] = (byte) ((cCharAt2 & '?') | 128);
                    b0VarT3.f230c = i16 + 3;
                    this.f250b += 3;
                } else {
                    int i17 = i + 1;
                    char cCharAt3 = i17 < i10 ? str.charAt(i17) : (char) 0;
                    if (cCharAt2 > 56319 || 56320 > cCharAt3 || cCharAt3 >= 57344) {
                        A(63);
                        i = i17;
                    } else {
                        int i18 = (((cCharAt2 & 1023) << 10) | (cCharAt3 & 1023)) + 65536;
                        b0 b0VarT4 = t(4);
                        byte[] bArr4 = b0VarT4.f228a;
                        int i19 = b0VarT4.f230c;
                        bArr4[i19] = (byte) ((i18 >> 18) | 240);
                        bArr4[i19 + 1] = (byte) (((i18 >> 12) & 63) | 128);
                        bArr4[i19 + 2] = (byte) (((i18 >> 6) & 63) | 128);
                        bArr4[i19 + 3] = (byte) ((i18 & 63) | 128);
                        b0VarT4.f230c = i19 + 4;
                        this.f250b += 4;
                        i += 2;
                    }
                }
                i++;
            }
        }
    }

    public final void G(String str) {
        str.getClass();
        F(0, str.length(), str);
    }

    public final void H(int i) {
        String str;
        if (i < 128) {
            A(i);
            return;
        }
        if (i < 2048) {
            b0 b0VarT = t(2);
            byte[] bArr = b0VarT.f228a;
            int i10 = b0VarT.f230c;
            bArr[i10] = (byte) ((i >> 6) | 192);
            bArr[i10 + 1] = (byte) ((i & 63) | 128);
            b0VarT.f230c = i10 + 2;
            this.f250b += 2;
            return;
        }
        if (55296 <= i && i < 57344) {
            A(63);
            return;
        }
        if (i < 65536) {
            b0 b0VarT2 = t(3);
            byte[] bArr2 = b0VarT2.f228a;
            int i11 = b0VarT2.f230c;
            bArr2[i11] = (byte) ((i >> 12) | 224);
            bArr2[i11 + 1] = (byte) (((i >> 6) & 63) | 128);
            bArr2[i11 + 2] = (byte) ((i & 63) | 128);
            b0VarT2.f230c = i11 + 3;
            this.f250b += 3;
            return;
        }
        if (i <= 1114111) {
            b0 b0VarT3 = t(4);
            byte[] bArr3 = b0VarT3.f228a;
            int i12 = b0VarT3.f230c;
            bArr3[i12] = (byte) ((i >> 18) | 240);
            bArr3[i12 + 1] = (byte) (((i >> 12) & 63) | 128);
            bArr3[i12 + 2] = (byte) (((i >> 6) & 63) | 128);
            bArr3[i12 + 3] = (byte) ((i & 63) | 128);
            b0VarT3.f230c = i12 + 4;
            this.f250b += 4;
            return;
        }
        StringBuilder sb = new StringBuilder("Unexpected code point: 0x");
        if (i != 0) {
            char[] cArr = b9.b.f1152a;
            char[] cArr2 = {cArr[(i >> 28) & 15], cArr[(i >> 24) & 15], cArr[(i >> 20) & 15], cArr[(i >> 16) & 15], cArr[(i >> 12) & 15], cArr[(i >> 8) & 15], cArr[(i >> 4) & 15], cArr[i & 15]};
            int i13 = 0;
            while (i13 < 8 && cArr2[i13] == '0') {
                i13++;
            }
            u6.e.Companion.getClass();
            u6.b.a(i13, 8, 8);
            str = new String(cArr2, i13, 8 - i13);
        } else {
            str = "0";
        }
        sb.append(str);
        throw new IllegalArgumentException(sb.toString());
    }

    @Override // a9.g0
    public final i0 a() {
        return i0.f251d;
    }

    public final void b(h hVar, long j, long j10) {
        hVar.getClass();
        long j11 = j;
        n1.b.i(this.f250b, j11, j10);
        if (j10 == 0) {
            return;
        }
        hVar.f250b += j10;
        b0 b0Var = this.f249a;
        while (true) {
            b0Var.getClass();
            long j12 = b0Var.f230c - b0Var.f229b;
            if (j11 < j12) {
                break;
            }
            j11 -= j12;
            b0Var = b0Var.f;
        }
        b0 b0Var2 = b0Var;
        long j13 = j10;
        while (j13 > 0) {
            b0Var2.getClass();
            b0 b0VarC = b0Var2.c();
            int i = b0VarC.f229b + ((int) j11);
            b0VarC.f229b = i;
            b0VarC.f230c = Math.min(i + ((int) j13), b0VarC.f230c);
            b0 b0Var3 = hVar.f249a;
            if (b0Var3 == null) {
                b0VarC.g = b0VarC;
                b0VarC.f = b0VarC;
                hVar.f249a = b0VarC;
            } else {
                b0 b0Var4 = b0Var3.g;
                b0Var4.getClass();
                b0Var4.b(b0VarC);
            }
            j13 -= (long) (b0VarC.f230c - b0VarC.f229b);
            b0Var2 = b0Var2.f;
            j11 = 0;
        }
    }

    public final boolean c() {
        return this.f250b == 0;
    }

    public final Object clone() {
        h hVar = new h();
        if (this.f250b == 0) {
            return hVar;
        }
        b0 b0Var = this.f249a;
        b0Var.getClass();
        b0 b0VarC = b0Var.c();
        hVar.f249a = b0VarC;
        b0VarC.g = b0VarC;
        b0VarC.f = b0VarC;
        for (b0 b0Var2 = b0Var.f; b0Var2 != b0Var; b0Var2 = b0Var2.f) {
            b0 b0Var3 = b0VarC.g;
            b0Var3.getClass();
            b0Var2.getClass();
            b0Var3.b(b0Var2.c());
        }
        hVar.f250b = this.f250b;
        return hVar;
    }

    public final byte d(long j) {
        n1.b.i(this.f250b, j, 1L);
        b0 b0Var = this.f249a;
        b0Var.getClass();
        long j10 = this.f250b;
        if (j10 - j < j) {
            while (j10 > j) {
                b0Var = b0Var.g;
                b0Var.getClass();
                j10 -= (long) (b0Var.f230c - b0Var.f229b);
            }
            return b0Var.f228a[(int) ((((long) b0Var.f229b) + j) - j10)];
        }
        long j11 = 0;
        while (true) {
            int i = b0Var.f230c;
            int i10 = b0Var.f229b;
            long j12 = ((long) (i - i10)) + j11;
            if (j12 > j) {
                return b0Var.f228a[(int) ((((long) i10) + j) - j11)];
            }
            b0Var = b0Var.f;
            b0Var.getClass();
            j11 = j12;
        }
    }

    public final long e(byte b10, long j, long j10) {
        b0 b0Var;
        long j11 = 0;
        if (0 > j || j > j10) {
            throw new IllegalArgumentException(("size=" + this.f250b + " fromIndex=" + j + " toIndex=" + j10).toString());
        }
        long j12 = this.f250b;
        if (j10 > j12) {
            j10 = j12;
        }
        if (j == j10 || (b0Var = this.f249a) == null) {
            return -1L;
        }
        if (j12 - j < j) {
            while (j12 > j) {
                b0Var = b0Var.g;
                b0Var.getClass();
                j12 -= (long) (b0Var.f230c - b0Var.f229b);
            }
            while (j12 < j10) {
                byte[] bArr = b0Var.f228a;
                int iMin = (int) Math.min(b0Var.f230c, (((long) b0Var.f229b) + j10) - j12);
                for (int i = (int) ((((long) b0Var.f229b) + j) - j12); i < iMin; i++) {
                    if (bArr[i] == b10) {
                        return ((long) (i - b0Var.f229b)) + j12;
                    }
                }
                j12 += (long) (b0Var.f230c - b0Var.f229b);
                b0Var = b0Var.f;
                b0Var.getClass();
                j = j12;
            }
            return -1L;
        }
        while (true) {
            long j13 = ((long) (b0Var.f230c - b0Var.f229b)) + j11;
            if (j13 > j) {
                break;
            }
            b0Var = b0Var.f;
            b0Var.getClass();
            j11 = j13;
        }
        while (j11 < j10) {
            byte[] bArr2 = b0Var.f228a;
            int iMin2 = (int) Math.min(b0Var.f230c, (((long) b0Var.f229b) + j10) - j11);
            for (int i10 = (int) ((((long) b0Var.f229b) + j) - j11); i10 < iMin2; i10++) {
                if (bArr2[i10] == b10) {
                    return ((long) (i10 - b0Var.f229b)) + j11;
                }
            }
            j11 += (long) (b0Var.f230c - b0Var.f229b);
            b0Var = b0Var.f;
            b0Var.getClass();
            j = j11;
        }
        return -1L;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof h)) {
            return false;
        }
        long j = this.f250b;
        h hVar = (h) obj;
        if (j != hVar.f250b) {
            return false;
        }
        if (j == 0) {
            return true;
        }
        b0 b0Var = this.f249a;
        b0Var.getClass();
        b0 b0Var2 = hVar.f249a;
        b0Var2.getClass();
        int i = b0Var.f229b;
        int i10 = b0Var2.f229b;
        long j10 = 0;
        while (j10 < this.f250b) {
            long jMin = Math.min(b0Var.f230c - i, b0Var2.f230c - i10);
            long j11 = 0;
            while (j11 < jMin) {
                int i11 = i + 1;
                int i12 = i10 + 1;
                if (b0Var.f228a[i] != b0Var2.f228a[i10]) {
                    return false;
                }
                j11++;
                i = i11;
                i10 = i12;
            }
            if (i == b0Var.f230c) {
                b0Var = b0Var.f;
                b0Var.getClass();
                i = b0Var.f229b;
            }
            if (i10 == b0Var2.f230c) {
                b0Var2 = b0Var2.f;
                b0Var2.getClass();
                i10 = b0Var2.f229b;
            }
            j10 += jMin;
        }
        return true;
    }

    @Override // a9.j
    public final k f(long j) throws EOFException {
        if (j < 0 || j > 2147483647L) {
            a3.b.q(a4.x.h(j, "byteCount: "));
            return null;
        }
        if (this.f250b < j) {
            a3.b.e();
            return null;
        }
        if (j < 4096) {
            return new k(j(j));
        }
        k kVarR = r((int) j);
        skip(j);
        return kVarR;
    }

    public final long g(k kVar) {
        int i;
        int i10;
        kVar.getClass();
        b0 b0Var = this.f249a;
        if (b0Var == null) {
            return -1L;
        }
        long j = this.f250b;
        long j10 = 0;
        if (j < 0) {
            while (j > 0) {
                b0Var = b0Var.g;
                b0Var.getClass();
                j -= (long) (b0Var.f230c - b0Var.f229b);
            }
            if (kVar.f() == 2) {
                byte bK = kVar.k(0);
                byte bK2 = kVar.k(1);
                while (j < this.f250b) {
                    byte[] bArr = b0Var.f228a;
                    i = (int) ((((long) b0Var.f229b) + j10) - j);
                    int i11 = b0Var.f230c;
                    while (i < i11) {
                        byte b10 = bArr[i];
                        if (b10 == bK || b10 == bK2) {
                            i10 = b0Var.f229b;
                        } else {
                            i++;
                        }
                    }
                    j10 = ((long) (b0Var.f230c - b0Var.f229b)) + j;
                    b0Var = b0Var.f;
                    b0Var.getClass();
                    j = j10;
                }
                return -1L;
            }
            byte[] bArrJ = kVar.j();
            while (j < this.f250b) {
                byte[] bArr2 = b0Var.f228a;
                i = (int) ((((long) b0Var.f229b) + j10) - j);
                int i12 = b0Var.f230c;
                while (i < i12) {
                    byte b11 = bArr2[i];
                    for (byte b12 : bArrJ) {
                        if (b11 == b12) {
                            i10 = b0Var.f229b;
                        }
                    }
                    i++;
                }
                j10 = ((long) (b0Var.f230c - b0Var.f229b)) + j;
                b0Var = b0Var.f;
                b0Var.getClass();
                j = j10;
            }
            return -1L;
        }
        j = 0;
        while (true) {
            long j11 = ((long) (b0Var.f230c - b0Var.f229b)) + j;
            if (j11 > 0) {
                break;
            }
            b0Var = b0Var.f;
            b0Var.getClass();
            j = j11;
        }
        if (kVar.f() == 2) {
            byte bK3 = kVar.k(0);
            byte bK4 = kVar.k(1);
            while (j < this.f250b) {
                byte[] bArr3 = b0Var.f228a;
                i = (int) ((((long) b0Var.f229b) + j10) - j);
                int i13 = b0Var.f230c;
                while (i < i13) {
                    byte b13 = bArr3[i];
                    if (b13 == bK3 || b13 == bK4) {
                        i10 = b0Var.f229b;
                    } else {
                        i++;
                    }
                }
                j10 = ((long) (b0Var.f230c - b0Var.f229b)) + j;
                b0Var = b0Var.f;
                b0Var.getClass();
                j = j10;
            }
            return -1L;
        }
        byte[] bArrJ2 = kVar.j();
        while (j < this.f250b) {
            byte[] bArr4 = b0Var.f228a;
            i = (int) ((((long) b0Var.f229b) + j10) - j);
            int i14 = b0Var.f230c;
            while (i < i14) {
                byte b14 = bArr4[i];
                for (byte b15 : bArrJ2) {
                    if (b14 == b15) {
                        i10 = b0Var.f229b;
                    }
                }
                i++;
            }
            j10 = ((long) (b0Var.f230c - b0Var.f229b)) + j;
            b0Var = b0Var.f;
            b0Var.getClass();
            j = j10;
        }
        return -1L;
        return ((long) (i - i10)) + j;
    }

    public final boolean h(long j, k kVar) {
        kVar.getClass();
        int iF = kVar.f();
        if (j >= 0 && iF >= 0 && this.f250b - j >= iF && kVar.f() >= iF) {
            for (int i = 0; i < iF; i++) {
                if (d(((long) i) + j) == kVar.k(i)) {
                }
            }
            return true;
        }
        return false;
    }

    public final int hashCode() {
        b0 b0Var = this.f249a;
        if (b0Var == null) {
            return 0;
        }
        int i = 1;
        do {
            int i10 = b0Var.f230c;
            for (int i11 = b0Var.f229b; i11 < i10; i11++) {
                i = (i * 31) + b0Var.f228a[i11];
            }
            b0Var = b0Var.f;
            b0Var.getClass();
        } while (b0Var != this.f249a);
        return i;
    }

    @Override // a9.e0
    public final void i(h hVar, long j) {
        b0 b0VarB;
        hVar.getClass();
        if (hVar == this) {
            com.google.android.material.drawable.a.l("source == this");
            return;
        }
        n1.b.i(hVar.f250b, 0L, j);
        while (j > 0) {
            b0 b0Var = hVar.f249a;
            b0Var.getClass();
            int i = b0Var.f230c;
            b0 b0Var2 = hVar.f249a;
            b0Var2.getClass();
            long j10 = i - b0Var2.f229b;
            int i10 = 0;
            if (j < j10) {
                b0 b0Var3 = this.f249a;
                b0 b0Var4 = b0Var3 != null ? b0Var3.g : null;
                if (b0Var4 != null && b0Var4.f232e) {
                    if ((((long) b0Var4.f230c) + j) - ((long) (b0Var4.f231d ? 0 : b0Var4.f229b)) <= 8192) {
                        b0 b0Var5 = hVar.f249a;
                        b0Var5.getClass();
                        b0Var5.d(b0Var4, (int) j);
                        hVar.f250b -= j;
                        this.f250b += j;
                        return;
                    }
                }
                b0 b0Var6 = hVar.f249a;
                b0Var6.getClass();
                int i11 = (int) j;
                if (i11 <= 0 || i11 > b0Var6.f230c - b0Var6.f229b) {
                    com.google.android.material.drawable.a.l("byteCount out of range");
                    return;
                }
                if (i11 >= 1024) {
                    b0VarB = b0Var6.c();
                } else {
                    b0VarB = c0.b();
                    byte[] bArr = b0Var6.f228a;
                    byte[] bArr2 = b0VarB.f228a;
                    int i12 = b0Var6.f229b;
                    u6.j.V(bArr, 0, bArr2, i12, i12 + i11);
                }
                b0VarB.f230c = b0VarB.f229b + i11;
                b0Var6.f229b += i11;
                b0 b0Var7 = b0Var6.g;
                b0Var7.getClass();
                b0Var7.b(b0VarB);
                hVar.f249a = b0VarB;
            }
            b0 b0Var8 = hVar.f249a;
            b0Var8.getClass();
            long j11 = b0Var8.f230c - b0Var8.f229b;
            hVar.f249a = b0Var8.a();
            b0 b0Var9 = this.f249a;
            if (b0Var9 == null) {
                this.f249a = b0Var8;
                b0Var8.g = b0Var8;
                b0Var8.f = b0Var8;
            } else {
                b0 b0Var10 = b0Var9.g;
                b0Var10.getClass();
                b0Var10.b(b0Var8);
                b0 b0Var11 = b0Var8.g;
                if (b0Var11 == b0Var8) {
                    androidx.window.layout.c.g("cannot compact");
                    return;
                }
                b0Var11.getClass();
                if (b0Var11.f232e) {
                    int i13 = b0Var8.f230c - b0Var8.f229b;
                    b0 b0Var12 = b0Var8.g;
                    b0Var12.getClass();
                    int i14 = 8192 - b0Var12.f230c;
                    b0 b0Var13 = b0Var8.g;
                    b0Var13.getClass();
                    if (!b0Var13.f231d) {
                        b0 b0Var14 = b0Var8.g;
                        b0Var14.getClass();
                        i10 = b0Var14.f229b;
                    }
                    if (i13 <= i14 + i10) {
                        b0 b0Var15 = b0Var8.g;
                        b0Var15.getClass();
                        b0Var8.d(b0Var15, i13);
                        b0Var8.a();
                        c0.a(b0Var8);
                    }
                }
            }
            hVar.f250b -= j11;
            this.f250b += j11;
            j -= j11;
        }
    }

    @Override // java.nio.channels.Channel
    public final boolean isOpen() {
        return true;
    }

    public final byte[] j(long j) throws EOFException {
        if (j < 0 || j > 2147483647L) {
            a3.b.q(a4.x.h(j, "byteCount: "));
            return null;
        }
        if (this.f250b < j) {
            a3.b.e();
            return null;
        }
        int i = (int) j;
        byte[] bArr = new byte[i];
        int i10 = 0;
        while (i10 < i) {
            int i11 = read(bArr, i10, i - i10);
            if (i11 == -1) {
                a3.b.e();
                return null;
            }
            i10 += i11;
        }
        return bArr;
    }

    @Override // a9.j
    public final String k(long j) throws EOFException {
        if (j < 0) {
            a3.b.q(a4.x.h(j, "limit < 0: "));
            return null;
        }
        long j10 = LocationRequestCompat.PASSIVE_INTERVAL;
        if (j != LocationRequestCompat.PASSIVE_INTERVAL) {
            j10 = j + 1;
        }
        long j11 = j10;
        long jE = e((byte) 10, 0L, j11);
        if (jE != -1) {
            return b9.a.a(this, jE);
        }
        if (j11 < this.f250b && d(j11 - 1) == 13 && d(j11) == 10) {
            return b9.a.a(this, j11);
        }
        h hVar = new h();
        b(hVar, 0L, Math.min(32, this.f250b));
        throw new EOFException("\\n not found: limit=" + Math.min(this.f250b, j) + " content=" + hVar.f(hVar.f250b).g() + (char) 8230);
    }

    @Override // a9.g0
    public final long l(h hVar, long j) {
        hVar.getClass();
        if (j < 0) {
            a3.b.q(a4.x.h(j, "byteCount < 0: "));
            return 0L;
        }
        long j10 = this.f250b;
        if (j10 == 0) {
            return -1L;
        }
        if (j > j10) {
            j = j10;
        }
        hVar.i(this, j);
        return j;
    }

    @Override // a9.i
    public final /* bridge */ /* synthetic */ i m(String str) {
        G(str);
        return this;
    }

    /* JADX WARN: Code restructure failed: missing block: B:19:0x0046, code lost:
    
        r2 = new a9.h();
        r2.B(r7);
        r2.A(r1);
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x0051, code lost:
    
        if (r9 != false) goto L22;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x0053, code lost:
    
        r2.readByte();
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x0069, code lost:
    
        throw new java.lang.NumberFormatException("Number too large: ".concat(r2.q(r2.f250b, p7.a.f7743a)));
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final long n() throws java.io.EOFException {
        /*
            Method dump skipped, instruction units count: 251
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: a9.h.n():long");
    }

    public final short o() throws EOFException {
        short s10 = readShort();
        return (short) (((s10 & 255) << 8) | ((65280 & s10) >>> 8));
    }

    @Override // a9.i
    public final /* bridge */ /* synthetic */ i p(long j) {
        C(j);
        return this;
    }

    public final String q(long j, Charset charset) throws EOFException {
        charset.getClass();
        if (j < 0 || j > 2147483647L) {
            a3.b.q(a4.x.h(j, "byteCount: "));
            return null;
        }
        if (this.f250b < j) {
            a3.b.e();
            return null;
        }
        if (j == 0) {
            return "";
        }
        b0 b0Var = this.f249a;
        b0Var.getClass();
        int i = b0Var.f229b;
        if (((long) i) + j > b0Var.f230c) {
            return new String(j(j), charset);
        }
        int i10 = (int) j;
        String str = new String(b0Var.f228a, i, i10, charset);
        int i11 = b0Var.f229b + i10;
        b0Var.f229b = i11;
        this.f250b -= j;
        if (i11 == b0Var.f230c) {
            this.f249a = b0Var.a();
            c0.a(b0Var);
        }
        return str;
    }

    public final k r(int i) {
        if (i == 0) {
            return k.f259m;
        }
        n1.b.i(this.f250b, 0L, i);
        b0 b0Var = this.f249a;
        int i10 = 0;
        int i11 = 0;
        int i12 = 0;
        while (i11 < i) {
            b0Var.getClass();
            int i13 = b0Var.f230c;
            int i14 = b0Var.f229b;
            if (i13 == i14) {
                a3.b.j("s.limit == s.pos");
                return null;
            }
            i11 += i13 - i14;
            i12++;
            b0Var = b0Var.f;
        }
        byte[][] bArr = new byte[i12][];
        int[] iArr = new int[i12 * 2];
        b0 b0Var2 = this.f249a;
        int i15 = 0;
        while (i10 < i) {
            b0Var2.getClass();
            bArr[i15] = b0Var2.f228a;
            i10 += b0Var2.f230c - b0Var2.f229b;
            iArr[i15] = Math.min(i10, i);
            iArr[i15 + i12] = b0Var2.f229b;
            b0Var2.f231d = true;
            i15++;
            b0Var2 = b0Var2.f;
        }
        return new d0(bArr, iArr);
    }

    public final int read(byte[] bArr, int i, int i10) {
        n1.b.i(bArr.length, i, i10);
        b0 b0Var = this.f249a;
        if (b0Var == null) {
            return -1;
        }
        int iMin = Math.min(i10, b0Var.f230c - b0Var.f229b);
        byte[] bArr2 = b0Var.f228a;
        int i11 = b0Var.f229b;
        u6.j.V(bArr2, i, bArr, i11, i11 + iMin);
        int i12 = b0Var.f229b + iMin;
        b0Var.f229b = i12;
        this.f250b -= (long) iMin;
        if (i12 == b0Var.f230c) {
            this.f249a = b0Var.a();
            c0.a(b0Var);
        }
        return iMin;
    }

    @Override // a9.j
    public final byte readByte() throws EOFException {
        if (this.f250b == 0) {
            a3.b.e();
            return (byte) 0;
        }
        b0 b0Var = this.f249a;
        b0Var.getClass();
        int i = b0Var.f229b;
        int i10 = b0Var.f230c;
        int i11 = i + 1;
        byte b10 = b0Var.f228a[i];
        this.f250b--;
        if (i11 != i10) {
            b0Var.f229b = i11;
            return b10;
        }
        this.f249a = b0Var.a();
        c0.a(b0Var);
        return b10;
    }

    @Override // a9.j
    public final int readInt() throws EOFException {
        if (this.f250b < 4) {
            a3.b.e();
            return 0;
        }
        b0 b0Var = this.f249a;
        b0Var.getClass();
        int i = b0Var.f229b;
        int i10 = b0Var.f230c;
        if (i10 - i < 4) {
            return ((readByte() & 255) << 24) | ((readByte() & 255) << 16) | ((readByte() & 255) << 8) | (readByte() & 255);
        }
        byte[] bArr = b0Var.f228a;
        int i11 = i + 3;
        int i12 = ((bArr[i + 1] & 255) << 16) | ((bArr[i] & 255) << 24) | ((bArr[i + 2] & 255) << 8);
        int i13 = i + 4;
        int i14 = (bArr[i11] & 255) | i12;
        this.f250b -= 4;
        if (i13 != i10) {
            b0Var.f229b = i13;
            return i14;
        }
        this.f249a = b0Var.a();
        c0.a(b0Var);
        return i14;
    }

    @Override // a9.j
    public final short readShort() throws EOFException {
        if (this.f250b < 2) {
            a3.b.e();
            return (short) 0;
        }
        b0 b0Var = this.f249a;
        b0Var.getClass();
        int i = b0Var.f229b;
        int i10 = b0Var.f230c;
        if (i10 - i < 2) {
            return (short) (((readByte() & 255) << 8) | (readByte() & 255));
        }
        byte[] bArr = b0Var.f228a;
        int i11 = i + 1;
        int i12 = (bArr[i] & 255) << 8;
        int i13 = i + 2;
        int i14 = (bArr[i11] & 255) | i12;
        this.f250b -= 2;
        if (i13 == i10) {
            this.f249a = b0Var.a();
            c0.a(b0Var);
        } else {
            b0Var.f229b = i13;
        }
        return (short) i14;
    }

    @Override // a9.j
    public final String s() {
        return k(LocationRequestCompat.PASSIVE_INTERVAL);
    }

    @Override // a9.j
    public final void skip(long j) throws EOFException {
        while (j > 0) {
            b0 b0Var = this.f249a;
            if (b0Var == null) {
                a3.b.e();
                return;
            }
            int iMin = (int) Math.min(j, b0Var.f230c - b0Var.f229b);
            long j10 = iMin;
            this.f250b -= j10;
            j -= j10;
            int i = b0Var.f229b + iMin;
            b0Var.f229b = i;
            if (i == b0Var.f230c) {
                this.f249a = b0Var.a();
                c0.a(b0Var);
            }
        }
    }

    public final b0 t(int i) {
        if (i < 1 || i > 8192) {
            com.google.android.material.drawable.a.l("unexpected capacity");
            return null;
        }
        b0 b0Var = this.f249a;
        if (b0Var == null) {
            b0 b0VarB = c0.b();
            this.f249a = b0VarB;
            b0VarB.g = b0VarB;
            b0VarB.f = b0VarB;
            return b0VarB;
        }
        b0 b0Var2 = b0Var.g;
        b0Var2.getClass();
        if (b0Var2.f230c + i <= 8192 && b0Var2.f232e) {
            return b0Var2;
        }
        b0 b0VarB2 = c0.b();
        b0Var2.b(b0VarB2);
        return b0VarB2;
    }

    public final String toString() {
        long j = this.f250b;
        if (j <= 2147483647L) {
            return r((int) j).toString();
        }
        throw new IllegalStateException(("size > Int.MAX_VALUE: " + this.f250b).toString());
    }

    @Override // a9.j
    public final void u(long j) throws EOFException {
        if (this.f250b >= j) {
            return;
        }
        a3.b.e();
    }

    @Override // a9.i
    public final OutputStream v() {
        return new g(this, 0);
    }

    /* JADX WARN: Removed duplicated region for block: B:33:0x0094  */
    /* JADX WARN: Removed duplicated region for block: B:34:0x009e  */
    /* JADX WARN: Removed duplicated region for block: B:36:0x00a2  */
    /* JADX WARN: Removed duplicated region for block: B:44:0x00a6 A[EDGE_INSN: B:44:0x00a6->B:38:0x00a6 BREAK  A[LOOP:0: B:5:0x000c->B:46:?], SYNTHETIC] */
    @Override // a9.j
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final long w() throws java.io.EOFException {
        /*
            r15 = this;
            long r0 = r15.f250b
            r2 = 0
            int r0 = (r0 > r2 ? 1 : (r0 == r2 ? 0 : -1))
            if (r0 == 0) goto Lad
            r0 = 0
            r1 = r0
            r6 = r1
            r4 = r2
        Lc:
            a9.b0 r7 = r15.f249a
            r7.getClass()
            byte[] r8 = r7.f228a
            int r9 = r7.f229b
            int r10 = r7.f230c
        L17:
            if (r9 >= r10) goto L92
            r11 = r8[r9]
            r12 = 48
            if (r11 < r12) goto L26
            r12 = 57
            if (r11 > r12) goto L26
            int r12 = r11 + (-48)
            goto L3b
        L26:
            r12 = 97
            if (r11 < r12) goto L31
            r12 = 102(0x66, float:1.43E-43)
            if (r11 > r12) goto L31
            int r12 = r11 + (-87)
            goto L3b
        L31:
            r12 = 65
            if (r11 < r12) goto L6a
            r12 = 70
            if (r11 > r12) goto L6a
            int r12 = r11 + (-55)
        L3b:
            r13 = -1152921504606846976(0xf000000000000000, double:-3.105036184601418E231)
            long r13 = r13 & r4
            int r13 = (r13 > r2 ? 1 : (r13 == r2 ? 0 : -1))
            if (r13 != 0) goto L4b
            r11 = 4
            long r4 = r4 << r11
            long r11 = (long) r12
            long r4 = r4 | r11
            int r9 = r9 + 1
            int r1 = r1 + 1
            goto L17
        L4b:
            a9.h r0 = new a9.h
            r0.<init>()
            r0.C(r4)
            r0.A(r11)
            java.lang.NumberFormatException r1 = new java.lang.NumberFormatException
            long r2 = r0.f250b
            java.nio.charset.Charset r4 = p7.a.f7743a
            java.lang.String r0 = r0.q(r2, r4)
            java.lang.String r2 = "Number too large: "
            java.lang.String r0 = r2.concat(r0)
            r1.<init>(r0)
            throw r1
        L6a:
            r6 = 1
            if (r1 == 0) goto L6e
            goto L92
        L6e:
            java.lang.NumberFormatException r1 = new java.lang.NumberFormatException
            int r2 = r11 >> 4
            r2 = r2 & 15
            char[] r3 = b9.b.f1152a
            char r2 = r3[r2]
            r4 = r11 & 15
            char r3 = r3[r4]
            r4 = 2
            char[] r4 = new char[r4]
            r4[r0] = r2
            r4[r6] = r3
            java.lang.String r0 = new java.lang.String
            r0.<init>(r4)
            java.lang.String r2 = "Expected leading [0-9a-fA-F] character but was 0x"
            java.lang.String r0 = r2.concat(r0)
            r1.<init>(r0)
            throw r1
        L92:
            if (r9 != r10) goto L9e
            a9.b0 r8 = r7.a()
            r15.f249a = r8
            a9.c0.a(r7)
            goto La0
        L9e:
            r7.f229b = r9
        La0:
            if (r6 != 0) goto La6
            a9.b0 r7 = r15.f249a
            if (r7 != 0) goto Lc
        La6:
            long r2 = r15.f250b
            long r0 = (long) r1
            long r2 = r2 - r0
            r15.f250b = r2
            return r4
        Lad:
            a3.b.e()
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: a9.h.w():long");
    }

    public final void write(byte[] bArr, int i, int i10) {
        bArr.getClass();
        long j = i10;
        n1.b.i(bArr.length, i, j);
        int i11 = i10 + i;
        while (i < i11) {
            b0 b0VarT = t(1);
            int iMin = Math.min(i11 - i, 8192 - b0VarT.f230c);
            int i12 = i + iMin;
            u6.j.V(bArr, b0VarT.f230c, b0VarT.f228a, i, i12);
            b0VarT.f230c += iMin;
            i = i12;
        }
        this.f250b += j;
    }

    @Override // a9.i
    public final /* bridge */ /* synthetic */ i writeByte(int i) {
        A(i);
        return this;
    }

    @Override // a9.i
    public final /* bridge */ /* synthetic */ i writeInt(int i) {
        D(i);
        return this;
    }

    @Override // a9.i
    public final /* bridge */ /* synthetic */ i writeShort(int i) {
        E(i);
        return this;
    }

    @Override // a9.j
    public final InputStream x() {
        return new f(this, 0);
    }

    public final void y(k kVar) {
        kVar.getClass();
        kVar.u(this, kVar.f());
    }

    public final void z(g0 g0Var) {
        g0Var.getClass();
        while (g0Var.l(this, 8192L) != -1) {
        }
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable, java.nio.channels.Channel, a9.e0
    public final void close() {
    }

    @Override // a9.i, a9.e0, java.io.Flushable
    public final void flush() {
    }

    @Override // a9.i
    public final i write(byte[] bArr) {
        write(bArr, 0, bArr.length);
        return this;
    }

    @Override // java.nio.channels.WritableByteChannel
    public final int write(ByteBuffer byteBuffer) {
        byteBuffer.getClass();
        int iRemaining = byteBuffer.remaining();
        int i = iRemaining;
        while (i > 0) {
            b0 b0VarT = t(1);
            int iMin = Math.min(i, 8192 - b0VarT.f230c);
            byteBuffer.get(b0VarT.f228a, b0VarT.f230c, iMin);
            i -= iMin;
            b0VarT.f230c += iMin;
        }
        this.f250b += (long) iRemaining;
        return iRemaining;
    }

    @Override // java.nio.channels.ReadableByteChannel
    public final int read(ByteBuffer byteBuffer) {
        byteBuffer.getClass();
        b0 b0Var = this.f249a;
        if (b0Var == null) {
            return -1;
        }
        int iMin = Math.min(byteBuffer.remaining(), b0Var.f230c - b0Var.f229b);
        byteBuffer.put(b0Var.f228a, b0Var.f229b, iMin);
        int i = b0Var.f229b + iMin;
        b0Var.f229b = i;
        this.f250b -= (long) iMin;
        if (i == b0Var.f230c) {
            this.f249a = b0Var.a();
            c0.a(b0Var);
        }
        return iMin;
    }
}
