package a9;

import java.io.Closeable;
import java.io.Flushable;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public interface e0 extends Closeable, Flushable {
    i0 a();

    @Override // java.io.Closeable, java.lang.AutoCloseable
    void close();

    void flush();

    void i(h hVar, long j);
}
