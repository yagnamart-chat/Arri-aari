package a9;

import java.io.EOFException;
import java.io.IOException;
import java.util.zip.DataFormatException;
import java.util.zip.Inflater;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public final class t implements g0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final a0 f283a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Inflater f284b;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public int f285l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public boolean f286m;

    public t(a0 a0Var, Inflater inflater) {
        this.f283a = a0Var;
        this.f284b = inflater;
    }

    @Override // a9.g0
    public final i0 a() {
        return this.f283a.f222a.a();
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public final void close() {
        if (this.f286m) {
            return;
        }
        this.f284b.end();
        this.f286m = true;
        this.f283a.close();
    }

    @Override // a9.g0
    public final long l(h hVar, long j) throws IOException {
        long j10;
        hVar.getClass();
        while (j >= 0) {
            if (this.f286m) {
                androidx.window.layout.c.g("closed");
                return 0L;
            }
            a0 a0Var = this.f283a;
            Inflater inflater = this.f284b;
            if (j == 0) {
                j10 = 0;
            } else {
                try {
                    b0 b0VarT = hVar.t(1);
                    int iMin = (int) Math.min(j, 8192 - b0VarT.f230c);
                    if (inflater.needsInput() && !a0Var.b()) {
                        b0 b0Var = a0Var.f223b.f249a;
                        b0Var.getClass();
                        int i = b0Var.f230c;
                        int i10 = b0Var.f229b;
                        int i11 = i - i10;
                        this.f285l = i11;
                        inflater.setInput(b0Var.f228a, i10, i11);
                    }
                    int iInflate = inflater.inflate(b0VarT.f228a, b0VarT.f230c, iMin);
                    int i12 = this.f285l;
                    if (i12 != 0) {
                        int remaining = i12 - inflater.getRemaining();
                        this.f285l -= remaining;
                        a0Var.skip(remaining);
                    }
                    if (iInflate > 0) {
                        b0VarT.f230c += iInflate;
                        j10 = iInflate;
                        hVar.f250b += j10;
                    } else {
                        if (b0VarT.f229b == b0VarT.f230c) {
                            hVar.f249a = b0VarT.a();
                            c0.a(b0VarT);
                        }
                        j10 = 0;
                    }
                } catch (DataFormatException e5) {
                    throw new IOException(e5);
                }
            }
            if (j10 > 0) {
                return j10;
            }
            if (inflater.finished() || inflater.needsDictionary()) {
                return -1L;
            }
            if (a0Var.b()) {
                throw new EOFException("source exhausted prematurely");
            }
        }
        a3.b.q(a4.x.h(j, "byteCount < 0: "));
        return 0L;
    }
}
