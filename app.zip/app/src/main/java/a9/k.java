package a9;

import java.io.Serializable;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public class k implements Serializable, Comparable {

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public static final k f259m = new k(new byte[0]);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final byte[] f260a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public transient int f261b;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public transient String f262l;

    public k(byte[] bArr) {
        bArr.getClass();
        this.f260a = bArr;
    }

    public static final k c(String str) {
        int i;
        char cCharAt;
        str.getClass();
        byte[] bArr = a.f221a;
        int length = str.length();
        while (length > 0 && ((cCharAt = str.charAt(length - 1)) == '=' || cCharAt == '\n' || cCharAt == '\r' || cCharAt == ' ' || cCharAt == '\t')) {
            length--;
        }
        int i10 = (int) ((((long) length) * 6) / 8);
        byte[] bArrCopyOf = new byte[i10];
        int i11 = 0;
        int i12 = 0;
        int i13 = 0;
        int i14 = 0;
        while (true) {
            if (i11 < length) {
                char cCharAt2 = str.charAt(i11);
                if ('A' <= cCharAt2 && cCharAt2 < '[') {
                    i = cCharAt2 - 'A';
                } else if ('a' <= cCharAt2 && cCharAt2 < '{') {
                    i = cCharAt2 - 'G';
                } else if ('0' <= cCharAt2 && cCharAt2 < ':') {
                    i = cCharAt2 + 4;
                } else if (cCharAt2 != '+' && cCharAt2 != '-') {
                    if (cCharAt2 != '/' && cCharAt2 != '_') {
                        if (cCharAt2 != '\n' && cCharAt2 != '\r' && cCharAt2 != ' ' && cCharAt2 != '\t') {
                            break;
                        }
                        i11++;
                    } else {
                        i = 63;
                    }
                } else {
                    i = 62;
                }
                i13 = (i13 << 6) | i;
                i12++;
                if (i12 % 4 == 0) {
                    bArrCopyOf[i14] = (byte) (i13 >> 16);
                    int i15 = i14 + 2;
                    bArrCopyOf[i14 + 1] = (byte) (i13 >> 8);
                    i14 += 3;
                    bArrCopyOf[i15] = (byte) i13;
                }
                i11++;
            } else {
                int i16 = i12 % 4;
                if (i16 != 1) {
                    if (i16 == 2) {
                        bArrCopyOf[i14] = (byte) ((i13 << 12) >> 16);
                        i14++;
                    } else if (i16 == 3) {
                        int i17 = i13 << 6;
                        int i18 = i14 + 1;
                        bArrCopyOf[i14] = (byte) (i17 >> 16);
                        i14 += 2;
                        bArrCopyOf[i18] = (byte) (i17 >> 8);
                    }
                    if (i14 != i10) {
                        bArrCopyOf = Arrays.copyOf(bArrCopyOf, i14);
                    }
                }
            }
        }
        bArrCopyOf = null;
        if (bArrCopyOf != null) {
            return new k(bArrCopyOf);
        }
        return null;
    }

    public static final void d(String str) {
        if (str.length() % 2 != 0) {
            a3.b.q("Unexpected hex string: ".concat(str));
            return;
        }
        int length = str.length() / 2;
        byte[] bArr = new byte[length];
        for (int i = 0; i < length; i++) {
            int i10 = i * 2;
            bArr[i] = (byte) (b9.b.a(str.charAt(i10 + 1)) + (b9.b.a(str.charAt(i10)) << 4));
        }
        new k(bArr);
    }

    public static int i(k kVar, k kVar2) {
        kVar.getClass();
        kVar2.getClass();
        return kVar.h(0, kVar2.j());
    }

    public static int m(k kVar, k kVar2) {
        kVar.getClass();
        kVar2.getClass();
        return kVar.l(kVar2.j());
    }

    public static final k n(byte... bArr) {
        bArr.getClass();
        return new k(Arrays.copyOf(bArr, bArr.length));
    }

    public static /* synthetic */ k r(k kVar, int i, int i10, int i11) {
        if ((i11 & 1) != 0) {
            i = 0;
        }
        if ((i11 & 2) != 0) {
            i10 = -1234567890;
        }
        return kVar.q(i, i10);
    }

    public String a() {
        byte[] bArr = a.f221a;
        byte[] bArr2 = this.f260a;
        bArr2.getClass();
        bArr.getClass();
        byte[] bArr3 = new byte[((bArr2.length + 2) / 3) * 4];
        int length = bArr2.length - (bArr2.length % 3);
        int i = 0;
        int i10 = 0;
        while (i < length) {
            byte b10 = bArr2[i];
            int i11 = i + 2;
            byte b11 = bArr2[i + 1];
            i += 3;
            byte b12 = bArr2[i11];
            bArr3[i10] = bArr[(b10 & 255) >> 2];
            bArr3[i10 + 1] = bArr[((b10 & 3) << 4) | ((b11 & 255) >> 4)];
            int i12 = i10 + 3;
            bArr3[i10 + 2] = bArr[((b11 & 15) << 2) | ((b12 & 255) >> 6)];
            i10 += 4;
            bArr3[i12] = bArr[b12 & 63];
        }
        int length2 = bArr2.length - length;
        if (length2 == 1) {
            byte b13 = bArr2[i];
            bArr3[i10] = bArr[(b13 & 255) >> 2];
            bArr3[i10 + 1] = bArr[(b13 & 3) << 4];
            bArr3[i10 + 2] = 61;
            bArr3[i10 + 3] = 61;
        } else if (length2 == 2) {
            int i13 = i + 1;
            byte b14 = bArr2[i];
            byte b15 = bArr2[i13];
            bArr3[i10] = bArr[(b14 & 255) >> 2];
            bArr3[i10 + 1] = bArr[((b14 & 3) << 4) | ((b15 & 255) >> 4)];
            bArr3[i10 + 2] = bArr[(b15 & 15) << 2];
            bArr3[i10 + 3] = 61;
        }
        return new String(bArr3, p7.a.f7743a);
    }

    @Override // java.lang.Comparable
    /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
    public final int compareTo(k kVar) {
        kVar.getClass();
        int iF = f();
        int iF2 = kVar.f();
        int iMin = Math.min(iF, iF2);
        for (int i = 0; i < iMin; i++) {
            int iK = k(i) & 255;
            int iK2 = kVar.k(i) & 255;
            if (iK != iK2) {
                return iK < iK2 ? -1 : 1;
            }
        }
        if (iF == iF2) {
            return 0;
        }
        return iF < iF2 ? -1 : 1;
    }

    public k e(String str) throws NoSuchAlgorithmException {
        MessageDigest messageDigest = MessageDigest.getInstance(str);
        messageDigest.update(this.f260a, 0, f());
        byte[] bArrDigest = messageDigest.digest();
        bArrDigest.getClass();
        return new k(bArrDigest);
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj instanceof k) {
            k kVar = (k) obj;
            int iF = kVar.f();
            byte[] bArr = this.f260a;
            if (iF == bArr.length && kVar.p(0, bArr, 0, bArr.length)) {
                return true;
            }
        }
        return false;
    }

    public int f() {
        return this.f260a.length;
    }

    public String g() {
        byte[] bArr = this.f260a;
        char[] cArr = new char[bArr.length * 2];
        int i = 0;
        for (byte b10 : bArr) {
            int i10 = i + 1;
            char[] cArr2 = b9.b.f1152a;
            cArr[i] = cArr2[(b10 >> 4) & 15];
            i += 2;
            cArr[i10] = cArr2[b10 & 15];
        }
        return new String(cArr);
    }

    public int h(int i, byte[] bArr) {
        bArr.getClass();
        byte[] bArr2 = this.f260a;
        int length = bArr2.length - bArr.length;
        int iMax = Math.max(i, 0);
        if (iMax > length) {
            return -1;
        }
        while (!n1.b.d(bArr2, iMax, bArr, 0, bArr.length)) {
            if (iMax == length) {
                return -1;
            }
            iMax++;
        }
        return iMax;
    }

    public int hashCode() {
        int i = this.f261b;
        if (i != 0) {
            return i;
        }
        int iHashCode = Arrays.hashCode(this.f260a);
        this.f261b = iHashCode;
        return iHashCode;
    }

    public byte[] j() {
        return this.f260a;
    }

    public byte k(int i) {
        return this.f260a[i];
    }

    public int l(byte[] bArr) {
        bArr.getClass();
        int iF = f();
        byte[] bArr2 = this.f260a;
        for (int iMin = Math.min(iF, bArr2.length - bArr.length); -1 < iMin; iMin--) {
            if (n1.b.d(bArr2, iMin, bArr, 0, bArr.length)) {
                return iMin;
            }
        }
        return -1;
    }

    public boolean o(int i, k kVar, int i10) {
        kVar.getClass();
        return kVar.p(0, this.f260a, i, i10);
    }

    public boolean p(int i, byte[] bArr, int i10, int i11) {
        bArr.getClass();
        if (i < 0) {
            return false;
        }
        byte[] bArr2 = this.f260a;
        return i <= bArr2.length - i11 && i10 >= 0 && i10 <= bArr.length - i11 && n1.b.d(bArr2, i, bArr, i10, i11);
    }

    public k q(int i, int i10) {
        if (i10 == -1234567890) {
            i10 = f();
        }
        if (i < 0) {
            com.google.android.material.drawable.a.l("beginIndex < 0");
            return null;
        }
        byte[] bArr = this.f260a;
        if (i10 > bArr.length) {
            a3.b.h(bArr.length, 41, "endIndex > length(");
            return null;
        }
        if (i10 - i < 0) {
            com.google.android.material.drawable.a.l("endIndex < beginIndex");
            return null;
        }
        if (i == 0 && i10 == bArr.length) {
            return this;
        }
        n1.b.o(i10, bArr.length);
        byte[] bArrCopyOfRange = Arrays.copyOfRange(bArr, i, i10);
        bArrCopyOfRange.getClass();
        return new k(bArrCopyOfRange);
    }

    public k s() {
        int i = 0;
        while (true) {
            byte[] bArr = this.f260a;
            if (i >= bArr.length) {
                return this;
            }
            byte b10 = bArr[i];
            if (b10 >= 65 && b10 <= 90) {
                byte[] bArrCopyOf = Arrays.copyOf(bArr, bArr.length);
                bArrCopyOf[i] = (byte) (b10 + 32);
                for (int i10 = i + 1; i10 < bArrCopyOf.length; i10++) {
                    byte b11 = bArrCopyOf[i10];
                    if (b11 >= 65 && b11 <= 90) {
                        bArrCopyOf[i10] = (byte) (b11 + 32);
                    }
                }
                return new k(bArrCopyOf);
            }
            i++;
        }
    }

    public final String t() {
        String str = this.f262l;
        if (str != null) {
            return str;
        }
        byte[] bArrJ = j();
        bArrJ.getClass();
        String str2 = new String(bArrJ, p7.a.f7743a);
        this.f262l = str2;
        return str2;
    }

    public String toString() {
        k kVar;
        byte b10;
        int i;
        byte[] bArr = this.f260a;
        if (bArr.length == 0) {
            return "[size=0]";
        }
        int length = bArr.length;
        int i10 = 0;
        int i11 = 0;
        int i12 = 0;
        loop0: while (true) {
            if (i10 >= length) {
                break;
            }
            byte b11 = bArr[i10];
            if (b11 >= 0) {
                int i13 = i12 + 1;
                if (i12 == 64) {
                    break;
                }
                if ((b11 != 10 && b11 != 13 && ((b11 >= 0 && b11 < 32) || (127 <= b11 && b11 < 160))) || b11 == 65533) {
                    break;
                }
                i11 += b11 < 65536 ? 1 : 2;
                i10++;
                while (true) {
                    i12 = i13;
                    if (i10 < length && (b10 = bArr[i10]) >= 0) {
                        i10++;
                        i13 = i12 + 1;
                        if (i12 == 64) {
                            break loop0;
                        }
                        if ((b10 != 10 && b10 != 13 && ((b10 >= 0 && b10 < 32) || (127 <= b10 && b10 < 160))) || b10 == 65533) {
                            break loop0;
                        }
                        i11 += b10 < 65536 ? 1 : 2;
                    } else {
                        break;
                    }
                }
            } else if ((b11 >> 5) == -2) {
                int i14 = i10 + 1;
                if (length > i14) {
                    byte b12 = bArr[i14];
                    if ((b12 & 192) == 128) {
                        int i15 = (b12 ^ 3968) ^ (b11 << 6);
                        if (i15 >= 128) {
                            i = i12 + 1;
                            if (i12 == 64) {
                                break;
                            }
                            if ((i15 != 10 && i15 != 13 && ((i15 >= 0 && i15 < 32) || (127 <= i15 && i15 < 160))) || i15 == 65533) {
                                break;
                            }
                            i11 += i15 < 65536 ? 1 : 2;
                            i10 += 2;
                            i12 = i;
                        } else if (i12 != 64) {
                            break;
                        }
                    } else if (i12 != 64) {
                        break;
                    }
                } else if (i12 != 64) {
                    break;
                }
            } else if ((b11 >> 4) == -2) {
                int i16 = i10 + 2;
                if (length > i16) {
                    byte b13 = bArr[i10 + 1];
                    if ((b13 & 192) == 128) {
                        byte b14 = bArr[i16];
                        if ((b14 & 192) == 128) {
                            int i17 = ((b14 ^ (-123008)) ^ (b13 << 6)) ^ (b11 << 12);
                            if (i17 < 2048) {
                                if (i12 != 64) {
                                    break;
                                }
                            } else if (55296 > i17 || i17 >= 57344) {
                                i = i12 + 1;
                                if (i12 == 64) {
                                    break;
                                }
                                if ((i17 != 10 && i17 != 13 && ((i17 >= 0 && i17 < 32) || (127 <= i17 && i17 < 160))) || i17 == 65533) {
                                    break;
                                }
                                i11 += i17 < 65536 ? 1 : 2;
                                i10 += 3;
                                i12 = i;
                            } else if (i12 != 64) {
                                break;
                            }
                        } else if (i12 != 64) {
                            break;
                        }
                    } else if (i12 != 64) {
                        break;
                    }
                } else if (i12 != 64) {
                    break;
                }
            } else if ((b11 >> 3) == -2) {
                int i18 = i10 + 3;
                if (length > i18) {
                    byte b15 = bArr[i10 + 1];
                    if ((b15 & 192) == 128) {
                        byte b16 = bArr[i10 + 2];
                        if ((b16 & 192) == 128) {
                            byte b17 = bArr[i18];
                            if ((b17 & 192) == 128) {
                                int i19 = (((b17 ^ 3678080) ^ (b16 << 6)) ^ (b15 << 12)) ^ (b11 << 18);
                                if (i19 > 1114111) {
                                    if (i12 != 64) {
                                        break;
                                    }
                                } else if (55296 > i19 || i19 >= 57344) {
                                    if (i19 >= 65536) {
                                        i = i12 + 1;
                                        if (i12 == 64) {
                                            break;
                                        }
                                        if ((i19 != 10 && i19 != 13 && ((i19 >= 0 && i19 < 32) || (127 <= i19 && i19 < 160))) || i19 == 65533) {
                                            break;
                                        }
                                        i11 += i19 < 65536 ? 1 : 2;
                                        i10 += 4;
                                        i12 = i;
                                    } else if (i12 != 64) {
                                        break;
                                    }
                                } else if (i12 != 64) {
                                    break;
                                }
                            } else if (i12 != 64) {
                                break;
                            }
                        } else if (i12 != 64) {
                            break;
                        }
                    } else if (i12 != 64) {
                        break;
                    }
                } else if (i12 != 64) {
                    break;
                }
            } else if (i12 != 64) {
                break;
            }
        }
        i11 = -1;
        if (i11 != -1) {
            String strT = t();
            String strB0 = p7.u.b0(p7.u.b0(p7.u.b0(strT.substring(0, i11), "\\", "\\\\", false), "\n", "\\n", false), "\r", "\\r", false);
            if (i11 >= strT.length()) {
                return "[text=" + strB0 + ']';
            }
            return "[size=" + bArr.length + " text=" + strB0 + "…]";
        }
        if (bArr.length <= 64) {
            return "[hex=" + g() + ']';
        }
        StringBuilder sb = new StringBuilder("[size=");
        sb.append(bArr.length);
        sb.append(" hex=");
        if (64 > bArr.length) {
            a3.b.h(bArr.length, 41, "endIndex > length(");
            return null;
        }
        if (64 == bArr.length) {
            kVar = this;
        } else {
            n1.b.o(64, bArr.length);
            byte[] bArrCopyOfRange = Arrays.copyOfRange(bArr, 0, 64);
            bArrCopyOfRange.getClass();
            kVar = new k(bArrCopyOfRange);
        }
        sb.append(kVar.g());
        sb.append("…]");
        return sb.toString();
    }

    public void u(h hVar, int i) {
        hVar.write(this.f260a, 0, i);
    }
}
