package a9;

import java.io.IOException;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public abstract class q implements g0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final g0 f276a;

    public q(g0 g0Var) {
        g0Var.getClass();
        this.f276a = g0Var;
    }

    @Override // a9.g0
    public final i0 a() {
        return this.f276a.a();
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public void close() throws IOException {
        this.f276a.close();
    }

    @Override // a9.g0
    public long l(h hVar, long j) {
        hVar.getClass();
        return this.f276a.l(hVar, j);
    }

    public final String toString() {
        return getClass().getSimpleName() + '(' + this.f276a + ')';
    }
}
