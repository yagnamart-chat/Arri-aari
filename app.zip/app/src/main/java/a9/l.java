package a9;

import java.util.concurrent.locks.ReentrantLock;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public final class l implements e0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final u f263a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public long f264b;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public boolean f265l;

    public l(u uVar) {
        uVar.getClass();
        this.f263a = uVar;
        this.f264b = 0L;
    }

    @Override // a9.e0
    public final i0 a() {
        return i0.f251d;
    }

    @Override // a9.e0, java.io.Closeable, java.lang.AutoCloseable
    public final void close() {
        u uVar = this.f263a;
        if (this.f265l) {
            return;
        }
        this.f265l = true;
        ReentrantLock reentrantLock = uVar.f290m;
        reentrantLock.lock();
        try {
            int i = uVar.f289l - 1;
            uVar.f289l = i;
            if (i == 0) {
                if (uVar.f288b) {
                    synchronized (uVar) {
                        uVar.f291n.close();
                    }
                }
            }
        } finally {
            reentrantLock.unlock();
        }
    }

    @Override // a9.e0, java.io.Flushable
    public final void flush() {
        if (this.f265l) {
            androidx.window.layout.c.g("closed");
            return;
        }
        u uVar = this.f263a;
        synchronized (uVar) {
            uVar.f291n.getFD().sync();
        }
    }

    @Override // a9.e0
    public final void i(h hVar, long j) {
        if (this.f265l) {
            androidx.window.layout.c.g("closed");
            return;
        }
        u uVar = this.f263a;
        long j10 = this.f264b;
        uVar.getClass();
        n1.b.i(hVar.f250b, 0L, j);
        long j11 = j10 + j;
        while (j10 < j11) {
            b0 b0Var = hVar.f249a;
            b0Var.getClass();
            int iMin = (int) Math.min(j11 - j10, b0Var.f230c - b0Var.f229b);
            byte[] bArr = b0Var.f228a;
            int i = b0Var.f229b;
            synchronized (uVar) {
                bArr.getClass();
                uVar.f291n.seek(j10);
                uVar.f291n.write(bArr, i, iMin);
            }
            int i10 = b0Var.f229b + iMin;
            b0Var.f229b = i10;
            long j12 = iMin;
            j10 += j12;
            hVar.f250b -= j12;
            if (i10 == b0Var.f230c) {
                hVar.f249a = b0Var.a();
                c0.a(b0Var);
            }
        }
        this.f264b += j;
    }
}
