package a9;

import b2.t1;
import java.io.IOException;
import java.io.InputStream;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public final class c implements g0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f233a = 0;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Object f234b;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final Object f235l;

    public c(InputStream inputStream, i0 i0Var) {
        inputStream.getClass();
        this.f234b = inputStream;
        this.f235l = i0Var;
    }

    @Override // a9.g0
    public final i0 a() {
        switch (this.f233a) {
            case 0:
                return (f0) this.f234b;
            default:
                return (i0) this.f235l;
        }
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public final void close() throws IOException {
        switch (this.f233a) {
            case 0:
                f0 f0Var = (f0) this.f234b;
                c cVar = (c) this.f235l;
                f0Var.h();
                try {
                    cVar.close();
                    if (f0Var.i()) {
                        throw f0Var.k(null);
                    }
                    return;
                } catch (IOException e5) {
                    if (!f0Var.i()) {
                        throw e5;
                    }
                    throw f0Var.k(e5);
                } finally {
                    f0Var.i();
                }
            default:
                ((InputStream) this.f234b).close();
                return;
        }
    }

    @Override // a9.g0
    public final long l(h hVar, long j) throws IOException {
        int i = this.f233a;
        hVar.getClass();
        switch (i) {
            case 0:
                f0 f0Var = (f0) this.f234b;
                c cVar = (c) this.f235l;
                f0Var.h();
                try {
                    long jL = cVar.l(hVar, j);
                    if (f0Var.i()) {
                        throw f0Var.k(null);
                    }
                    return jL;
                } catch (IOException e5) {
                    if (f0Var.i()) {
                        throw f0Var.k(e5);
                    }
                    throw e5;
                } finally {
                    f0Var.i();
                }
            default:
                if (j == 0) {
                    return 0L;
                }
                if (j < 0) {
                    a3.b.q(a4.x.h(j, "byteCount < 0: "));
                    return 0L;
                }
                try {
                    ((i0) this.f235l).f();
                    b0 b0VarT = hVar.t(1);
                    int i10 = ((InputStream) this.f234b).read(b0VarT.f228a, b0VarT.f230c, (int) Math.min(j, 8192 - b0VarT.f230c));
                    if (i10 == -1) {
                        if (b0VarT.f229b == b0VarT.f230c) {
                            hVar.f249a = b0VarT.a();
                            c0.a(b0VarT);
                        }
                        return -1L;
                    }
                    b0VarT.f230c += i10;
                    long j10 = i10;
                    hVar.f250b += j10;
                    return j10;
                } catch (AssertionError e8) {
                    if (t1.J(e8)) {
                        throw new IOException(e8);
                    }
                    throw e8;
                }
        }
    }

    public final String toString() {
        switch (this.f233a) {
            case 0:
                return "AsyncTimeout.source(" + ((c) this.f235l) + ')';
            default:
                return "source(" + ((InputStream) this.f234b) + ')';
        }
    }

    public c(f0 f0Var, c cVar) {
        this.f234b = f0Var;
        this.f235l = cVar;
    }
}
