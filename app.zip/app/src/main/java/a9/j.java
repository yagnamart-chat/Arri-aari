package a9;

import java.io.InputStream;
import java.nio.channels.ReadableByteChannel;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public interface j extends g0, ReadableByteChannel {
    k f(long j);

    String k(long j);

    byte readByte();

    int readInt();

    short readShort();

    String s();

    void skip(long j);

    void u(long j);

    long w();

    InputStream x();
}
