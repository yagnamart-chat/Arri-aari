package a9;

import androidx.core.location.LocationRequestCompat;
import java.io.IOException;
import java.util.Arrays;
import java.util.zip.CRC32;
import java.util.zip.Inflater;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public final class s implements g0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public byte f278a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final a0 f279b;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final Inflater f280l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final t f281m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final CRC32 f282n;

    public s(g0 g0Var) {
        g0Var.getClass();
        a0 a0Var = new a0(g0Var);
        this.f279b = a0Var;
        Inflater inflater = new Inflater(true);
        this.f280l = inflater;
        this.f281m = new t(a0Var, inflater);
        this.f282n = new CRC32();
    }

    public static void b(int i, int i10, String str) throws IOException {
        if (i10 != i) {
            throw new IOException(String.format("%s: actual 0x%08x != expected 0x%08x", Arrays.copyOf(new Object[]{str, Integer.valueOf(i10), Integer.valueOf(i)}, 3)));
        }
    }

    @Override // a9.g0
    public final i0 a() {
        return this.f279b.f222a.a();
    }

    public final void c(h hVar, long j, long j10) {
        b0 b0Var = hVar.f249a;
        b0Var.getClass();
        while (true) {
            int i = b0Var.f230c;
            int i10 = b0Var.f229b;
            if (j < i - i10) {
                break;
            }
            j -= (long) (i - i10);
            b0Var = b0Var.f;
            b0Var.getClass();
        }
        while (j10 > 0) {
            int i11 = (int) (((long) b0Var.f229b) + j);
            int iMin = (int) Math.min(b0Var.f230c - i11, j10);
            this.f282n.update(b0Var.f228a, i11, iMin);
            j10 -= (long) iMin;
            b0Var = b0Var.f;
            b0Var.getClass();
            j = 0;
        }
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public final void close() {
        this.f281m.close();
    }

    @Override // a9.g0
    public final long l(h hVar, long j) throws IOException {
        s sVar = this;
        hVar.getClass();
        if (j < 0) {
            a3.b.q(a4.x.h(j, "byteCount < 0: "));
            return 0L;
        }
        if (j == 0) {
            return 0L;
        }
        byte b10 = sVar.f278a;
        CRC32 crc32 = sVar.f282n;
        a0 a0Var = sVar.f279b;
        if (b10 == 0) {
            a0Var.u(10L);
            h hVar2 = a0Var.f223b;
            byte bD = hVar2.d(3L);
            boolean z9 = ((bD >> 1) & 1) == 1;
            if (z9) {
                sVar.c(hVar2, 0L, 10L);
            }
            b(8075, a0Var.readShort(), "ID1ID2");
            a0Var.skip(8L);
            if (((bD >> 2) & 1) == 1) {
                a0Var.u(2L);
                if (z9) {
                    c(hVar2, 0L, 2L);
                }
                long jO = hVar2.o() & 65535;
                a0Var.u(jO);
                if (z9) {
                    c(hVar2, 0L, jO);
                }
                a0Var.skip(jO);
            }
            if (((bD >> 3) & 1) == 1) {
                long jC = a0Var.c((byte) 0, 0L, LocationRequestCompat.PASSIVE_INTERVAL);
                if (jC == -1) {
                    a3.b.e();
                    return 0L;
                }
                if (z9) {
                    c(hVar2, 0L, jC + 1);
                }
                a0Var.skip(jC + 1);
            }
            if (((bD >> 4) & 1) == 1) {
                long jC2 = a0Var.c((byte) 0, 0L, LocationRequestCompat.PASSIVE_INTERVAL);
                if (jC2 == -1) {
                    a3.b.e();
                    return 0L;
                }
                if (z9) {
                    sVar = this;
                    sVar.c(hVar2, 0L, jC2 + 1);
                } else {
                    sVar = this;
                }
                a0Var.skip(jC2 + 1);
            } else {
                sVar = this;
            }
            if (z9) {
                b(a0Var.j(), (short) crc32.getValue(), "FHCRC");
                crc32.reset();
            }
            sVar.f278a = (byte) 1;
        }
        if (sVar.f278a == 1) {
            long j10 = hVar.f250b;
            long jL = sVar.f281m.l(hVar, j);
            if (jL != -1) {
                sVar.c(hVar, j10, jL);
                return jL;
            }
            sVar.f278a = (byte) 2;
        }
        if (sVar.f278a == 2) {
            b(a0Var.g(), (int) crc32.getValue(), "CRC");
            b(a0Var.g(), (int) sVar.f280l.getBytesWritten(), "ISIZE");
            sVar.f278a = (byte) 3;
            if (!a0Var.b()) {
                com.google.android.material.drawable.a.k("gzip finished without exhausting source");
                return 0L;
            }
        }
        return -1L;
    }
}
