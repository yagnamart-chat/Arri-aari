package a5;

import v7.d0;
import v7.j0;
import v7.k0;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public abstract class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final j0 f195a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final d0 f196b;

    static {
        j0 j0VarA = k0.a(0, 1);
        f195a = j0VarA;
        f196b = new d0(j0VarA);
    }
}
