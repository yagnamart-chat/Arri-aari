package a5;

import v7.d0;
import v7.e0;
import v7.j0;
import v7.k0;
import v7.o0;
import x4.f0;
import x4.g0;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public abstract class b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final o0 f197a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final e0 f198b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final j0 f199c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final d0 f200d;

    static {
        o0 o0VarB = k0.b(g0.f11071a);
        f197a = o0VarB;
        f198b = new e0(o0VarB);
        j0 j0VarA = k0.a(0, 1);
        f199c = j0VarA;
        f200d = new d0(j0VarA);
    }

    public static void a(f0 f0Var) {
        o0 o0Var = f197a;
        o0Var.getClass();
        o0Var.g(null, g0.f11071a);
        f199c.n(f0Var);
    }
}
