package a3;

import a4.t0;
import a4.u;
import a4.x;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.BadParcelableException;
import android.os.Bundle;
import android.os.NetworkOnMainThreadException;
import android.os.RemoteException;
import android.os.SystemClock;
import android.text.TextUtils;
import android.util.Log;
import android.util.Pair;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.appcompat.widget.SearchView;
import androidx.documentfile.provider.DocumentFile;
import androidx.lifecycle.LifecycleCoroutineScope;
import androidx.lifecycle.LifecycleOwnerKt;
import androidx.viewbinding.ViewBindings;
import androidx.work.Constraints;
import androidx.work.ListenableWorker;
import androidx.work.NetworkType;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;
import c3.x0;
import c4.ea;
import c4.g0;
import c4.r3;
import c4.s5;
import c4.v4;
import c4.w8;
import com.google.android.gms.internal.measurement.h1;
import com.google.android.gms.internal.measurement.j5;
import com.google.android.gms.internal.measurement.k1;
import com.uptodown.R;
import com.uptodown.UptodownApp;
import com.uptodown.activities.OrganizationActivity;
import com.uptodown.activities.PublicListActivity;
import com.uptodown.activities.RecommendedActivity;
import com.uptodown.activities.RepliesActivity;
import com.uptodown.activities.RollbackActivity;
import com.uptodown.activities.SearchActivity;
import com.uptodown.activities.SecurityActivity;
import com.uptodown.activities.UserDeviceDetailsActivity;
import com.uptodown.activities.WishlistActivity;
import com.uptodown.core.activities.FileExplorerActivity;
import com.uptodown.workers.GetRemoteInstallWorker;
import e1.b3;
import e1.f4;
import e1.g1;
import e1.g2;
import e1.j2;
import e1.t1;
import e1.u4;
import e1.w0;
import e1.y0;
import e1.z4;
import e4.c1;
import e4.e1;
import e4.h0;
import e4.j0;
import e4.n0;
import j$.util.DesugarCollections;
import j$.util.concurrent.ConcurrentHashMap;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import kotlin.jvm.internal.l;
import s7.b0;
import s7.l0;
import w4.g;
import w4.p;
import w4.q;
import x4.d1;
import x4.j;
import x4.n1;
import x4.r;
import x4.r1;
import x7.n;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public final class d implements p, e3.b, w4.c, g, w4.b, q, SearchView.OnQueryTextListener, z4, y0, k4.a {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public static volatile d f65l;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f66a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Object f67b;

    public d(Context context) {
        this.f66a = 1;
        StringBuilder sb = t0.f181a;
        ActivityManager activityManager = (ActivityManager) context.getSystemService("activity");
        this.f67b = new u((int) ((((long) ((context.getApplicationInfo().flags & 1048576) != 0 ? activityManager.getLargeMemoryClass() : activityManager.getMemoryClass())) * 1048576) / 7));
    }

    public static d B(String str) {
        return new d((TextUtils.isEmpty(str) || str.length() > 1) ? g2.UNINITIALIZED : j2.e(str.charAt(0)), 24);
    }

    public void A(long j) {
        f4 f4Var = (f4) this.f67b;
        f4Var.g();
        f4Var.k();
        t1 t1Var = f4Var.f3925a;
        g1 g1Var = t1Var.f4313n;
        t1.k(g1Var);
        if (g1Var.q(j)) {
            t1.k(g1Var);
            g1Var.f4040u.b(true);
            t1Var.r().l();
        }
        t1.k(g1Var);
        g1Var.f4043y.b(j);
        if (g1Var.f4040u.a()) {
            C(j);
        }
    }

    public void C(long j) {
        f4 f4Var = (f4) this.f67b;
        f4Var.g();
        t1 t1Var = f4Var.f3925a;
        if (t1Var.d()) {
            g1 g1Var = t1Var.f4313n;
            t1.k(g1Var);
            g1Var.f4043y.b(j);
            t1Var.f4319t.getClass();
            long jElapsedRealtime = SystemClock.elapsedRealtime();
            w0 w0Var = t1Var.f4314o;
            t1.m(w0Var);
            w0Var.f4395w.c(Long.valueOf(jElapsedRealtime), "Session started, time");
            long j10 = j / 1000;
            Long lValueOf = Long.valueOf(j10);
            b3 b3Var = t1Var.v;
            t1.l(b3Var);
            b3Var.r(j, lValueOf, "auto", "_sid");
            t1.k(g1Var);
            g1Var.f4044z.b(j10);
            g1Var.f4040u.b(false);
            Bundle bundle = new Bundle();
            bundle.putLong("_sid", j10);
            t1.l(b3Var);
            b3Var.o(j, bundle, "auto", "_s");
            String strN = g1Var.E.n();
            if (TextUtils.isEmpty(strN)) {
                return;
            }
            Bundle bundle2 = new Bundle();
            bundle2.putString("_ffr", strN);
            t1.l(b3Var);
            b3Var.o(j, bundle2, "auto", "_ssr");
        }
    }

    @Override // w4.b, w4.q
    public void a(int i) {
        j0 j0Var;
        String str;
        e1 e1Var;
        int i10 = this.f66a;
        int i11 = 1;
        int i12 = 2;
        x6.c cVar = null;
        Object obj = this.f67b;
        switch (i10) {
            case 15:
                RollbackActivity rollbackActivity = (RollbackActivity) obj;
                float f = UptodownApp.J;
                if (b4.c.t() && (j0Var = rollbackActivity.f3507e0) != null && i < j0Var.f4621a.size()) {
                    j0 j0Var2 = rollbackActivity.f3507e0;
                    j0Var2.getClass();
                    if (((x4.e) j0Var2.f4621a.get(i)).F != 0) {
                        j0 j0Var3 = rollbackActivity.f3507e0;
                        j0Var3.getClass();
                        Object obj2 = j0Var3.f4621a.get(i);
                        obj2.getClass();
                        LifecycleCoroutineScope lifecycleScope = LifecycleOwnerKt.getLifecycleScope(rollbackActivity);
                        z7.e eVar = l0.f9082a;
                        b0.r(lifecycleScope, n.f11429a, null, new v4(rollbackActivity, (x4.e) obj2, cVar, i11), 2);
                    }
                    break;
                }
                break;
            case 16:
            case 18:
            default:
                WishlistActivity wishlistActivity = (WishlistActivity) obj;
                float f7 = UptodownApp.J;
                if (b4.c.t() && (e1Var = wishlistActivity.f3533e0) != null && !e1Var.f4570a.isEmpty()) {
                    e1 e1Var2 = wishlistActivity.f3533e0;
                    e1Var2.getClass();
                    Object obj3 = e1Var2.f4570a.get(i);
                    obj3.getClass();
                    x4.t1 t1Var = (x4.t1) obj3;
                    wishlistActivity.g0(t1Var.f11294a, t1Var.i);
                    break;
                }
                break;
            case 17:
                SecurityActivity securityActivity = (SecurityActivity) obj;
                float f10 = UptodownApp.J;
                if (b4.c.t()) {
                    int i13 = SecurityActivity.f3510i0;
                    n0 n0Var = securityActivity.f3513e0;
                    n0Var.getClass();
                    if (n0Var.a().get(i) instanceof x4.e) {
                        n0 n0Var2 = securityActivity.f3513e0;
                        n0Var2.getClass();
                        Object obj4 = n0Var2.a().get(i);
                        obj4.getClass();
                        x4.e eVar2 = (x4.e) obj4;
                        if (!securityActivity.isFinishing()) {
                            int i14 = 0;
                            View viewInflate = securityActivity.getLayoutInflater().inflate(R.layout.dialog_positive_selected, (ViewGroup) null, false);
                            int i15 = R.id.iv_icon;
                            ImageView imageView = (ImageView) ViewBindings.findChildViewById(viewInflate, R.id.iv_icon);
                            if (imageView != null) {
                                i15 = R.id.rl_header;
                                if (((RelativeLayout) ViewBindings.findChildViewById(viewInflate, R.id.rl_header)) != null) {
                                    i15 = R.id.tv_app_name;
                                    TextView textView = (TextView) ViewBindings.findChildViewById(viewInflate, R.id.tv_app_name);
                                    if (textView != null) {
                                        i15 = R.id.tv_open_app_details_positive;
                                        TextView textView2 = (TextView) ViewBindings.findChildViewById(viewInflate, R.id.tv_open_app_details_positive);
                                        if (textView2 != null) {
                                            i15 = R.id.tv_rollback_positive;
                                            TextView textView3 = (TextView) ViewBindings.findChildViewById(viewInflate, R.id.tv_rollback_positive);
                                            if (textView3 != null) {
                                                i15 = R.id.tv_uninstall_positive;
                                                TextView textView4 = (TextView) ViewBindings.findChildViewById(viewInflate, R.id.tv_uninstall_positive);
                                                if (textView4 != null) {
                                                    i15 = R.id.tv_virus_report_positive;
                                                    TextView textView5 = (TextView) ViewBindings.findChildViewById(viewInflate, R.id.tv_virus_report_positive);
                                                    if (textView5 != null) {
                                                        i15 = R.id.v_outside_header;
                                                        if (ViewBindings.findChildViewById(viewInflate, R.id.v_outside_header) != null) {
                                                            securityActivity.F = new AlertDialog.Builder(securityActivity).setView((RelativeLayout) viewInflate).create();
                                                            textView.setTypeface(f4.c.f4889x);
                                                            textView.setText(eVar2.f10999b);
                                                            ConcurrentHashMap concurrentHashMap = n5.q.f7470a;
                                                            imageView.setImageDrawable(n5.q.c(securityActivity, eVar2.f11000l));
                                                            if (eVar2.f11000l == null || eVar2.f11009u == null || eVar2.F <= 0) {
                                                                textView2.setVisibility(8);
                                                                textView5.setVisibility(8);
                                                                textView3.setVisibility(8);
                                                            } else {
                                                                textView2.setTypeface(f4.c.f4890y);
                                                                textView2.setOnClickListener(new ea(securityActivity, eVar2, i14));
                                                                textView5.setTypeface(f4.c.f4890y);
                                                                textView5.setOnClickListener(new ea(securityActivity, eVar2, i11));
                                                                textView3.setTypeface(f4.c.f4890y);
                                                                textView3.setOnClickListener(new ea(securityActivity, eVar2, i12));
                                                            }
                                                            if (p7.u.Z(securityActivity.getPackageName(), eVar2.f11000l, true)) {
                                                                textView4.setVisibility(8);
                                                            } else {
                                                                textView4.setTypeface(f4.c.f4890y);
                                                                textView4.setOnClickListener(new ea(eVar2, securityActivity));
                                                            }
                                                            if (!securityActivity.isFinishing()) {
                                                                AlertDialog alertDialog = securityActivity.F;
                                                                alertDialog.getClass();
                                                                Window window = alertDialog.getWindow();
                                                                if (window != null) {
                                                                    x.y(window, 0);
                                                                }
                                                                AlertDialog alertDialog2 = securityActivity.F;
                                                                alertDialog2.getClass();
                                                                alertDialog2.show();
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            com.google.android.material.drawable.a.j("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(i15)));
                        }
                    }
                }
                break;
            case 19:
                UserDeviceDetailsActivity userDeviceDetailsActivity = (UserDeviceDetailsActivity) obj;
                c1 c1Var = userDeviceDetailsActivity.S;
                if (c1Var != null && (str = ((r1) c1Var.f4554a.get(i)).f11260b) != null && str.length() != 0) {
                    LifecycleCoroutineScope lifecycleScope2 = LifecycleOwnerKt.getLifecycleScope(userDeviceDetailsActivity);
                    z7.e eVar3 = l0.f9082a;
                    b0.r(lifecycleScope2, z7.d.f11887a, null, new r3(userDeviceDetailsActivity, i, cVar, 5), 2);
                    break;
                }
                break;
        }
    }

    @Override // e1.z4
    public void b(String str, String str2, Bundle bundle) {
        boolean zIsEmpty = TextUtils.isEmpty(str);
        b3 b3Var = (b3) this.f67b;
        if (zIsEmpty) {
            b3Var.f3925a.f4319t.getClass();
            b3Var.l("auto", "_err", bundle, true, true, System.currentTimeMillis());
        } else {
            b3Var.getClass();
            androidx.window.layout.c.g("Unexpected call on client side");
        }
    }

    @Override // e1.y0
    public /* synthetic */ void c(String str, int i, Throwable th, byte[] bArr, Map map) {
        ((u4) this.f67b).A(str, i, th, bArr, map);
    }

    @Override // w4.q
    public void d(View view, int i) {
        e1 e1Var;
        WishlistActivity wishlistActivity = (WishlistActivity) this.f67b;
        float f = UptodownApp.J;
        if (!b4.c.t() || (e1Var = wishlistActivity.f3533e0) == null || e1Var.f4570a.isEmpty()) {
            return;
        }
        e1 e1Var2 = wishlistActivity.f3533e0;
        e1Var2.getClass();
        Object obj = e1Var2.f4570a.get(i);
        obj.getClass();
        x4.t1 t1Var = (x4.t1) obj;
        String string = wishlistActivity.getString(R.string.dialog_wishlist_msg);
        string.getClass();
        wishlistActivity.I(String.format(string, Arrays.copyOf(new Object[]{t1Var.f11295b}, 1)), new s5(i, wishlistActivity, 2, t1Var));
    }

    @Override // w4.c
    public void e(x4.g gVar) {
        int i = this.f66a;
        Object obj = this.f67b;
        gVar.getClass();
        switch (i) {
            case 11:
                float f = UptodownApp.J;
                if (b4.c.t()) {
                    ((OrganizationActivity) obj).f0(gVar.f11031a);
                }
                break;
            default:
                float f7 = UptodownApp.J;
                if (b4.c.t()) {
                    ((SearchActivity) obj).f0(gVar.f11031a);
                }
                break;
        }
    }

    @Override // w4.q
    public void f(int i) {
        WishlistActivity wishlistActivity = (WishlistActivity) this.f67b;
        e1 e1Var = wishlistActivity.f3533e0;
        if (e1Var == null || e1Var.f4570a.isEmpty()) {
            return;
        }
        LifecycleCoroutineScope lifecycleScope = LifecycleOwnerKt.getLifecycleScope(wishlistActivity);
        z7.e eVar = l0.f9082a;
        b0.r(lifecycleScope, n.f11429a, null, new b.e(wishlistActivity, i, null, 5), 2);
    }

    @Override // q6.a
    public Object get() {
        return new x0((c3.e1) ((e3.d) this.f67b).get());
    }

    @Override // w4.g
    public void h(r rVar) {
        int i = this.f66a;
        Object obj = this.f67b;
        switch (i) {
            case 12:
                float f = UptodownApp.J;
                File fileG = rVar.g();
                fileG.getClass();
                b4.c.q((PublicListActivity) obj, null, fileG);
                break;
            default:
                float f7 = UptodownApp.J;
                File fileG2 = rVar.g();
                fileG2.getClass();
                b4.c.q((RecommendedActivity) obj, null, fileG2);
                break;
        }
    }

    @Override // k4.a
    public void j(Object obj, int i, int i10, long j) {
        obj.getClass();
        boolean z9 = obj instanceof File;
        FileExplorerActivity fileExplorerActivity = (FileExplorerActivity) this.f67b;
        if (z9) {
            FileExplorerActivity.J(fileExplorerActivity, ((File) obj).getName(), i, i10, j);
        } else if (obj instanceof DocumentFile) {
            FileExplorerActivity.J(fileExplorerActivity, ((DocumentFile) obj).getName(), i, i10, j);
        } else {
            FileExplorerActivity.J(fileExplorerActivity, fileExplorerActivity.getString(R.string.copying), i, i10, j);
        }
    }

    @Override // k4.a
    public void k(File file) {
        file.getClass();
    }

    @Override // k4.a
    public void m(int i, String str, long j, long j10) {
        str.getClass();
        FileExplorerActivity fileExplorerActivity = (FileExplorerActivity) this.f67b;
        AlertDialog alertDialog = fileExplorerActivity.f5102a;
        if (alertDialog == null || alertDialog.findViewById(R.id.pb_dialog_copying) == null) {
            return;
        }
        AlertDialog alertDialog2 = fileExplorerActivity.f5102a;
        alertDialog2.getClass();
        ((ProgressBar) alertDialog2.findViewById(R.id.pb_dialog_copying)).setProgress(i);
        AlertDialog alertDialog3 = fileExplorerActivity.f5102a;
        alertDialog3.getClass();
        ((TextView) alertDialog3.findViewById(R.id.tv_size_dialog_copying)).setText(fileExplorerActivity.getString(R.string.size_of_total_size, t0.f.I(j), t0.f.I(j10)));
        AlertDialog alertDialog4 = fileExplorerActivity.f5102a;
        alertDialog4.getClass();
        ((TextView) alertDialog4.findViewById(R.id.tv_percentage_dialog_copying)).setText(i + fileExplorerActivity.getString(R.string.percentage));
        AlertDialog alertDialog5 = fileExplorerActivity.f5102a;
        alertDialog5.getClass();
        ((TextView) alertDialog5.findViewById(R.id.tv_files_dialog_copying)).setText(str);
    }

    @Override // w4.g
    public void n(String str) {
        int i = this.f66a;
        str.getClass();
        switch (i) {
            case 12:
                n5.c.e((PublicListActivity) this.f67b, str, null);
                break;
            default:
                n5.c.e((RecommendedActivity) this.f67b, str, null);
                break;
        }
    }

    public Set o() {
        Set setUnmodifiableSet;
        synchronized (((HashSet) this.f67b)) {
            setUnmodifiableSet = DesugarCollections.unmodifiableSet((HashSet) this.f67b);
        }
        return setUnmodifiableSet;
    }

    @Override // androidx.appcompat.widget.SearchView.OnQueryTextListener
    public boolean onQueryTextChange(String str) {
        str.getClass();
        d6.c cVar = (d6.c) this.f67b;
        c.g gVar = cVar.C;
        if (gVar == null) {
            l.i("switchAdapter");
            throw null;
        }
        d6.d dVar = cVar.B;
        if (dVar == null) {
            l.i("viewModel");
            throw null;
        }
        ArrayList arrayListC = dVar.c(str);
        boolean z9 = str.length() > 0;
        gVar.f1210a = arrayListC;
        if (!z9) {
            gVar.a();
        }
        gVar.notifyDataSetChanged();
        return true;
    }

    @Override // androidx.appcompat.widget.SearchView.OnQueryTextListener
    public boolean onQueryTextSubmit(String str) {
        return true;
    }

    @Override // k4.a
    public void p(File file) {
        file.getClass();
    }

    public void q(int i) {
        RepliesActivity repliesActivity = (RepliesActivity) this.f67b;
        float f = UptodownApp.J;
        if (b4.c.t()) {
            if (n1.h(repliesActivity) == null) {
                String string = repliesActivity.getString(R.string.login_required_follow_title);
                string.getClass();
                String string2 = repliesActivity.getString(R.string.login_required_follow_msg);
                string2.getClass();
                a.a.o(repliesActivity, string, string2);
                return;
            }
            if (i == -1 && repliesActivity.v0().f2334m.getValue() != null) {
                Object value = repliesActivity.v0().f2334m.getValue();
                value.getClass();
                String str = ((d1) value).f10985b;
                if (str != null && str.length() != 0) {
                    w8 w8VarV0 = repliesActivity.v0();
                    Object value2 = repliesActivity.v0().f2334m.getValue();
                    value2.getClass();
                    int i10 = ((d1) value2).f10997x;
                    Object value3 = repliesActivity.v0().f2334m.getValue();
                    value3.getClass();
                    String str2 = ((d1) value3).f10985b;
                    str2.getClass();
                    w8VarV0.a(repliesActivity, i10, str2);
                    return;
                }
            }
            if (repliesActivity.S != null) {
                w8 w8VarV02 = repliesActivity.v0();
                h0 h0Var = repliesActivity.S;
                h0Var.getClass();
                int i11 = ((x4.w0) h0Var.f4600a.get(i)).f11351u;
                h0 h0Var2 = repliesActivity.S;
                h0Var2.getClass();
                String str3 = ((x4.w0) h0Var2.f4600a.get(i)).f11342l;
                str3.getClass();
                w8VarV02.a(repliesActivity, i11, str3);
            }
        }
    }

    @Override // w4.p
    public void r() {
        UptodownApp uptodownApp = (UptodownApp) this.f67b;
        Context applicationContext = uptodownApp.getApplicationContext();
        applicationContext.getClass();
        if (n1.h(applicationContext) != null) {
            float f = UptodownApp.J;
            Context applicationContext2 = uptodownApp.getApplicationContext();
            applicationContext2.getClass();
            b4.c.B(applicationContext2);
            Context applicationContext3 = uptodownApp.getApplicationContext();
            applicationContext3.getClass();
            b4.c.C(applicationContext3);
            Context applicationContext4 = uptodownApp.getApplicationContext();
            applicationContext4.getClass();
            String string = null;
            try {
                SharedPreferences sharedPreferences = applicationContext4.getSharedPreferences("SettingsPreferences", 0);
                if (sharedPreferences.contains("fcmToken")) {
                    string = sharedPreferences.getString("fcmToken", null);
                }
            } catch (Exception e5) {
                e5.printStackTrace();
            }
            if (string != null && string.length() != 0) {
                if (b4.c.p(applicationContext4, "GetRemoteInstallWorker")) {
                    WorkManager.Companion.getInstance(applicationContext4).cancelAllWorkByTag("GetRemoteInstallWorker");
                }
            } else {
                if (b4.c.p(applicationContext4, "GetRemoteInstallWorker")) {
                    return;
                }
                WorkManager.Companion.getInstance(applicationContext4).enqueue(new PeriodicWorkRequest.Builder((Class<? extends ListenableWorker>) GetRemoteInstallWorker.class, 30L, TimeUnit.MINUTES).addTag("GetRemoteInstallWorker").setConstraints(new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()).build());
            }
        }
    }

    @Override // w4.g
    public void s(r rVar) {
        switch (this.f66a) {
            case 12:
                ((PublicListActivity) this.f67b).J0(rVar != null ? rVar.f11239b : null);
                break;
            default:
                ((RecommendedActivity) this.f67b).K0(rVar != null ? rVar.f11239b : null);
                break;
        }
    }

    @Override // w4.q
    public void t(long j, j jVar) {
        float f = UptodownApp.J;
        if (b4.c.t()) {
            WishlistActivity wishlistActivity = (WishlistActivity) this.f67b;
            LifecycleCoroutineScope lifecycleScope = LifecycleOwnerKt.getLifecycleScope(wishlistActivity);
            z7.e eVar = l0.f9082a;
            b0.r(lifecycleScope, n.f11429a, null, new g0(wishlistActivity, j, jVar, (x6.c) null, 7), 2);
        }
    }

    @Override // w4.q
    public void u(int i) {
        e1 e1Var;
        WishlistActivity wishlistActivity = (WishlistActivity) this.f67b;
        float f = UptodownApp.J;
        if (!b4.c.t() || (e1Var = wishlistActivity.f3533e0) == null || e1Var.f4570a.isEmpty()) {
            return;
        }
        e1 e1Var2 = wishlistActivity.f3533e0;
        e1Var2.getClass();
        Object obj = e1Var2.f4570a.get(i);
        obj.getClass();
        x4.t1 t1Var = (x4.t1) obj;
        j5.l(t1Var.f11294a, wishlistActivity, t1Var.f11297d);
        e1 e1Var3 = wishlistActivity.f3533e0;
        if (e1Var3 != null) {
            e1Var3.notifyItemChanged(i);
        }
    }

    @Override // k4.a
    public void v(Object obj) {
        obj.getClass();
    }

    public void w(q1.b bVar) {
        k1 k1Var = (k1) this.f67b;
        ArrayList arrayList = k1Var.f2842c;
        synchronized (arrayList) {
            for (int i = 0; i < arrayList.size(); i++) {
                try {
                    if (bVar.equals(((Pair) arrayList.get(i)).first)) {
                        Log.w("FA", "OnEventListener already registered.");
                        return;
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
            h1 h1Var = new h1(bVar);
            arrayList.add(new Pair(bVar, h1Var));
            if (k1Var.f != null) {
                try {
                    k1Var.f.registerOnMeasurementEventListener(h1Var);
                    return;
                } catch (BadParcelableException | NetworkOnMainThreadException | RemoteException | IllegalArgumentException | IllegalStateException | NullPointerException | SecurityException | UnsupportedOperationException unused) {
                    Log.w("FA", "Failed to register event listener on calling thread. Trying again on the dynamite thread.");
                }
            }
            k1Var.a(new com.google.android.gms.internal.measurement.x0(k1Var, h1Var, 5));
        }
    }

    @Override // k4.a
    public void x() {
        FileExplorerActivity fileExplorerActivity = (FileExplorerActivity) this.f67b;
        fileExplorerActivity.f3546f0 = null;
        fileExplorerActivity.U();
        fileExplorerActivity.W(true);
        AlertDialog alertDialog = fileExplorerActivity.f5102a;
        if (alertDialog != null) {
            alertDialog.dismiss();
        }
        fileExplorerActivity.f5102a = null;
    }

    @Override // w4.g
    public void y(String str) {
        switch (this.f66a) {
            case 12:
                ((PublicListActivity) this.f67b).N(str);
                break;
            default:
                ((RecommendedActivity) this.f67b).N(str);
                break;
        }
    }

    public void z() {
        f4 f4Var = (f4) this.f67b;
        f4Var.g();
        t1 t1Var = f4Var.f3925a;
        g1 g1Var = t1Var.f4313n;
        t1.k(g1Var);
        t1Var.f4319t.getClass();
        if (g1Var.q(System.currentTimeMillis())) {
            g1 g1Var2 = t1Var.f4313n;
            t1.k(g1Var2);
            g1Var2.f4040u.b(true);
            ActivityManager.RunningAppProcessInfo runningAppProcessInfo = new ActivityManager.RunningAppProcessInfo();
            ActivityManager.getMyMemoryState(runningAppProcessInfo);
            if (runningAppProcessInfo.importance == 100) {
                w0 w0Var = t1Var.f4314o;
                t1.m(w0Var);
                w0Var.f4395w.b("Detected application was in foreground");
                C(System.currentTimeMillis());
            }
        }
    }

    @Override // k4.a
    public void g(DocumentFile documentFile) {
    }

    @Override // k4.a
    public void l(DocumentFile documentFile) {
    }

    public /* synthetic */ d(Object obj, int i) {
        this.f66a = i;
        this.f67b = obj;
    }

    public d() {
        this.f66a = 0;
        this.f67b = new HashSet();
    }
}
