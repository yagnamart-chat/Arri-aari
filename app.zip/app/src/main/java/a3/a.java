package a3;

import a4.x;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public final class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f60a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String f61b;

    public a(String str, String str2) {
        this.f60a = str;
        if (str2 != null) {
            this.f61b = str2;
        } else {
            com.google.android.material.drawable.a.j("Null version");
            throw null;
        }
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof a)) {
            return false;
        }
        a aVar = (a) obj;
        return this.f60a.equals(aVar.f60a) && this.f61b.equals(aVar.f61b);
    }

    public final int hashCode() {
        return ((this.f60a.hashCode() ^ 1000003) * 1000003) ^ this.f61b.hashCode();
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("LibraryVersion{libraryName=");
        sb.append(this.f60a);
        sb.append(", version=");
        return x.n(sb, this.f61b, "}");
    }
}
