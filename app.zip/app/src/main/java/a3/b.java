package a3;

import a4.d0;
import android.window.OnBackInvokedDispatcher;
import androidx.constraintlayout.core.state.Interpolator;
import androidx.constraintlayout.core.state.Transition;
import java.io.EOFException;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ConcurrentModificationException;
import java.util.NoSuchElementException;
import java.util.Set;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public final /* synthetic */ class b implements s1.d, Interpolator {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f62a;

    public /* synthetic */ b(int i) {
        this.f62a = i;
    }

    public static /* bridge */ /* synthetic */ OnBackInvokedDispatcher d(Object obj) {
        return (OnBackInvokedDispatcher) obj;
    }

    public static /* synthetic */ void e() throws EOFException {
        throw new EOFException();
    }

    public static /* synthetic */ void f(int i, int i10, int i11) {
        throw new IndexOutOfBoundsException("Start (" + i + ((Object) ") and end (") + i10 + ((Object) ") must be in 0..") + i11);
    }

    public static /* synthetic */ void g(int i, int i10, Object obj, String str) {
        throw new IllegalArgumentException((str + i + obj + i10).toString());
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static /* synthetic */ void h(int i, int i10, String str) {
        throw new IllegalArgumentException((str + i + ((char) i10)).toString());
    }

    public static /* synthetic */ void j(Object obj) {
        throw new AssertionError(obj);
    }

    public static /* synthetic */ void k(Object obj, String str) {
        throw new IllegalStateException(str + obj);
    }

    public static /* synthetic */ void l(Object obj, String str, Object obj2) {
        throw new NoSuchElementException(str + obj + obj2);
    }

    public static /* synthetic */ void m(String str) {
        throw new RuntimeException(str);
    }

    public static /* synthetic */ void n(String str, float f, Object obj) {
        throw new IllegalArgumentException(str + f + obj);
    }

    public static /* synthetic */ void p() {
        throw new IllegalArgumentException();
    }

    public static /* synthetic */ void q(Object obj) {
        throw new IllegalArgumentException(obj.toString());
    }

    public static /* synthetic */ void r(Object obj, String str) throws IOException {
        throw new IOException(str + obj);
    }

    public static /* synthetic */ void s(String str) {
        throw new UnsupportedOperationException(str);
    }

    public static /* synthetic */ void u() {
        throw new ConcurrentModificationException();
    }

    public static /* synthetic */ void v(Object obj, String str) throws FileNotFoundException {
        throw new FileNotFoundException(str + obj);
    }

    @Override // s1.d
    public Object c(d0 d0Var) {
        Set setP = d0Var.p(a.class);
        d dVar = d.f65l;
        if (dVar == null) {
            synchronized (d.class) {
                try {
                    dVar = d.f65l;
                    if (dVar == null) {
                        dVar = new d();
                        d.f65l = dVar;
                    }
                } finally {
                }
            }
        }
        return new c(setP, dVar);
    }

    @Override // androidx.constraintlayout.core.state.Interpolator
    public float getInterpolation(float f) {
        switch (this.f62a) {
            case 28:
                return Transition.lambda$getInterpolator$1(f);
            default:
                return Transition.lambda$getInterpolator$2(f);
        }
    }
}
