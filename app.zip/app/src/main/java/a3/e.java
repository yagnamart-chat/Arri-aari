package a3;

import a4.d0;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.os.Trace;
import androidx.collection.ArrayMap;
import androidx.concurrent.futures.CallbackToFutureAdapter;
import androidx.fragment.app.FragmentActivity;
import androidx.leanback.widget.Action;
import androidx.leanback.widget.OnActionClickedListener;
import androidx.lifecycle.LifecycleCoroutineScope;
import androidx.lifecycle.LifecycleOwnerKt;
import androidx.privacysandbox.ads.adservices.java.internal.CoroutineAdapterKt;
import androidx.work.WorkerKt;
import c4.za;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.uptodown.UptodownApp;
import com.uptodown.activities.MoreInfo;
import com.uptodown.tv.ui.activity.TvOldVersionsActivity;
import com.uptodown.tv.ui.fragment.TvAppDetailFragment;
import j1.p;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.ListIterator;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Executor;
import s7.b0;
import s7.e0;
import s7.l0;
import y.g;
import y.h;
import y2.j;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public final /* synthetic */ class e implements s1.d, CallbackToFutureAdapter.Resolver, OnActionClickedListener, s2.a, z.b, y.f, j1.d, j1.a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f68a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f69b;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ Object f70l;

    public /* synthetic */ e(j jVar, String str) {
        this.f68a = 10;
        this.f70l = jVar;
        this.f69b = str;
    }

    @Override // y.f
    public Object apply(Object obj) {
        h hVar = (h) this.f69b;
        r.j jVar = (r.j) this.f70l;
        SQLiteDatabase sQLiteDatabase = (SQLiteDatabase) obj;
        y.a aVar = hVar.f11468m;
        ArrayList arrayListE = hVar.e(sQLiteDatabase, jVar, aVar.f11453b);
        for (o.d dVar : o.d.values()) {
            if (dVar != jVar.f8613c) {
                int size = aVar.f11453b - arrayListE.size();
                if (size <= 0) {
                    break;
                }
                arrayListE.addAll(hVar.e(sQLiteDatabase, jVar.a(dVar), size));
            }
        }
        HashMap map = new HashMap();
        StringBuilder sb = new StringBuilder("event_id IN (");
        for (int i = 0; i < arrayListE.size(); i++) {
            sb.append(((y.b) arrayListE.get(i)).f11457a);
            if (i < arrayListE.size() - 1) {
                sb.append(',');
            }
        }
        sb.append(')');
        Cursor cursorQuery = sQLiteDatabase.query("event_metadata", new String[]{"event_id", "name", "value"}, sb.toString(), null, null, null, null);
        while (cursorQuery.moveToNext()) {
            try {
                long j = cursorQuery.getLong(0);
                Set hashSet = (Set) map.get(Long.valueOf(j));
                if (hashSet == null) {
                    hashSet = new HashSet();
                    map.put(Long.valueOf(j), hashSet);
                }
                hashSet.add(new g(cursorQuery.getString(1), cursorQuery.getString(2)));
            } catch (Throwable th) {
                cursorQuery.close();
                throw th;
            }
        }
        cursorQuery.close();
        ListIterator listIterator = arrayListE.listIterator();
        while (listIterator.hasNext()) {
            y.b bVar = (y.b) listIterator.next();
            long j10 = bVar.f11457a;
            if (map.containsKey(Long.valueOf(j10))) {
                r.h hVarC = bVar.f11459c.c();
                for (g gVar : (Set) map.get(Long.valueOf(j10))) {
                    hVarC.a(gVar.f11462a, gVar.f11463b);
                }
                listIterator.set(new y.b(j10, bVar.f11458b, hVarC.b()));
            }
        }
        return arrayListE;
    }

    @Override // androidx.concurrent.futures.CallbackToFutureAdapter.Resolver
    public Object attachCompleter(CallbackToFutureAdapter.Completer completer) {
        switch (this.f68a) {
            case 1:
                return CoroutineAdapterKt.asListenableFuture$lambda$0((e0) this.f69b, this.f70l, completer);
            default:
                return WorkerKt.future$lambda$2((Executor) this.f69b, (h7.a) this.f70l, completer);
        }
    }

    @Override // s2.a
    public void b(s2.b bVar) {
        s2.a aVar = (s2.a) this.f69b;
        s2.a aVar2 = (s2.a) this.f70l;
        aVar.b(bVar);
        aVar2.b(bVar);
    }

    @Override // s1.d
    public Object c(d0 d0Var) {
        switch (this.f68a) {
            case 0:
                return new a((String) this.f69b, ((f) this.f70l).a((Context) d0Var.a(Context.class)));
            default:
                String str = (String) this.f69b;
                s1.a aVar = (s1.a) this.f70l;
                try {
                    Trace.beginSection(str);
                    return aVar.f.c(d0Var);
                } finally {
                    Trace.endSection();
                }
        }
    }

    @Override // j1.a
    public Object e(p pVar) {
        j jVar = (j) this.f70l;
        String str = (String) this.f69b;
        synchronized (jVar) {
            ((ArrayMap) jVar.f11617b).remove(str);
        }
        return pVar;
    }

    @Override // z.b
    public Object execute() {
        switch (this.f68a) {
            case 6:
                x.h hVar = (x.h) this.f69b;
                Iterable iterable = (Iterable) this.f70l;
                h hVar2 = (h) hVar.f10944c;
                hVar2.getClass();
                if (iterable.iterator().hasNext()) {
                    hVar2.b().compileStatement("DELETE FROM events WHERE _id in ".concat(h.j(iterable))).execute();
                    break;
                }
                break;
            default:
                x.h hVar3 = (x.h) this.f69b;
                for (Map.Entry entry : ((HashMap) this.f70l).entrySet()) {
                    ((h) hVar3.i).g(((Integer) entry.getValue()).intValue(), u.c.INVALID_PAYLOD, (String) entry.getKey());
                }
                break;
        }
        return null;
    }

    @Override // androidx.leanback.widget.OnActionClickedListener
    public void onActionClicked(Action action) {
        TvAppDetailFragment tvAppDetailFragment = (TvAppDetailFragment) this.f69b;
        FragmentActivity fragmentActivity = (FragmentActivity) this.f70l;
        action.getClass();
        if (action.getId() == 1) {
            int i = tvAppDetailFragment.f3578l;
            if (i != 0) {
                if (i == 1) {
                    tvAppDetailFragment.g();
                    return;
                }
                if (i == 2) {
                    tvAppDetailFragment.g();
                    return;
                }
                if (i == 3) {
                    tvAppDetailFragment.b();
                    return;
                } else if (i == 5) {
                    tvAppDetailFragment.g();
                    return;
                } else {
                    if (i != 6) {
                        return;
                    }
                    tvAppDetailFragment.g();
                    return;
                }
            }
            x4.g gVar = tvAppDetailFragment.f3576a;
            if (gVar == null || gVar.F == null || tvAppDetailFragment.getContext() == null) {
                return;
            }
            PackageManager packageManager = tvAppDetailFragment.requireContext().getPackageManager();
            x4.g gVar2 = tvAppDetailFragment.f3576a;
            gVar2.getClass();
            String str = gVar2.F;
            str.getClass();
            Intent leanbackLaunchIntentForPackage = packageManager.getLeanbackLaunchIntentForPackage(str);
            if (leanbackLaunchIntentForPackage == null) {
                PackageManager packageManager2 = tvAppDetailFragment.requireContext().getPackageManager();
                x4.g gVar3 = tvAppDetailFragment.f3576a;
                gVar3.getClass();
                String str2 = gVar3.F;
                str2.getClass();
                leanbackLaunchIntentForPackage = packageManager2.getLaunchIntentForPackage(str2);
            }
            if (leanbackLaunchIntentForPackage != null) {
                tvAppDetailFragment.startActivity(leanbackLaunchIntentForPackage);
                return;
            }
            return;
        }
        if (action.getId() == 2) {
            x4.g gVar4 = tvAppDetailFragment.f3576a;
            if (gVar4 == null || gVar4.F == null) {
                return;
            }
            Context contextRequireContext = tvAppDetailFragment.requireContext();
            contextRequireContext.getClass();
            x4.g gVar5 = tvAppDetailFragment.f3576a;
            gVar5.getClass();
            String str3 = gVar5.F;
            str3.getClass();
            Intent intent = new Intent("android.intent.action.DELETE", Uri.parse("package:".concat(str3)));
            intent.addFlags(268435456);
            contextRequireContext.startActivity(intent);
            return;
        }
        if (action.getId() == 3) {
            if (tvAppDetailFragment.f3576a != null) {
                Intent intent2 = new Intent(fragmentActivity, (Class<?>) TvOldVersionsActivity.class);
                intent2.putExtra("appInfo", tvAppDetailFragment.f3576a);
                float f = UptodownApp.J;
                tvAppDetailFragment.startActivity(intent2, b4.c.a(fragmentActivity));
                return;
            }
            return;
        }
        Bundle bundleA = null;
        byte b10 = 0;
        if (action.getId() == 4) {
            if (tvAppDetailFragment.f3576a != null) {
                LifecycleCoroutineScope lifecycleScope = LifecycleOwnerKt.getLifecycleScope(tvAppDetailFragment);
                z7.e eVar = l0.f9082a;
                b0.r(lifecycleScope, z7.d.f11887a, null, new za((Object) fragmentActivity, (Object) tvAppDetailFragment, (x6.c) (b10 == true ? 1 : 0), 20), 2);
                return;
            }
            return;
        }
        if (action.getId() != 5 || tvAppDetailFragment.f3576a == null) {
            return;
        }
        Intent intent3 = new Intent(tvAppDetailFragment.getContext(), (Class<?>) MoreInfo.class);
        intent3.putExtra("appInfo", tvAppDetailFragment.f3576a);
        FragmentActivity activity = tvAppDetailFragment.getActivity();
        if (activity != null) {
            float f7 = UptodownApp.J;
            bundleA = b4.c.a(activity);
        }
        tvAppDetailFragment.startActivity(intent3, bundleA);
    }

    @Override // j1.d
    public void q(p pVar) {
        ((FirebaseMessagingService) this.f69b).a((Intent) this.f70l);
    }

    public /* synthetic */ e(int i, Object obj, Object obj2) {
        this.f68a = i;
        this.f69b = obj;
        this.f70l = obj2;
    }
}
