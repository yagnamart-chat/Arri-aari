package a3;

import j$.util.DesugarCollections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public final class c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f63a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final d f64b;

    public c(Set set, d dVar) {
        this.f63a = b(set);
        this.f64b = dVar;
    }

    public static String b(Set set) {
        StringBuilder sb = new StringBuilder();
        Iterator it = set.iterator();
        while (it.hasNext()) {
            a aVar = (a) it.next();
            sb.append(aVar.f60a);
            sb.append('/');
            sb.append(aVar.f61b);
            if (it.hasNext()) {
                sb.append(' ');
            }
        }
        return sb.toString();
    }

    public final String a() {
        Set setUnmodifiableSet;
        d dVar = this.f64b;
        synchronized (((HashSet) dVar.f67b)) {
            setUnmodifiableSet = DesugarCollections.unmodifiableSet((HashSet) dVar.f67b);
        }
        boolean zIsEmpty = setUnmodifiableSet.isEmpty();
        String str = this.f63a;
        if (zIsEmpty) {
            return str;
        }
        return str + ' ' + b(dVar.o());
    }
}
