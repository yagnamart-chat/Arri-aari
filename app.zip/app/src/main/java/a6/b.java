package a6;

import b2.t1;
import h7.p;
import java.util.List;
import java.util.Set;
import kotlin.jvm.internal.l;
import kotlin.jvm.internal.m;
import kotlin.jvm.internal.x;
import y5.g;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public final class b extends m implements p {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f202a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ x f203b;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ b(x xVar, int i) {
        super(2);
        this.f202a = i;
        this.f203b = xVar;
    }

    /* JADX WARN: Type inference failed for: r10v5, types: [java.lang.Object, java.util.Map] */
    /* JADX WARN: Type inference failed for: r4v12, types: [java.lang.Object, java.util.Map] */
    /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Object, java.util.Map] */
    @Override // h7.p
    public final Object invoke(Object obj, Object obj2) throws e {
        int i = this.f202a;
        t6.x xVar = t6.x.f9993a;
        x xVar2 = this.f203b;
        switch (i) {
            case 0:
                int iIntValue = ((Number) obj).intValue();
                boolean zBooleanValue = ((Boolean) obj2).booleanValue();
                if (iIntValue > 0 && iIntValue <= p7.m.g0((CharSequence) xVar2.f6892a) + 1) {
                    StringBuilder sb = new StringBuilder((String) xVar2.f6892a);
                    sb.setCharAt(iIntValue - 1, zBooleanValue ? '1' : '0');
                    xVar2.f6892a = sb.toString();
                }
                break;
            default:
                String str = (String) obj;
                Set set = (Set) obj2;
                str.getClass();
                set.getClass();
                g gVarD = a.a.d(str);
                String str2 = (String) xVar2.f6892a;
                Integer numValueOf = Integer.valueOf(gVarD.f11709a);
                Object obj3 = c.f204a;
                ?? r52 = c.f205b;
                Integer num = (Integer) r52.get(d.f213p);
                String strG = l.g(t1.c(numValueOf, num == null ? 0 : num.intValue()), str2);
                xVar2.f6892a = strG;
                Integer numValueOf2 = Integer.valueOf(gVarD.f11710b.f11719a);
                Integer num2 = (Integer) r52.get(d.f214q);
                xVar2.f6892a = l.g(t1.c(numValueOf2, num2 == null ? 0 : num2.intValue()), strG);
                List listO0 = u6.l.o0(set);
                int size = listO0.size();
                String strG2 = "";
                int i10 = 0;
                int i11 = 0;
                int i12 = 0;
                while (i10 < size) {
                    int i13 = i10 + 1;
                    int iIntValue2 = ((Number) listO0.get(i10)).intValue();
                    if (i12 == 0) {
                        i11++;
                        i12 = iIntValue2;
                    }
                    if (i10 == listO0.size() - 1 || ((Number) listO0.get(i13)).intValue() > iIntValue2 + 1) {
                        boolean z9 = iIntValue2 != i12;
                        String strG3 = l.g(z9 ? "1" : "0", strG2);
                        Integer numValueOf3 = Integer.valueOf(i12);
                        Object obj4 = c.f204a;
                        ?? r10 = c.f205b;
                        d dVar = d.f217t;
                        Integer num3 = (Integer) r10.get(dVar);
                        strG2 = l.g(t1.c(numValueOf3, num3 == null ? 0 : num3.intValue()), strG3);
                        if (z9) {
                            Integer numValueOf4 = Integer.valueOf(iIntValue2);
                            Integer num4 = (Integer) r10.get(dVar);
                            strG2 = l.g(t1.c(numValueOf4, num4 == null ? 0 : num4.intValue()), strG2);
                        }
                        i12 = 0;
                    }
                    i10 = i13;
                }
                String str3 = (String) xVar2.f6892a;
                Integer numValueOf5 = Integer.valueOf(i11);
                Object obj5 = c.f204a;
                Integer num5 = (Integer) c.f205b.get(d.f211n);
                String strG4 = l.g(t1.c(numValueOf5, num5 != null ? num5.intValue() : 0), str3);
                xVar2.f6892a = strG4;
                xVar2.f6892a = l.g(strG2, strG4);
                break;
        }
        return xVar;
    }
}
