package a6;

import java.util.ArrayList;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public final class f {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ArrayList f219a;

    public f(ArrayList arrayList) {
        this.f219a = arrayList;
    }

    public final boolean equals(Object obj) {
        Object obj2 = 2;
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof f)) {
            return false;
        }
        f fVar = (f) obj;
        Object obj3 = Boolean.TRUE;
        return obj3.equals(obj3) && obj2.equals(obj2) && this.f219a.equals(fVar.f219a);
    }

    public final int hashCode() {
        Integer num = 2;
        return this.f219a.hashCode() + ((num.hashCode() + (Boolean.TRUE.hashCode() * 31)) * 31);
    }

    public final String toString() {
        return "EncodingOptions(isForVendors=" + Boolean.TRUE + ", version=" + ((Object) 2) + ", segments=" + this.f219a + ')';
    }
}
