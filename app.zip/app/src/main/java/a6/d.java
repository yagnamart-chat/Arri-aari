package a6;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public final class d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final d f207a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final d f208b;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public static final d f209l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public static final d f210m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public static final d f211n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public static final d f212o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public static final d f213p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public static final d f214q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public static final d f215r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public static final d f216s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public static final d f217t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public static final /* synthetic */ d[] f218u;

    static {
        d dVar = new d("ANY_BOOLEAN", 0);
        f207a = dVar;
        d dVar2 = new d("ENCODING_TYPE", 1);
        f208b = dVar2;
        d dVar3 = new d("MAX_ID", 2);
        f209l = dVar3;
        d dVar4 = new d("NUM_CUSTOM_PURPOSES", 3);
        f210m = dVar4;
        d dVar5 = new d("NUM_ENTRIES", 4);
        f211n = dVar5;
        d dVar6 = new d("NUM_RESTRICTIONS", 5);
        f212o = dVar6;
        d dVar7 = new d("PURPOSE_ID", 6);
        f213p = dVar7;
        d dVar8 = new d("RESTRICTION_TYPE", 7);
        f214q = dVar8;
        d dVar9 = new d("SEGMENT_TYPE", 8);
        f215r = dVar9;
        d dVar10 = new d("SINGLE_OR_RANGE", 9);
        f216s = dVar10;
        d dVar11 = new d("VENDOR_ID", 10);
        f217t = dVar11;
        f218u = new d[]{dVar, dVar2, dVar3, dVar4, dVar5, dVar6, dVar7, dVar8, dVar9, dVar10, dVar11};
    }

    public static d valueOf(String str) {
        return (d) Enum.valueOf(d.class, str);
    }

    public static d[] values() {
        return (d[]) f218u.clone();
    }
}
