package a6;

import t6.i;
import u6.a0;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public abstract class c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final Object f204a = a0.L(new i(y5.a.f11686l, 12), new i(y5.a.f11687m, 12), new i(y5.a.f11689o, 12), new i(y5.a.f11688n, 6), new i(y5.a.f11684a, 36), new i(y5.a.f11692r, 1), new i(y5.a.f11685b, 36), new i(y5.a.f11691q, 6), new i(y5.a.f11696w, 12), new i(y5.a.D, 24), new i(y5.a.E, 24), new i(y5.a.f11699z, 36), new i(y5.a.f11695u, 24), new i(y5.a.F, 24), new i(y5.a.v, 1), new i(y5.a.f11694t, 12), new i(y5.a.f11693s, 1), new i(y5.a.f11697x, 24), new i(y5.a.f11698y, 24), new i(y5.a.f11690p, 12), new i(y5.a.I, 6));

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final Object f205b = a0.L(new i(d.f207a, 1), new i(d.f208b, 1), new i(d.f209l, 16), new i(d.f210m, 6), new i(d.f211n, 12), new i(d.f212o, 12), new i(d.f213p, 6), new i(d.f214q, 2), new i(d.f215r, 3), new i(d.f216s, 1), new i(d.f217t, 16));

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final Object f206c = a0.L(new i("cmpId", 12), new i("cmpVersion", 12), new i("consentLanguage", 12), new i("consentScreen", 6), new i("created", 36), new i("isServiceSpecific", 1), new i("lastUpdated", 36), new i("policyVersion", 6), new i("publisherCountryCode", 12), new i("publisherLegitimateInterests", 24), new i("publisherConsents", 24), new i("publisherRestrictions", 36), new i("purposeConsents", 24), new i("purposeLegitimateInterests", 24), new i("purposeOneTreatment", 1), new i("specialFeatureOptions", 12), new i("useNonStandardStacks", 1), new i("vendorListVersion", 12), new i("vendorConsents", 24), new i("vendorLegitimateInterests", 24), new i("version", 6), new i("anyBoolean", 1), new i("encodingType", 1), new i("maxId", 16), new i("numCustomPurposes", 6), new i("numEntries", 12), new i("numRestrictions", 12), new i("purposeId", 6), new i("restrictionType", 2), new i("segmentType", 3), new i("singleOrRange", 1), new i("vendorId", 16));
}
