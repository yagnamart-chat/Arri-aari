package a2;

import android.util.Log;
import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.Locale;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public final class o implements d {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public static final Charset f43l = Charset.forName("UTF-8");

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final File f44a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public m f45b;

    public o(File file) {
        this.f44a = file;
    }

    public final void a() {
        File file = this.f44a;
        if (this.f45b == null) {
            try {
                this.f45b = new m(file);
            } catch (IOException e5) {
                Log.e("FirebaseCrashlytics", "Could not open log file: " + file, e5);
            }
        }
    }

    @Override // a2.d
    public final void b() {
        y1.g.b(this.f45b, "There was a problem closing the Crashlytics log file.");
        this.f45b = null;
    }

    /* JADX WARN: Removed duplicated region for block: B:4:0x000a  */
    @Override // a2.d
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.String c() {
        /*
            r7 = this;
            java.io.File r0 = r7.f44a
            boolean r0 = r0.exists()
            r1 = 0
            r2 = 0
            if (r0 != 0) goto Lc
        La:
            r4 = r2
            goto L38
        Lc:
            r7.a()
            a2.m r0 = r7.f45b
            if (r0 != 0) goto L14
            goto La
        L14:
            int[] r3 = new int[]{r1}
            int r0 = r0.r()
            byte[] r0 = new byte[r0]
            a2.m r4 = r7.f45b     // Catch: java.io.IOException -> L29
            a2.f r5 = new a2.f     // Catch: java.io.IOException -> L29
            r5.<init>(r0, r3)     // Catch: java.io.IOException -> L29
            r4.e(r5)     // Catch: java.io.IOException -> L29
            goto L31
        L29:
            r4 = move-exception
            java.lang.String r5 = "A problem occurred while reading the Crashlytics log file."
            java.lang.String r6 = "FirebaseCrashlytics"
            android.util.Log.e(r6, r5, r4)
        L31:
            a2.n r4 = new a2.n
            r3 = r3[r1]
            r4.<init>(r0, r3)
        L38:
            if (r4 != 0) goto L3c
            r3 = r2
            goto L45
        L3c:
            int r0 = r4.f42b
            byte[] r3 = new byte[r0]
            byte[] r4 = r4.f41a
            java.lang.System.arraycopy(r4, r1, r3, r1, r0)
        L45:
            if (r3 == 0) goto L4f
            java.lang.String r0 = new java.lang.String
            java.nio.charset.Charset r1 = a2.o.f43l
            r0.<init>(r3, r1)
            return r0
        L4f:
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: a2.o.c():java.lang.String");
    }

    @Override // a2.d
    public final void e(long j, String str) {
        a();
        if (this.f45b == null) {
            return;
        }
        try {
            if (str.length() > 16384) {
                str = "...".concat(str.substring(str.length() - 16384));
            }
            this.f45b.b(String.format(Locale.US, "%d %s%n", Long.valueOf(j), str.replaceAll("\r", " ").replaceAll("\n", " ")).getBytes(f43l));
            while (!this.f45b.g() && this.f45b.r() > 65536) {
                this.f45b.n();
            }
        } catch (IOException e5) {
            Log.e("FirebaseCrashlytics", "There was a problem writing to the Crashlytics log.", e5);
        }
    }
}
