package a2;

import android.util.Log;
import android.view.animation.Animation;
import android.widget.ImageView;
import androidx.work.Configuration;
import androidx.work.impl.Schedulers;
import androidx.work.impl.WorkDatabase;
import androidx.work.impl.model.WorkGenerationalId;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicMarkableReference;
import java.util.logging.Logger;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public final /* synthetic */ class r implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f49a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f50b;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ Object f51l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ Object f52m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final /* synthetic */ Object f53n;

    public /* synthetic */ r(List list, WorkGenerationalId workGenerationalId, Configuration configuration, WorkDatabase workDatabase) {
        this.f49a = 1;
        this.f50b = list;
        this.f51l = workGenerationalId;
        this.f52m = configuration;
        this.f53n = workDatabase;
    }

    @Override // java.lang.Runnable
    public final void run() throws Throwable {
        BufferedWriter bufferedWriter;
        String string;
        switch (this.f49a) {
            case 0:
                e2.d dVar = (e2.d) this.f51l;
                String str = (String) this.f52m;
                Map map = (Map) this.f53n;
                List list = (List) this.f50b;
                h hVar = (h) dVar.f4516l;
                AtomicMarkableReference atomicMarkableReference = (AtomicMarkableReference) dVar.f4521q;
                BufferedWriter bufferedWriter2 = null;
                if (((String) atomicMarkableReference.getReference()) != null) {
                    String str2 = (String) atomicMarkableReference.getReference();
                    File fileH = hVar.f25a.h(str, "user-data");
                    try {
                        g gVar = new g();
                        gVar.put("userId", str2);
                        string = gVar.toString();
                        bufferedWriter = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(fileH), h.f24b));
                    } catch (Exception e5) {
                        e = e5;
                        bufferedWriter = null;
                    } catch (Throwable th) {
                        th = th;
                        y1.g.b(bufferedWriter2, "Failed to close user metadata file.");
                        throw th;
                    }
                    try {
                        try {
                            bufferedWriter.write(string);
                            bufferedWriter.flush();
                        } catch (Throwable th2) {
                            th = th2;
                            bufferedWriter2 = bufferedWriter;
                            y1.g.b(bufferedWriter2, "Failed to close user metadata file.");
                            throw th;
                        }
                    } catch (Exception e8) {
                        e = e8;
                        Log.w("FirebaseCrashlytics", "Error serializing user metadata.", e);
                    }
                    y1.g.b(bufferedWriter, "Failed to close user metadata file.");
                }
                if (!map.isEmpty()) {
                    hVar.h(str, map, false);
                }
                if (list.isEmpty()) {
                    return;
                }
                File fileH2 = hVar.f25a.h(str, "rollouts-state");
                if (list.isEmpty()) {
                    h.g(fileH2, "Rollout state is empty for session: " + str);
                    return;
                }
                try {
                    try {
                        String strE = h.e(list);
                        BufferedWriter bufferedWriter3 = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(fileH2), h.f24b));
                        try {
                            bufferedWriter3.write(strE);
                            bufferedWriter3.flush();
                            y1.g.b(bufferedWriter3, "Failed to close rollouts state file.");
                            return;
                        } catch (Exception e10) {
                            e = e10;
                            bufferedWriter2 = bufferedWriter3;
                            Log.w("FirebaseCrashlytics", "Error serializing rollouts state.", e);
                            h.f(fileH2);
                            y1.g.b(bufferedWriter2, "Failed to close rollouts state file.");
                            return;
                        } catch (Throwable th3) {
                            th = th3;
                            bufferedWriter2 = bufferedWriter3;
                            y1.g.b(bufferedWriter2, "Failed to close rollouts state file.");
                            throw th;
                        }
                    } catch (Throwable th4) {
                        th = th4;
                    }
                } catch (Exception e11) {
                    e = e11;
                }
                break;
            case 1:
                Schedulers.lambda$registerRescheduling$0((List) this.f50b, (WorkGenerationalId) this.f51l, (Configuration) this.f52m, (WorkDatabase) this.f53n);
                return;
            case 2:
                ImageView imageView = (ImageView) this.f51l;
                Animation animation = (Animation) this.f52m;
                ImageView imageView2 = (ImageView) this.f53n;
                Animation animation2 = (Animation) this.f50b;
                imageView.startAnimation(animation);
                imageView2.startAnimation(animation2);
                return;
            default:
                w.a aVar = (w.a) this.f51l;
                r.j jVar = (r.j) this.f52m;
                String str3 = jVar.f8611a;
                o.g gVar2 = (o.g) this.f53n;
                r.i iVar = (r.i) this.f50b;
                aVar.getClass();
                Logger logger = w.a.f;
                try {
                    s.e eVarA = aVar.f10762c.a(str3);
                    if (eVarA == null) {
                        String str4 = "Transport backend '" + str3 + "' is not registered";
                        logger.warning(str4);
                        gVar2.d(new IllegalArgumentException(str4));
                    } else {
                        ((y.h) aVar.f10764e).h(new androidx.transition.a(aVar, jVar, ((p.c) eVarA).a(iVar), 3));
                        gVar2.d(null);
                    }
                    return;
                } catch (Exception e12) {
                    logger.warning("Error scheduling event " + e12.getMessage());
                    gVar2.d(e12);
                    return;
                }
        }
    }

    public /* synthetic */ r(Object obj, Object obj2, Object obj3, Object obj4, int i) {
        this.f49a = i;
        this.f51l = obj;
        this.f52m = obj2;
        this.f53n = obj3;
        this.f50b = obj4;
    }
}
