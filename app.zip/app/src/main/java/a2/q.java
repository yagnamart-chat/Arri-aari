package a2;

import j$.util.DesugarCollections;
import java.util.ArrayList;
import java.util.List;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public final class q {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ArrayList f47a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f48b;

    public q() {
        this.f47a = new ArrayList();
        this.f48b = 128;
    }

    public synchronized List a() {
        return DesugarCollections.unmodifiableList(new ArrayList(this.f47a));
    }

    public q(ArrayList arrayList) {
        this.f48b = 0;
        this.f47a = arrayList;
    }
}
