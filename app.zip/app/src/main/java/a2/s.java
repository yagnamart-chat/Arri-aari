package a2;

import a4.d0;
import android.content.SharedPreferences;
import android.util.Log;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.constraintlayout.helper.widget.Carousel;
import androidx.room.RoomTrackingLiveData;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import androidx.work.ListenableFutureKt;
import c4.a8;
import c4.qd;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.carousel.CarouselLayoutManager;
import com.google.android.material.motion.MaterialBackOrchestrator;
import com.uptodown.R;
import com.uptodown.activities.AppInstalledDetailsActivity;
import com.uptodown.activities.OldVersionsActivity;
import com.uptodown.activities.RecommendedActivity;
import com.uptodown.activities.WishlistActivity;
import com.uptodown.core.activities.FileExplorerActivity;
import com.uptodown.tv.ui.fragment.TvMyAppsFragment;
import com.uptodown.tv.ui.fragment.TvOldVersionsFragment;
import java.util.ArrayDeque;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.atomic.AtomicMarkableReference;
import java.util.concurrent.atomic.AtomicReference;
import q5.p1;
import q5.q1;
import s7.d1;
import y2.c0;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public final /* synthetic */ class s implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f54a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f55b;

    public /* synthetic */ s(Object obj, int i) {
        this.f54a = i;
        this.f55b = obj;
    }

    private final void a() {
        d0 d0Var = (d0) this.f55b;
        synchronized (((ArrayDeque) d0Var.f88n)) {
            SharedPreferences.Editor editorEdit = ((SharedPreferences) d0Var.f85b).edit();
            String str = (String) d0Var.f86l;
            StringBuilder sb = new StringBuilder();
            Iterator it = ((ArrayDeque) d0Var.f88n).iterator();
            while (it.hasNext()) {
                sb.append((String) it.next());
                sb.append((String) d0Var.f87m);
            }
            editorEdit.putString(str, sb.toString()).commit();
        }
    }

    @Override // java.lang.Runnable
    public final void run() {
        int i = 2;
        int i10 = 1;
        Map mapA = null;
        int i11 = 0;
        switch (this.f54a) {
            case 0:
                t tVar = (t) this.f55b;
                ((AtomicReference) tVar.f58c).set(null);
                synchronized (tVar) {
                    try {
                        if (((AtomicMarkableReference) tVar.f57b).isMarked()) {
                            mapA = ((e) ((AtomicMarkableReference) tVar.f57b).getReference()).a();
                            AtomicMarkableReference atomicMarkableReference = (AtomicMarkableReference) tVar.f57b;
                            atomicMarkableReference.set((e) atomicMarkableReference.getReference(), false);
                        }
                    } catch (Throwable th) {
                        throw th;
                    }
                    break;
                }
                if (mapA != null) {
                    e2.d dVar = (e2.d) tVar.f59d;
                    ((h) dVar.f4516l).h((String) dVar.f4515b, mapA, tVar.f56a);
                    return;
                }
                return;
            case 1:
                ((Carousel) this.f55b).lambda$updateItems$0();
                return;
            case 2:
                RoomTrackingLiveData.access$invalidated((RoomTrackingLiveData) this.f55b);
                return;
            case 3:
                ((SwipeRefreshLayout) this.f55b).lambda$onStopNestedScroll$0();
                return;
            case 4:
                ListenableFutureKt.launchFuture$lambda$1$lambda$0((d1) this.f55b);
                return;
            case 5:
                AppInstalledDetailsActivity appInstalledDetailsActivity = (AppInstalledDetailsActivity) this.f55b;
                int i12 = AppInstalledDetailsActivity.f3456g0;
                appInstalledDetailsActivity.L0().F.smoothScrollTo(0, appInstalledDetailsActivity.L0().f9454x.getTop());
                return;
            case 6:
                OldVersionsActivity oldVersionsActivity = (OldVersionsActivity) this.f55b;
                int i13 = OldVersionsActivity.U;
                oldVersionsActivity.v0().f9375l.scrollToPosition(0);
                return;
            case 7:
                RecommendedActivity recommendedActivity = (RecommendedActivity) this.f55b;
                int i14 = RecommendedActivity.f3497i0;
                String string = recommendedActivity.getString(R.string.recommended_login_msg);
                string.getClass();
                recommendedActivity.J(string, new a8(recommendedActivity, i), new a8(recommendedActivity, i11));
                return;
            case 8:
                WishlistActivity wishlistActivity = (WishlistActivity) this.f55b;
                int i15 = WishlistActivity.f3530i0;
                String string2 = wishlistActivity.getString(R.string.wishlist_login_msg);
                string2.getClass();
                wishlistActivity.J(string2, new qd(wishlistActivity, i10), new qd(wishlistActivity, i));
                return;
            case 9:
                ((MaterialButton) this.f55b).lambda$setOpticalCenterEnabled$1();
                return;
            case 10:
                ((CarouselLayoutManager) this.f55b).refreshKeylineState();
                return;
            case 11:
                ((MaterialBackOrchestrator) this.f55b).startListeningForBackCallbacksWithPriorityOverlay();
                return;
            case 12:
                FileExplorerActivity fileExplorerActivity = (FileExplorerActivity) this.f55b;
                HorizontalScrollView horizontalScrollView = fileExplorerActivity.J;
                if (horizontalScrollView == null) {
                    kotlin.jvm.internal.l.i("svBreadcrumb");
                    throw null;
                }
                LinearLayout linearLayout = fileExplorerActivity.I;
                if (linearLayout == null) {
                    kotlin.jvm.internal.l.i("llBreadcrumb");
                    throw null;
                }
                int right = linearLayout.getRight();
                LinearLayout linearLayout2 = fileExplorerActivity.I;
                if (linearLayout2 != null) {
                    horizontalScrollView.scrollTo(right, linearLayout2.getTop());
                    return;
                } else {
                    kotlin.jvm.internal.l.i("llBreadcrumb");
                    throw null;
                }
            case 13:
                ((TvMyAppsFragment) this.f55b).startEntranceTransition();
                return;
            case 14:
                ((TvOldVersionsFragment) this.f55b).startEntranceTransition();
                return;
            case 15:
                ((q1) this.f55b).B = p1.f8206l;
                return;
            case 16:
                ((AppCompatTextView) this.f55b).setSelected(true);
                return;
            case 17:
                y2.s sVar = (y2.s) this.f55b;
                ((y.h) ((z.c) sVar.f11636n)).h(new x.e(sVar, 3));
                return;
            case 18:
                a();
                return;
            default:
                c0 c0Var = (c0) this.f55b;
                Log.w("FirebaseMessaging", "Service took too long to process intent: " + c0Var.f11593a.getAction() + " finishing.");
                c0Var.f11594b.c(null);
                return;
        }
    }
}
