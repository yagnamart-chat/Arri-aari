package a2;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public final class n {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final byte[] f41a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f42b;

    public n() {
        this.f41a = new byte[4096];
    }

    public n(byte[] bArr, int i) {
        this.f41a = bArr;
        this.f42b = i;
    }
}
