package a2;

import java.io.IOException;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public final class f implements l {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final q2.e f21c = new q2.e(3);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Object f22a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public Object f23b;

    public f(e2.d dVar) {
        this.f22a = dVar;
        this.f23b = f21c;
    }

    @Override // a2.l
    public void a(k kVar, int i) throws IOException {
        int[] iArr = (int[]) this.f23b;
        try {
            kVar.read((byte[]) this.f22a, iArr[0], i);
            iArr[0] = iArr[0] + i;
        } finally {
            kVar.close();
        }
    }

    public f(byte[] bArr, int[] iArr) {
        this.f22a = bArr;
        this.f23b = iArr;
    }
}
