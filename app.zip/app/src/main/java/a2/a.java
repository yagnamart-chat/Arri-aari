package a2;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public final class a implements l2.d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final a f6a = new a();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final l2.c f7b = l2.c.a("rolloutId");

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final l2.c f8c = l2.c.a("parameterKey");

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final l2.c f9d = l2.c.a("parameterValue");

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final l2.c f10e = l2.c.a("variantId");
    public static final l2.c f = l2.c.a("templateVersion");

    @Override // l2.a
    public final void a(Object obj, Object obj2) {
        l2.e eVar = (l2.e) obj2;
        b bVar = (b) ((p) obj);
        eVar.a(f7b, bVar.f11b);
        eVar.a(f8c, bVar.f12c);
        eVar.a(f9d, bVar.f13d);
        eVar.a(f10e, bVar.f14e);
        eVar.f(f, bVar.f);
    }
}
