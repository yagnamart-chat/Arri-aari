package a2;

import a4.x;
import a9.e0;
import a9.i0;
import android.content.ContentResolver;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import androidx.documentfile.provider.DocumentFile;
import c4.w4;
import com.google.firebase.messaging.FirebaseMessaging;
import e1.g1;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.concurrent.atomic.AtomicMarkableReference;
import java.util.concurrent.atomic.AtomicReference;
import java.util.logging.Logger;
import java.util.regex.Pattern;
import s7.b0;
import s7.l0;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public final class t {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public boolean f56a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Object f57b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public Object f58c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public Object f59d;

    public t(Context context, String str, k4.d dVar, boolean z9) {
        str.getClass();
        dVar.getClass();
        this.f57b = context;
        this.f58c = str;
        this.f59d = dVar;
        this.f56a = z9;
        z7.e eVar = l0.f9082a;
        b0.r(b0.a(z7.d.f11887a), null, null, new b.s(this, (x6.c) null, 24), 3);
    }

    public void a() {
        synchronized (((s8.f) this.f59d)) {
            try {
                if (this.f56a) {
                    throw new IllegalStateException();
                }
                if (((s8.d) this.f57b).f == this) {
                    ((s8.f) this.f59d).c(this, false);
                }
                this.f56a = true;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:70:0x0179, code lost:
    
        if (r2 == r15) goto L71;
     */
    /* JADX WARN: Removed duplicated region for block: B:7:0x001d  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public java.lang.Object b(l4.b r23, z6.c r24) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 389
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: a2.t.b(l4.b, z6.c):java.lang.Object");
    }

    public void c() {
        synchronized (((s8.f) this.f59d)) {
            try {
                if (this.f56a) {
                    throw new IllegalStateException();
                }
                if (((s8.d) this.f57b).f == this) {
                    ((s8.f) this.f59d).c(this, true);
                }
                this.f56a = true;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:39:0x00e7, code lost:
    
        r7 = r18;
        r3 = true;
        r5 = null;
     */
    /* JADX WARN: Removed duplicated region for block: B:22:0x008f  */
    /* JADX WARN: Removed duplicated region for block: B:35:0x00f3  */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0017  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:31:0x00e3 -> B:33:0x00e6). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public java.lang.Object d(java.io.File r23, java.lang.Object r24, z6.c r25) throws java.lang.Exception {
        /*
            Method dump skipped, instruction units count: 260
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: a2.t.d(java.io.File, java.lang.Object, z6.c):java.lang.Object");
    }

    public void e() {
        s8.d dVar = (s8.d) this.f57b;
        if (dVar.f != this) {
            return;
        }
        int i = 0;
        while (true) {
            s8.f fVar = (s8.f) this.f59d;
            if (i >= fVar.f9158q) {
                dVar.f = null;
                return;
            } else {
                try {
                    fVar.f9151a.a(dVar.f9145d[i]);
                } catch (IOException unused) {
                }
                i++;
            }
        }
    }

    public String f(l4.b bVar) {
        String strReplaceAll;
        PackageInfo packageInfoF;
        PackageInfo packageInfoF2;
        SharedPreferences sharedPreferences;
        SharedPreferences sharedPreferences2;
        w4 w4Var = (w4) this.f57b;
        boolean z9 = true;
        try {
            sharedPreferences2 = w4Var.getSharedPreferences("CoreSettings", 0);
        } catch (Exception unused) {
        }
        boolean z10 = sharedPreferences2.contains("app_name_included") ? sharedPreferences2.getBoolean("app_name_included", true) : true;
        if (z10) {
            String str = bVar.f6971b;
            str.getClass();
            Pattern patternCompile = Pattern.compile("[/\\\\:*?\"<>|]");
            patternCompile.getClass();
            strReplaceAll = patternCompile.matcher(str).replaceAll("");
            strReplaceAll.getClass();
        } else {
            String str2 = bVar.f6970a;
            str2.getClass();
            Pattern patternCompile2 = Pattern.compile("[/\\\\:*?\"<>|]");
            patternCompile2.getClass();
            strReplaceAll = patternCompile2.matcher(str2).replaceAll("");
            strReplaceAll.getClass();
        }
        try {
            SharedPreferences sharedPreferences3 = w4Var.getSharedPreferences("CoreSettings", 0);
            if (sharedPreferences3.contains("versioncode_included")) {
                z9 = sharedPreferences3.getBoolean("versioncode_included", true);
            }
        } catch (Exception unused2) {
        }
        if (z9) {
            try {
                PackageManager packageManager = w4Var.getPackageManager();
                packageManager.getClass();
                packageInfoF = d5.a.f(packageManager, bVar.f6970a, 0);
            } catch (Exception e5) {
                e5.printStackTrace();
                packageInfoF = null;
            }
            strReplaceAll = strReplaceAll + "_" + (packageInfoF != null ? n4.e.d(packageInfoF) : 0L);
        }
        try {
            sharedPreferences = w4Var.getSharedPreferences("CoreSettings", 0);
        } catch (Exception unused3) {
        }
        boolean z11 = sharedPreferences.contains("versionname_included") ? sharedPreferences.getBoolean("versionname_included", false) : false;
        if (!z11) {
            return strReplaceAll;
        }
        try {
            PackageManager packageManager2 = w4Var.getPackageManager();
            packageManager2.getClass();
            packageInfoF2 = d5.a.f(packageManager2, bVar.f6970a, 0);
        } catch (Exception e8) {
            e8.printStackTrace();
            packageInfoF2 = null;
        }
        return x.k(strReplaceAll, "_", packageInfoF2 != null ? packageInfoF2.versionName : null);
    }

    public OutputStream g(Object obj) throws Exception {
        if (obj instanceof File) {
            return new FileOutputStream((File) obj);
        }
        if (!(obj instanceof DocumentFile)) {
            throw new Exception("getOutputStream: Illegal parameter type");
        }
        DocumentFile documentFile = (DocumentFile) obj;
        if (documentFile.getName() == null) {
            throw new Exception("getOutputStream: DocumentFile name is null");
        }
        ContentResolver contentResolver = ((w4) this.f57b).getContentResolver();
        OutputStream outputStreamOpenOutputStream = contentResolver != null ? contentResolver.openOutputStream(documentFile.getUri()) : null;
        outputStreamOpenOutputStream.getClass();
        return outputStreamOpenOutputStream;
    }

    public synchronized void h() {
        try {
            if (this.f56a) {
                return;
            }
            Boolean boolK = k();
            this.f58c = boolK;
            if (boolK == null) {
                n1.i iVar = new n1.i(28);
                s1.k kVar = (s1.k) ((p2.c) this.f57b);
                kVar.a(kVar.f8781c, iVar);
            }
            this.f56a = true;
        } catch (Throwable th) {
            throw th;
        }
    }

    public synchronized boolean i() {
        Boolean bool;
        try {
            h();
            bool = (Boolean) this.f58c;
        } catch (Throwable th) {
            throw th;
        }
        return bool != null ? bool.booleanValue() : ((FirebaseMessaging) this.f59d).f3240a.h();
    }

    public e0 j(int i) {
        a9.b bVar;
        synchronized (((s8.f) this.f59d)) {
            try {
                if (this.f56a) {
                    throw new IllegalStateException();
                }
                s8.d dVar = (s8.d) this.f57b;
                if (dVar.f != this) {
                    return new a9.e();
                }
                int i10 = 1;
                if (!dVar.f9146e) {
                    ((boolean[]) this.f58c)[i] = true;
                }
                File file = dVar.f9145d[i];
                try {
                    ((s8.f) this.f59d).f9151a.getClass();
                    try {
                        Logger logger = a9.x.f292a;
                        file.getClass();
                        bVar = new a9.b(i10, new FileOutputStream(file, false), new i0());
                    } catch (FileNotFoundException unused) {
                        file.getParentFile().mkdirs();
                        Logger logger2 = a9.x.f292a;
                        bVar = new a9.b(i10, new FileOutputStream(file, false), new i0());
                    }
                    return new s8.c(this, bVar, i10);
                } catch (FileNotFoundException unused2) {
                    return new a9.e();
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public Boolean k() {
        ApplicationInfo applicationInfo;
        Bundle bundle;
        n1.g gVar = ((FirebaseMessaging) this.f59d).f3240a;
        gVar.a();
        Context context = gVar.f7279a;
        SharedPreferences sharedPreferences = context.getSharedPreferences("com.google.firebase.messaging", 0);
        if (sharedPreferences.contains("auto_init")) {
            return Boolean.valueOf(sharedPreferences.getBoolean("auto_init", false));
        }
        try {
            PackageManager packageManager = context.getPackageManager();
            if (packageManager == null || (applicationInfo = packageManager.getApplicationInfo(context.getPackageName(), 128)) == null || (bundle = applicationInfo.metaData) == null || !bundle.containsKey("firebase_messaging_auto_init_enabled")) {
                return null;
            }
            return Boolean.valueOf(applicationInfo.metaData.getBoolean("firebase_messaging_auto_init_enabled"));
        } catch (PackageManager.NameNotFoundException unused) {
            return null;
        }
    }

    public boolean l(String str, String str2) {
        synchronized (this) {
            try {
                if (!((e) ((AtomicMarkableReference) this.f57b).getReference()).c(str, str2)) {
                    return false;
                }
                AtomicMarkableReference atomicMarkableReference = (AtomicMarkableReference) this.f57b;
                atomicMarkableReference.set((e) atomicMarkableReference.getReference(), true);
                s sVar = new s(this, 0);
                AtomicReference atomicReference = (AtomicReference) this.f58c;
                while (!atomicReference.compareAndSet(null, sVar)) {
                    if (atomicReference.get() != null) {
                        return true;
                    }
                }
                ((z1.e) ((e2.d) this.f59d).f4517m).f11800b.a(sVar);
                return true;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:71:0x01b5, code lost:
    
        r1 = r2;
        r10 = r11;
        r11 = r18;
        r2 = r19;
        r17 = r26;
     */
    /* JADX WARN: Removed duplicated region for block: B:40:0x00fb A[Catch: Exception -> 0x005e, TryCatch #0 {Exception -> 0x005e, blocks: (B:13:0x004f, B:62:0x020d, B:49:0x0187, B:51:0x019b, B:57:0x01b8, B:63:0x021e, B:46:0x0149, B:64:0x0242, B:20:0x007d, B:44:0x0137, B:25:0x008b, B:27:0x0095, B:29:0x00a7, B:40:0x00fb, B:65:0x0246, B:66:0x024d, B:31:0x00d2, B:33:0x00d6, B:35:0x00e0, B:36:0x00ef, B:37:0x00f6), top: B:70:0x002a }] */
    /* JADX WARN: Removed duplicated region for block: B:46:0x0149 A[Catch: Exception -> 0x005e, TryCatch #0 {Exception -> 0x005e, blocks: (B:13:0x004f, B:62:0x020d, B:49:0x0187, B:51:0x019b, B:57:0x01b8, B:63:0x021e, B:46:0x0149, B:64:0x0242, B:20:0x007d, B:44:0x0137, B:25:0x008b, B:27:0x0095, B:29:0x00a7, B:40:0x00fb, B:65:0x0246, B:66:0x024d, B:31:0x00d2, B:33:0x00d6, B:35:0x00e0, B:36:0x00ef, B:37:0x00f6), top: B:70:0x002a }] */
    /* JADX WARN: Removed duplicated region for block: B:49:0x0187 A[Catch: Exception -> 0x005e, TryCatch #0 {Exception -> 0x005e, blocks: (B:13:0x004f, B:62:0x020d, B:49:0x0187, B:51:0x019b, B:57:0x01b8, B:63:0x021e, B:46:0x0149, B:64:0x0242, B:20:0x007d, B:44:0x0137, B:25:0x008b, B:27:0x0095, B:29:0x00a7, B:40:0x00fb, B:65:0x0246, B:66:0x024d, B:31:0x00d2, B:33:0x00d6, B:35:0x00e0, B:36:0x00ef, B:37:0x00f6), top: B:70:0x002a }] */
    /* JADX WARN: Removed duplicated region for block: B:63:0x021e A[Catch: Exception -> 0x005e, TryCatch #0 {Exception -> 0x005e, blocks: (B:13:0x004f, B:62:0x020d, B:49:0x0187, B:51:0x019b, B:57:0x01b8, B:63:0x021e, B:46:0x0149, B:64:0x0242, B:20:0x007d, B:44:0x0137, B:25:0x008b, B:27:0x0095, B:29:0x00a7, B:40:0x00fb, B:65:0x0246, B:66:0x024d, B:31:0x00d2, B:33:0x00d6, B:35:0x00e0, B:36:0x00ef, B:37:0x00f6), top: B:70:0x002a }] */
    /* JADX WARN: Removed duplicated region for block: B:64:0x0242 A[Catch: Exception -> 0x005e, TryCatch #0 {Exception -> 0x005e, blocks: (B:13:0x004f, B:62:0x020d, B:49:0x0187, B:51:0x019b, B:57:0x01b8, B:63:0x021e, B:46:0x0149, B:64:0x0242, B:20:0x007d, B:44:0x0137, B:25:0x008b, B:27:0x0095, B:29:0x00a7, B:40:0x00fb, B:65:0x0246, B:66:0x024d, B:31:0x00d2, B:33:0x00d6, B:35:0x00e0, B:36:0x00ef, B:37:0x00f6), top: B:70:0x002a }] */
    /* JADX WARN: Removed duplicated region for block: B:65:0x0246 A[Catch: Exception -> 0x005e, TryCatch #0 {Exception -> 0x005e, blocks: (B:13:0x004f, B:62:0x020d, B:49:0x0187, B:51:0x019b, B:57:0x01b8, B:63:0x021e, B:46:0x0149, B:64:0x0242, B:20:0x007d, B:44:0x0137, B:25:0x008b, B:27:0x0095, B:29:0x00a7, B:40:0x00fb, B:65:0x0246, B:66:0x024d, B:31:0x00d2, B:33:0x00d6, B:35:0x00e0, B:36:0x00ef, B:37:0x00f6), top: B:70:0x002a }] */
    /* JADX WARN: Removed duplicated region for block: B:7:0x001d  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:46:0x0149 -> B:47:0x0184). Please report as a decompilation issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:60:0x01f9 -> B:61:0x0205). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public java.lang.Object m(java.util.ArrayList r26, java.util.ArrayList r27, java.lang.String r28, long r29, z6.c r31) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 596
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: a2.t.m(java.util.ArrayList, java.util.ArrayList, java.lang.String, long, z6.c):java.lang.Object");
    }

    public String n() {
        if (!this.f56a) {
            this.f56a = true;
            g1 g1Var = (g1) this.f59d;
            this.f58c = g1Var.k().getString((String) this.f57b, null);
        }
        return (String) this.f58c;
    }

    public void o(String str) {
        SharedPreferences.Editor editorEdit = ((g1) this.f59d).k().edit();
        editorEdit.putString((String) this.f57b, str);
        editorEdit.apply();
        this.f58c = str;
    }

    public t(g1 g1Var, String str) {
        this.f59d = g1Var;
        k0.x.d(str);
        this.f57b = str;
    }

    public t(w4 w4Var, f0.i iVar) {
        this.f57b = w4Var;
        this.f58c = iVar;
    }

    public t(e2.d dVar, boolean z9) {
        this.f59d = dVar;
        this.f58c = new AtomicReference(null);
        this.f56a = z9;
        this.f57b = new AtomicMarkableReference(new e(z9 ? 8192 : 1024), false);
    }

    public t(FirebaseMessaging firebaseMessaging, p2.c cVar) {
        this.f59d = firebaseMessaging;
        this.f57b = cVar;
    }

    public t(s8.f fVar, s8.d dVar) {
        this.f59d = fVar;
        this.f57b = dVar;
        this.f58c = dVar.f9146e ? null : new boolean[fVar.f9158q];
    }
}
