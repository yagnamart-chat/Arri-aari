package a2;

import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public final class k extends InputStream {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f31a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f32b;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ m f33l;

    public k(m mVar, j jVar) {
        this.f33l = mVar;
        this.f31a = mVar.t(jVar.f29a + 4);
        this.f32b = jVar.f30b;
    }

    @Override // java.io.InputStream
    public final int read(byte[] bArr, int i, int i10) throws IOException {
        if (bArr == null) {
            com.google.android.material.drawable.a.j("buffer");
            return 0;
        }
        if ((i | i10) < 0 || i10 > bArr.length - i) {
            throw new ArrayIndexOutOfBoundsException();
        }
        int i11 = this.f32b;
        if (i11 <= 0) {
            return -1;
        }
        if (i10 > i11) {
            i10 = i11;
        }
        int i12 = this.f31a;
        m mVar = this.f33l;
        mVar.o(i12, bArr, i, i10);
        this.f31a = mVar.t(this.f31a + i10);
        this.f32b -= i10;
        return i10;
    }

    @Override // java.io.InputStream
    public final int read() throws IOException {
        m mVar = this.f33l;
        RandomAccessFile randomAccessFile = mVar.f35a;
        if (this.f32b == 0) {
            return -1;
        }
        randomAccessFile.seek(this.f31a);
        int i = randomAccessFile.read();
        this.f31a = mVar.t(this.f31a + 1);
        this.f32b--;
        return i;
    }
}
