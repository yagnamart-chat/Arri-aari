package a2;

import android.net.Uri;
import com.google.android.gms.internal.measurement.n4;
import j8.y;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public class i implements l {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public boolean f26a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Object f27b;

    public /* synthetic */ i(Object obj) {
        this.f27b = obj;
        this.f26a = true;
    }

    @Override // a2.l
    public void a(k kVar, int i) {
        StringBuilder sb = (StringBuilder) this.f27b;
        if (this.f26a) {
            this.f26a = false;
        } else {
            sb.append(", ");
        }
        sb.append(i);
    }

    public void b() {
        this.f26a = false;
    }

    public void c(byte b10) {
        ((c9.a) this.f27b).i(String.valueOf(b10));
    }

    public void d(char c10) {
        c9.a aVar = (c9.a) this.f27b;
        aVar.b(aVar.f2500b, 1);
        char[] cArr = (char[]) aVar.f2501c;
        int i = aVar.f2500b;
        aVar.f2500b = i + 1;
        cArr[i] = c10;
    }

    public void e(int i) {
        ((c9.a) this.f27b).i(String.valueOf(i));
    }

    public void f(long j) {
        ((c9.a) this.f27b).i(String.valueOf(j));
    }

    public void g(short s10) {
        ((c9.a) this.f27b).i(String.valueOf(s10));
    }

    public void h(String str) {
        byte b10;
        str.getClass();
        c9.a aVar = (c9.a) this.f27b;
        aVar.b(aVar.f2500b, str.length() + 2);
        char[] cArr = (char[]) aVar.f2501c;
        int i = aVar.f2500b;
        int i10 = i + 1;
        cArr[i] = '\"';
        int length = str.length();
        str.getChars(0, length, cArr, i10);
        int i11 = length + i10;
        int i12 = i10;
        while (i12 < i11) {
            char c10 = cArr[i12];
            byte[] bArr = y.f6556b;
            if (c10 < bArr.length && bArr[c10] != 0) {
                int length2 = str.length();
                for (int i13 = i12 - i10; i13 < length2; i13++) {
                    aVar.b(i12, 2);
                    char cCharAt = str.charAt(i13);
                    byte[] bArr2 = y.f6556b;
                    if (cCharAt >= bArr2.length || (b10 = bArr2[cCharAt]) == 0) {
                        int i14 = i12 + 1;
                        ((char[]) aVar.f2501c)[i12] = cCharAt;
                        i12 = i14;
                    } else {
                        if (b10 == 1) {
                            String str2 = y.f6555a[cCharAt];
                            str2.getClass();
                            aVar.b(i12, str2.length());
                            str2.getChars(0, str2.length(), (char[]) aVar.f2501c, i12);
                            int length3 = str2.length() + i12;
                            aVar.f2500b = length3;
                            i12 = length3;
                        } else {
                            char[] cArr2 = (char[]) aVar.f2501c;
                            cArr2[i12] = '\\';
                            cArr2[i12 + 1] = (char) b10;
                            i12 += 2;
                            aVar.f2500b = i12;
                        }
                    }
                }
                aVar.b(i12, 1);
                ((char[]) aVar.f2501c)[i12] = '\"';
                aVar.f2500b = i12 + 1;
                return;
            }
            i12++;
        }
        cArr[i11] = '\"';
        aVar.f2500b = i11 + 1;
    }

    public n4 k(long j, String str) {
        Long lValueOf = Long.valueOf(j);
        Object obj = n4.g;
        return new n4(this, str, lValueOf, 0);
    }

    public n4 l(String str, boolean z9) {
        Boolean boolValueOf = Boolean.valueOf(z9);
        Object obj = n4.g;
        return new n4(this, str, boolValueOf, 1);
    }

    public n4 m(String str, String str2) {
        Object obj = n4.g;
        return new n4(this, str, str2, 3);
    }

    public i(Uri uri, boolean z9, boolean z10) {
        this.f27b = uri;
        this.f26a = z9;
    }

    public void i() {
    }

    public void j() {
    }
}
