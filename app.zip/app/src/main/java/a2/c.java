package a2;

import java.util.Map;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public final class c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f15a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final long f16b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Map f17c;

    public c(String str, long j, Map map) {
        map.getClass();
        this.f15a = str;
        this.f16b = j;
        this.f17c = map;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof c)) {
            return false;
        }
        c cVar = (c) obj;
        return this.f15a.equals(cVar.f15a) && this.f16b == cVar.f16b && kotlin.jvm.internal.l.a(this.f17c, cVar.f17c);
    }

    public final int hashCode() {
        int iHashCode = this.f15a.hashCode() * 31;
        long j = this.f16b;
        return this.f17c.hashCode() + ((iHashCode + ((int) (j ^ (j >>> 32)))) * 31);
    }

    public final String toString() {
        return "EventMetadata(sessionId=" + this.f15a + ", timestamp=" + this.f16b + ", additionalCustomKeys=" + this.f17c + ')';
    }
}
