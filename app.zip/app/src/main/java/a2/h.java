package a2;

import a4.x;
import android.util.Log;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public final class h {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final Charset f24b = Charset.forName("UTF-8");

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final e2.d f25a;

    public h(e2.d dVar) {
        this.f25a = dVar;
    }

    public static HashMap a(String str) {
        JSONObject jSONObject = new JSONObject(str);
        HashMap map = new HashMap();
        Iterator<String> itKeys = jSONObject.keys();
        while (itKeys.hasNext()) {
            String next = itKeys.next();
            String strOptString = null;
            if (!jSONObject.isNull(next)) {
                strOptString = jSONObject.optString(next, null);
            }
            map.put(next, strOptString);
        }
        return map;
    }

    public static ArrayList b(String str) throws JSONException {
        JSONArray jSONArray = new JSONObject(str).getJSONArray("rolloutsState");
        ArrayList arrayList = new ArrayList();
        for (int i = 0; i < jSONArray.length(); i++) {
            String string = jSONArray.getString(i);
            try {
                arrayList.add(p.a(string));
            } catch (Exception e5) {
                Log.w("FirebaseCrashlytics", "Failed de-serializing rollouts state. " + string, e5);
            }
        }
        return arrayList;
    }

    public static String e(List list) {
        HashMap map = new HashMap();
        JSONArray jSONArray = new JSONArray();
        for (int i = 0; i < list.size(); i++) {
            try {
                jSONArray.put(new JSONObject(p.f46a.k(list.get(i))));
            } catch (JSONException e5) {
                Log.w("FirebaseCrashlytics", "Exception parsing rollout assignment!", e5);
            }
        }
        map.put("rolloutsState", jSONArray);
        return new JSONObject(map).toString();
    }

    public static void f(File file) {
        if (file.exists() && file.delete()) {
            Log.i("FirebaseCrashlytics", "Deleted corrupt file: " + file.getAbsolutePath(), null);
        }
    }

    public static void g(File file, String str) {
        if (file.exists() && file.delete()) {
            Log.i("FirebaseCrashlytics", "Deleted corrupt file: " + file.getAbsolutePath() + "\nReason: " + str, null);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r1v4, types: [int] */
    /* JADX WARN: Type inference failed for: r1v5 */
    /* JADX WARN: Type inference failed for: r1v8, types: [java.io.Closeable] */
    public final Map c(String str, boolean z9) throws Throwable {
        Throwable th;
        FileInputStream fileInputStream;
        Exception e5;
        e2.d dVar = this.f25a;
        File fileH = z9 ? dVar.h(str, "internal-keys") : dVar.h(str, "keys");
        if (!fileH.exists() || fileH.length() == 0) {
            g(fileH, "The file has a length of zero for session: " + str);
            return Collections.EMPTY_MAP;
        }
        try {
            try {
                fileInputStream = new FileInputStream(fileH);
            } catch (Exception e8) {
                fileInputStream = null;
                e5 = e8;
            } catch (Throwable th2) {
                ?? r12 = 0;
                th = th2;
                y1.g.b(r12, "Failed to close user metadata file.");
                throw th;
            }
            try {
                HashMap mapA = a(y1.g.i(fileInputStream));
                y1.g.b(fileInputStream, "Failed to close user metadata file.");
                return mapA;
            } catch (Exception e10) {
                e5 = e10;
                Log.w("FirebaseCrashlytics", "Error deserializing user metadata.", e5);
                f(fileH);
                y1.g.b(fileInputStream, "Failed to close user metadata file.");
                return Collections.EMPTY_MAP;
            }
        } catch (Throwable th3) {
            th = th3;
            y1.g.b(r12, "Failed to close user metadata file.");
            throw th;
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r3v2, types: [int] */
    /* JADX WARN: Type inference failed for: r6v0 */
    /* JADX WARN: Type inference failed for: r6v1 */
    /* JADX WARN: Type inference failed for: r6v2, types: [java.io.Closeable] */
    public final String d(String str) {
        FileInputStream fileInputStream;
        File fileH = this.f25a.h(str, "user-data");
        ?? r62 = 0;
        if (fileH.exists()) {
            ?? r32 = (fileH.length() > 0L ? 1 : (fileH.length() == 0L ? 0 : -1));
            try {
                if (r32 != 0) {
                    try {
                        fileInputStream = new FileInputStream(fileH);
                    } catch (Exception e5) {
                        e = e5;
                        fileInputStream = null;
                    } catch (Throwable th) {
                        th = th;
                        y1.g.b(r62, "Failed to close user metadata file.");
                        throw th;
                    }
                    try {
                        JSONObject jSONObject = new JSONObject(y1.g.i(fileInputStream));
                        String strOptString = !jSONObject.isNull("userId") ? jSONObject.optString("userId", null) : null;
                        String str2 = "Loaded userId " + strOptString + " for session " + str;
                        if (Log.isLoggable("FirebaseCrashlytics", 3)) {
                            Log.d("FirebaseCrashlytics", str2, null);
                        }
                        y1.g.b(fileInputStream, "Failed to close user metadata file.");
                        return strOptString;
                    } catch (Exception e8) {
                        e = e8;
                        Log.w("FirebaseCrashlytics", "Error deserializing user metadata.", e);
                        f(fileH);
                        y1.g.b(fileInputStream, "Failed to close user metadata file.");
                        return null;
                    }
                }
            } catch (Throwable th2) {
                th = th2;
                r62 = r32;
            }
        }
        String strJ = x.j("No userId set for session ", str);
        if (Log.isLoggable("FirebaseCrashlytics", 3)) {
            Log.d("FirebaseCrashlytics", strJ, null);
        }
        f(fileH);
        return null;
    }

    public final void h(String str, Map map, boolean z9) {
        e2.d dVar = this.f25a;
        File fileH = z9 ? dVar.h(str, "internal-keys") : dVar.h(str, "keys");
        BufferedWriter bufferedWriter = null;
        try {
            try {
                String string = new JSONObject(map).toString();
                BufferedWriter bufferedWriter2 = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(fileH), f24b));
                try {
                    bufferedWriter2.write(string);
                    bufferedWriter2.flush();
                    y1.g.b(bufferedWriter2, "Failed to close key/value metadata file.");
                } catch (Exception e5) {
                    e = e5;
                    bufferedWriter = bufferedWriter2;
                    Log.w("FirebaseCrashlytics", "Error serializing key/value metadata.", e);
                    f(fileH);
                    y1.g.b(bufferedWriter, "Failed to close key/value metadata file.");
                } catch (Throwable th) {
                    th = th;
                    bufferedWriter = bufferedWriter2;
                    y1.g.b(bufferedWriter, "Failed to close key/value metadata file.");
                    throw th;
                }
            } catch (Throwable th2) {
                th = th2;
            }
        } catch (Exception e8) {
            e = e8;
        }
    }
}
