package a2;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public final class j {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final j f28c = new j(0, 0);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f29a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int f30b;

    public j(int i, int i10) {
        this.f29a = i;
        this.f30b = i10;
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(j.class.getSimpleName());
        sb.append("[position = ");
        sb.append(this.f29a);
        sb.append(", length = ");
        return androidx.lifecycle.l.x(sb, "]", this.f30b);
    }
}
