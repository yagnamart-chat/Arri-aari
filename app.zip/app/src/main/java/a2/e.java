package a2;

import android.util.Log;
import j$.util.DesugarCollections;
import java.util.HashMap;
import java.util.Map;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public final class e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final HashMap f18a = new HashMap();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int f19b = 64;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final int f20c;

    public e(int i) {
        this.f20c = i;
    }

    public static String b(int i, String str) {
        if (str != null) {
            str = str.trim();
            if (str.length() > i) {
                return str.substring(0, i);
            }
        }
        return str;
    }

    public final synchronized Map a() {
        return DesugarCollections.unmodifiableMap(new HashMap(this.f18a));
    }

    public final synchronized boolean c(String str, String str2) {
        String strB = b(this.f20c, str);
        if (this.f18a.size() >= this.f19b && !this.f18a.containsKey(strB)) {
            Log.w("FirebaseCrashlytics", "Ignored entry \"" + str + "\" when adding custom keys. Maximum allowable: " + this.f19b, null);
            return false;
        }
        String strB2 = b(this.f20c, str2);
        String str3 = (String) this.f18a.get(strB);
        if (str3 == null ? strB2 == null : str3.equals(strB2)) {
            return false;
        }
        this.f18a.put(strB, strB2);
        return true;
    }

    public final synchronized void d(Map map) {
        try {
            int i = 0;
            for (Map.Entry entry : map.entrySet()) {
                String str = (String) entry.getKey();
                if (str == null) {
                    throw new IllegalArgumentException("Custom attribute key must not be null.");
                }
                String strB = b(this.f20c, str);
                if (this.f18a.size() < this.f19b || this.f18a.containsKey(strB)) {
                    String str2 = (String) entry.getValue();
                    this.f18a.put(strB, str2 == null ? "" : b(this.f20c, str2));
                } else {
                    i++;
                }
            }
            if (i > 0) {
                Log.w("FirebaseCrashlytics", "Ignored " + i + " entries when adding custom keys. Maximum allowable: " + this.f19b, null);
            }
        } catch (Throwable th) {
            throw th;
        }
    }
}
