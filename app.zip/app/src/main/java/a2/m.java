package a2;

import java.io.Closeable;
import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.channels.FileChannel;
import java.util.NoSuchElementException;
import java.util.logging.Level;
import java.util.logging.Logger;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public final class m implements Closeable {

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public static final Logger f34p = Logger.getLogger(m.class.getName());

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final RandomAccessFile f35a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f36b;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public int f37l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public j f38m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public j f39n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final byte[] f40o;

    public m(File file) throws IOException {
        byte[] bArr = new byte[16];
        this.f40o = bArr;
        if (!file.exists()) {
            File file2 = new File(file.getPath() + ".tmp");
            RandomAccessFile randomAccessFile = new RandomAccessFile(file2, "rwd");
            try {
                randomAccessFile.setLength(4096L);
                randomAccessFile.seek(0L);
                byte[] bArr2 = new byte[16];
                int[] iArr = {4096, 0, 0, 0};
                int i = 0;
                for (int i10 = 0; i10 < 4; i10++) {
                    z(i, iArr[i10], bArr2);
                    i += 4;
                }
                randomAccessFile.write(bArr2);
                randomAccessFile.close();
                if (!file2.renameTo(file)) {
                    com.google.android.material.drawable.a.k("Rename failed!");
                    throw null;
                }
            } catch (Throwable th) {
                randomAccessFile.close();
                throw th;
            }
        }
        RandomAccessFile randomAccessFile2 = new RandomAccessFile(file, "rwd");
        this.f35a = randomAccessFile2;
        randomAccessFile2.seek(0L);
        randomAccessFile2.readFully(bArr);
        int iJ = j(0, bArr);
        this.f36b = iJ;
        if (iJ <= randomAccessFile2.length()) {
            this.f37l = j(4, bArr);
            int iJ2 = j(8, bArr);
            int iJ3 = j(12, bArr);
            this.f38m = h(iJ2);
            this.f39n = h(iJ3);
            return;
        }
        throw new IOException("File is truncated. Expected length: " + this.f36b + ", Actual length: " + randomAccessFile2.length());
    }

    public static int j(int i, byte[] bArr) {
        return ((bArr[i] & 255) << 24) + ((bArr[i + 1] & 255) << 16) + ((bArr[i + 2] & 255) << 8) + (bArr[i + 3] & 255);
    }

    public static void z(int i, int i10, byte[] bArr) {
        bArr[i] = (byte) (i10 >> 24);
        bArr[i + 1] = (byte) (i10 >> 16);
        bArr[i + 2] = (byte) (i10 >> 8);
        bArr[i + 3] = (byte) i10;
    }

    public final void b(byte[] bArr) {
        int iT;
        int length = bArr.length;
        synchronized (this) {
            if (length >= 0) {
                if (length <= bArr.length) {
                    d(length);
                    boolean zG = g();
                    if (zG) {
                        iT = 16;
                    } else {
                        j jVar = this.f39n;
                        iT = t(jVar.f29a + 4 + jVar.f30b);
                    }
                    j jVar2 = new j(iT, length);
                    z(0, length, this.f40o);
                    q(iT, 4, this.f40o);
                    q(iT + 4, length, bArr);
                    y(this.f36b, this.f37l + 1, zG ? iT : this.f38m.f29a, iT);
                    this.f39n = jVar2;
                    this.f37l++;
                    if (zG) {
                        this.f38m = jVar2;
                    }
                }
            }
            throw new IndexOutOfBoundsException();
        }
    }

    public final synchronized void c() {
        y(4096, 0, 0, 0);
        this.f37l = 0;
        j jVar = j.f28c;
        this.f38m = jVar;
        this.f39n = jVar;
        if (this.f36b > 4096) {
            RandomAccessFile randomAccessFile = this.f35a;
            randomAccessFile.setLength(4096);
            randomAccessFile.getChannel().force(true);
        }
        this.f36b = 4096;
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public final synchronized void close() {
        this.f35a.close();
    }

    public final void d(int i) throws IOException {
        int i10 = i + 4;
        int iR = this.f36b - r();
        if (iR >= i10) {
            return;
        }
        int i11 = this.f36b;
        do {
            iR += i11;
            i11 <<= 1;
        } while (iR < i10);
        RandomAccessFile randomAccessFile = this.f35a;
        randomAccessFile.setLength(i11);
        randomAccessFile.getChannel().force(true);
        j jVar = this.f39n;
        int iT = t(jVar.f29a + 4 + jVar.f30b);
        if (iT < this.f38m.f29a) {
            FileChannel channel = randomAccessFile.getChannel();
            channel.position(this.f36b);
            long j = iT - 4;
            if (channel.transferTo(16L, j, channel) != j) {
                a3.b.j("Copied insufficient number of bytes!");
                return;
            }
        }
        int i12 = this.f39n.f29a;
        int i13 = this.f38m.f29a;
        if (i12 < i13) {
            int i14 = (this.f36b + i12) - 16;
            y(i11, this.f37l, i13, i14);
            this.f39n = new j(i14, this.f39n.f30b);
        } else {
            y(i11, this.f37l, i13, i12);
        }
        this.f36b = i11;
    }

    public final synchronized void e(l lVar) {
        int iT = this.f38m.f29a;
        for (int i = 0; i < this.f37l; i++) {
            j jVarH = h(iT);
            lVar.a(new k(this, jVarH), jVarH.f30b);
            iT = t(jVarH.f29a + 4 + jVarH.f30b);
        }
    }

    public final synchronized boolean g() {
        return this.f37l == 0;
    }

    public final j h(int i) throws IOException {
        if (i == 0) {
            return j.f28c;
        }
        RandomAccessFile randomAccessFile = this.f35a;
        randomAccessFile.seek(i);
        return new j(i, randomAccessFile.readInt());
    }

    public final synchronized void n() {
        try {
            if (g()) {
                throw new NoSuchElementException();
            }
            if (this.f37l == 1) {
                c();
            } else {
                j jVar = this.f38m;
                int iT = t(jVar.f29a + 4 + jVar.f30b);
                o(iT, this.f40o, 0, 4);
                int iJ = j(0, this.f40o);
                y(this.f36b, this.f37l - 1, iT, this.f39n.f29a);
                this.f37l--;
                this.f38m = new j(iT, iJ);
            }
        } catch (Throwable th) {
            throw th;
        }
    }

    public final void o(int i, byte[] bArr, int i10, int i11) throws IOException {
        int iT = t(i);
        int i12 = iT + i11;
        int i13 = this.f36b;
        RandomAccessFile randomAccessFile = this.f35a;
        if (i12 <= i13) {
            randomAccessFile.seek(iT);
            randomAccessFile.readFully(bArr, i10, i11);
            return;
        }
        int i14 = i13 - iT;
        randomAccessFile.seek(iT);
        randomAccessFile.readFully(bArr, i10, i14);
        randomAccessFile.seek(16L);
        randomAccessFile.readFully(bArr, i10 + i14, i11 - i14);
    }

    public final void q(int i, int i10, byte[] bArr) throws IOException {
        int iT = t(i);
        int i11 = iT + i10;
        int i12 = this.f36b;
        RandomAccessFile randomAccessFile = this.f35a;
        if (i11 <= i12) {
            randomAccessFile.seek(iT);
            randomAccessFile.write(bArr, 0, i10);
            return;
        }
        int i13 = i12 - iT;
        randomAccessFile.seek(iT);
        randomAccessFile.write(bArr, 0, i13);
        randomAccessFile.seek(16L);
        randomAccessFile.write(bArr, i13, i10 - i13);
    }

    public final int r() {
        if (this.f37l == 0) {
            return 16;
        }
        j jVar = this.f39n;
        int i = jVar.f29a;
        int i10 = this.f38m.f29a;
        return i >= i10 ? (i - i10) + 4 + jVar.f30b + 16 : (((i + 4) + jVar.f30b) + this.f36b) - i10;
    }

    public final int t(int i) {
        int i10 = this.f36b;
        return i < i10 ? i : (i + 16) - i10;
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(m.class.getSimpleName());
        sb.append("[fileLength=");
        sb.append(this.f36b);
        sb.append(", size=");
        sb.append(this.f37l);
        sb.append(", first=");
        sb.append(this.f38m);
        sb.append(", last=");
        sb.append(this.f39n);
        sb.append(", element lengths=[");
        try {
            e(new i(sb));
        } catch (IOException e5) {
            f34p.log(Level.WARNING, "read error", (Throwable) e5);
        }
        sb.append("]]");
        return sb.toString();
    }

    public final void y(int i, int i10, int i11, int i12) throws IOException {
        int[] iArr = {i, i10, i11, i12};
        int i13 = 0;
        int i14 = 0;
        while (true) {
            byte[] bArr = this.f40o;
            if (i13 >= 4) {
                RandomAccessFile randomAccessFile = this.f35a;
                randomAccessFile.seek(0L);
                randomAccessFile.write(bArr);
                return;
            } else {
                z(i14, iArr[i13], bArr);
                i14 += 4;
                i13++;
            }
        }
    }
}
