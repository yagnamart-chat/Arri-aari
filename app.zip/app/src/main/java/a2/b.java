package a2;

import a4.x;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes3.dex */
public final class b extends p {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String f11b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final String f12c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final String f13d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final String f14e;
    public final long f;

    public b(String str, String str2, String str3, String str4, long j) {
        if (str == null) {
            com.google.android.material.drawable.a.j("Null rolloutId");
            throw null;
        }
        this.f11b = str;
        if (str2 == null) {
            com.google.android.material.drawable.a.j("Null parameterKey");
            throw null;
        }
        this.f12c = str2;
        this.f13d = str3;
        if (str4 == null) {
            com.google.android.material.drawable.a.j("Null variantId");
            throw null;
        }
        this.f14e = str4;
        this.f = j;
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof p)) {
            return false;
        }
        b bVar = (b) ((p) obj);
        return this.f11b.equals(bVar.f11b) && this.f12c.equals(bVar.f12c) && this.f13d.equals(bVar.f13d) && this.f14e.equals(bVar.f14e) && this.f == bVar.f;
    }

    public final int hashCode() {
        int iHashCode = (((((((this.f11b.hashCode() ^ 1000003) * 1000003) ^ this.f12c.hashCode()) * 1000003) ^ this.f13d.hashCode()) * 1000003) ^ this.f14e.hashCode()) * 1000003;
        long j = this.f;
        return iHashCode ^ ((int) (j ^ (j >>> 32)));
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("RolloutAssignment{rolloutId=");
        sb.append(this.f11b);
        sb.append(", parameterKey=");
        sb.append(this.f12c);
        sb.append(", parameterValue=");
        sb.append(this.f13d);
        sb.append(", variantId=");
        sb.append(this.f14e);
        sb.append(", templateVersion=");
        return x.l(sb, this.f, "}");
    }
}
