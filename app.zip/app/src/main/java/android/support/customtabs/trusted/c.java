package android.support.customtabs.trusted;

import android.os.Bundle;
import android.os.IInterface;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes.dex */
public interface c extends IInterface {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final String f302e = "android$support$customtabs$trusted$ITrustedWebActivityCallback".replace('$', '.');

    void onExtraCallback(String str, Bundle bundle);
}
