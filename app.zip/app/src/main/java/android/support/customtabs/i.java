package android.support.customtabs;

import android.os.Bundle;
import android.os.IInterface;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes.dex */
public interface i extends IInterface {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final String f300c = "android$support$customtabs$IEngagementSignalsCallback".replace('$', '.');

    void onGreatestScrollPercentageIncreased(int i, Bundle bundle);

    void onSessionEnded(boolean z9, Bundle bundle);

    void onVerticalScrollEvent(boolean z9, Bundle bundle);
}
