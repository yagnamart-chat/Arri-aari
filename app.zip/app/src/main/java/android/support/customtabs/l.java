package android.support.customtabs;

import android.os.Bundle;
import android.os.IInterface;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes.dex */
public interface l extends IInterface {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final String f301d = "android$support$customtabs$IPostMessageService".replace('$', '.');

    void onMessageChannelReady(c cVar, Bundle bundle);

    void onPostMessage(c cVar, String str, Bundle bundle);
}
