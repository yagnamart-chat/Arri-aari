package android.support.v4.media.session;

import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.ResultReceiver;
import androidx.core.app.BundleCompat;
import java.lang.ref.WeakReference;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes.dex */
class MediaControllerCompat$MediaControllerImplApi21$ExtraBinderRequestResultReceiver extends ResultReceiver {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public WeakReference f331a;

    @Override // android.os.ResultReceiver
    public final void onReceiveResult(int i, Bundle bundle) {
        d dVar;
        h hVar = (h) this.f331a.get();
        if (hVar == null || bundle == null) {
            return;
        }
        synchronized (hVar.f362b) {
            MediaSessionCompat$Token mediaSessionCompat$Token = hVar.f365e;
            IBinder binder = BundleCompat.getBinder(bundle, "android.support.v4.media.session.EXTRA_BINDER");
            int i10 = c.i;
            if (binder == null) {
                dVar = null;
            } else {
                IInterface iInterfaceQueryLocalInterface = binder.queryLocalInterface("android.support.v4.media.session.IMediaSession");
                if (iInterfaceQueryLocalInterface == null || !(iInterfaceQueryLocalInterface instanceof d)) {
                    b bVar = new b();
                    bVar.i = binder;
                    dVar = bVar;
                } else {
                    dVar = (d) iInterfaceQueryLocalInterface;
                }
            }
            mediaSessionCompat$Token.f337b = dVar;
            MediaSessionCompat$Token mediaSessionCompat$Token2 = hVar.f365e;
            bundle.getBundle("android.support.v4.media.session.SESSION_TOKEN2_BUNDLE");
            mediaSessionCompat$Token2.getClass();
            hVar.a();
        }
    }
}
