package android.support.v4.media;

import android.os.Bundle;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes.dex */
class MediaBrowserCompat$CustomActionResultReceiver extends e.d {
    @Override // e.d
    public final void a(int i, Bundle bundle) {
    }
}
