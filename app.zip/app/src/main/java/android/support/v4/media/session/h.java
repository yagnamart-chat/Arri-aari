package android.support.v4.media.session;

import android.content.Context;
import android.media.session.MediaController;
import android.media.session.MediaSession;
import android.os.Parcel;
import android.os.RemoteException;
import android.util.Log;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashMap;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes.dex */
public class h {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final MediaController f361a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Object f362b = new Object();

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final ArrayList f363c = new ArrayList();

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final HashMap f364d = new HashMap();

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final MediaSessionCompat$Token f365e;

    public h(Context context, MediaSessionCompat$Token mediaSessionCompat$Token) {
        this.f365e = mediaSessionCompat$Token;
        MediaController mediaController = new MediaController(context, (MediaSession.Token) mediaSessionCompat$Token.f336a);
        this.f361a = mediaController;
        if (mediaSessionCompat$Token.f337b == null) {
            MediaControllerCompat$MediaControllerImplApi21$ExtraBinderRequestResultReceiver mediaControllerCompat$MediaControllerImplApi21$ExtraBinderRequestResultReceiver = new MediaControllerCompat$MediaControllerImplApi21$ExtraBinderRequestResultReceiver(null);
            mediaControllerCompat$MediaControllerImplApi21$ExtraBinderRequestResultReceiver.f331a = new WeakReference(this);
            mediaController.sendCommand("android.support.v4.media.session.command.GET_EXTRA_BINDER", null, mediaControllerCompat$MediaControllerImplApi21$ExtraBinderRequestResultReceiver);
        }
    }

    public final void a() {
        MediaSessionCompat$Token mediaSessionCompat$Token = this.f365e;
        if (mediaSessionCompat$Token.f337b == null) {
            return;
        }
        ArrayList arrayList = this.f363c;
        int size = arrayList.size();
        int i = 0;
        while (i < size) {
            Object obj = arrayList.get(i);
            i++;
            f fVar = (f) obj;
            g gVar = new g(fVar);
            this.f364d.put(fVar, gVar);
            fVar.mIControllerCallback = gVar;
            try {
                b bVar = (b) mediaSessionCompat$Token.f337b;
                bVar.getClass();
                Parcel parcelObtain = Parcel.obtain();
                Parcel parcelObtain2 = Parcel.obtain();
                try {
                    parcelObtain.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
                    parcelObtain.writeStrongBinder(gVar);
                    bVar.i.transact(3, parcelObtain, parcelObtain2, 0);
                    parcelObtain2.readException();
                    fVar.postToHandler(13, null, null);
                } finally {
                    parcelObtain2.recycle();
                    parcelObtain.recycle();
                }
            } catch (RemoteException e5) {
                Log.e("MediaControllerCompat", "Dead object in registerCallback.", e5);
            }
        }
        arrayList.clear();
    }
}
