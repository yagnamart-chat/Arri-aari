package android.support.v4.media.session;

import android.os.Parcel;
import android.os.Parcelable;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes.dex */
public class ParcelableVolumeInfo implements Parcelable {
    public static final Parcelable.Creator<ParcelableVolumeInfo> CREATOR = new android.support.v4.media.f(7);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f338a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f339b;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public int f340l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public int f341m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public int f342n;

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.f338a);
        parcel.writeInt(this.f340l);
        parcel.writeInt(this.f341m);
        parcel.writeInt(this.f342n);
        parcel.writeInt(this.f339b);
    }
}
