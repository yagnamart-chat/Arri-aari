package android.support.v4.media;

import android.os.BadParcelableException;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.Messenger;
import android.support.v4.media.session.m;
import android.util.Log;
import androidx.media.MediaBrowserProtocol;
import java.lang.ref.WeakReference;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes.dex */
public final class a extends Handler {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final WeakReference f317a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public WeakReference f318b;

    public a(d dVar) {
        this.f317a = new WeakReference(dVar);
    }

    @Override // android.os.Handler
    public final void handleMessage(Message message) {
        WeakReference weakReference = this.f318b;
        if (weakReference == null || weakReference.get() == null) {
            return;
        }
        WeakReference weakReference2 = this.f317a;
        if (weakReference2.get() == null) {
            return;
        }
        Bundle data = message.getData();
        m.a(data);
        d dVar = (d) weakReference2.get();
        Messenger messenger = (Messenger) this.f318b.get();
        try {
            int i = message.what;
            if (i == 1) {
                m.a(data.getBundle(MediaBrowserProtocol.DATA_ROOT_HINTS));
                data.getString(MediaBrowserProtocol.DATA_MEDIA_ITEM_ID);
                dVar.getClass();
                return;
            }
            if (i == 2) {
                dVar.getClass();
                return;
            }
            if (i != 3) {
                Log.w("MediaBrowserCompat", "Unhandled message: " + message + "\n  Client version: 1\n  Service version: " + message.arg1);
                return;
            }
            m.a(data.getBundle(MediaBrowserProtocol.DATA_OPTIONS));
            m.a(data.getBundle(MediaBrowserProtocol.DATA_NOTIFY_CHILDREN_CHANGED_OPTIONS));
            String string = data.getString(MediaBrowserProtocol.DATA_MEDIA_ITEM_ID);
            data.getParcelableArrayList(MediaBrowserProtocol.DATA_MEDIA_ITEM_LIST);
            if (dVar.g != messenger) {
                return;
            }
            if (dVar.f323e.get(string) != null) {
                throw new ClassCastException();
            }
            if (h.f328b) {
                Log.d("MediaBrowserCompat", "onLoadChildren for id that isn't subscribed id=" + string);
            }
        } catch (BadParcelableException unused) {
            Log.e("MediaBrowserCompat", "Could not unparcel the data.");
            if (message.what == 1) {
                dVar.getClass();
            }
        }
    }
}
