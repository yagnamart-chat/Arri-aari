package android.support.v4.media.session;

import a4.x;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import java.util.ArrayList;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes.dex */
public final class PlaybackStateCompat implements Parcelable {
    public static final Parcelable.Creator<PlaybackStateCompat> CREATOR = new android.support.v4.media.f(8);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f343a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final long f344b;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final long f345l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final float f346m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final long f347n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final int f348o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final CharSequence f349p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final long f350q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final ArrayList f351r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final long f352s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final Bundle f353t;

    public PlaybackStateCompat(Parcel parcel) {
        this.f343a = parcel.readInt();
        this.f344b = parcel.readLong();
        this.f346m = parcel.readFloat();
        this.f350q = parcel.readLong();
        this.f345l = parcel.readLong();
        this.f347n = parcel.readLong();
        this.f349p = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
        this.f351r = parcel.createTypedArrayList(CustomAction.CREATOR);
        this.f352s = parcel.readLong();
        this.f353t = parcel.readBundle(m.class.getClassLoader());
        this.f348o = parcel.readInt();
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("PlaybackState {state=");
        sb.append(this.f343a);
        sb.append(", position=");
        sb.append(this.f344b);
        sb.append(", buffered position=");
        sb.append(this.f345l);
        sb.append(", speed=");
        sb.append(this.f346m);
        sb.append(", updated=");
        sb.append(this.f350q);
        sb.append(", actions=");
        sb.append(this.f347n);
        sb.append(", error code=");
        sb.append(this.f348o);
        sb.append(", error message=");
        sb.append(this.f349p);
        sb.append(", custom actions=");
        sb.append(this.f351r);
        sb.append(", active item id=");
        return x.l(sb, this.f352s, "}");
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.f343a);
        parcel.writeLong(this.f344b);
        parcel.writeFloat(this.f346m);
        parcel.writeLong(this.f350q);
        parcel.writeLong(this.f345l);
        parcel.writeLong(this.f347n);
        TextUtils.writeToParcel(this.f349p, parcel, i);
        parcel.writeTypedList(this.f351r);
        parcel.writeLong(this.f352s);
        parcel.writeBundle(this.f353t);
        parcel.writeInt(this.f348o);
    }

    /* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
    public static final class CustomAction implements Parcelable {
        public static final Parcelable.Creator<CustomAction> CREATOR = new n();

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final String f354a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public final CharSequence f355b;

        /* JADX INFO: renamed from: l, reason: collision with root package name */
        public final int f356l;

        /* JADX INFO: renamed from: m, reason: collision with root package name */
        public final Bundle f357m;

        /* JADX INFO: renamed from: n, reason: collision with root package name */
        public Object f358n;

        public CustomAction(Parcel parcel) {
            this.f354a = parcel.readString();
            this.f355b = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
            this.f356l = parcel.readInt();
            this.f357m = parcel.readBundle(m.class.getClassLoader());
        }

        @Override // android.os.Parcelable
        public final int describeContents() {
            return 0;
        }

        public final String toString() {
            return "Action:mName='" + ((Object) this.f355b) + ", mIcon=" + this.f356l + ", mExtras=" + this.f357m;
        }

        @Override // android.os.Parcelable
        public final void writeToParcel(Parcel parcel, int i) {
            parcel.writeString(this.f354a);
            TextUtils.writeToParcel(this.f355b, parcel, i);
            parcel.writeInt(this.f356l);
            parcel.writeBundle(this.f357m);
        }

        public CustomAction(String str, CharSequence charSequence, int i, Bundle bundle) {
            this.f354a = str;
            this.f355b = charSequence;
            this.f356l = i;
            this.f357m = bundle;
        }
    }

    public PlaybackStateCompat(int i, long j, long j10, float f, long j11, CharSequence charSequence, long j12, ArrayList arrayList, long j13, Bundle bundle) {
        this.f343a = i;
        this.f344b = j;
        this.f345l = j10;
        this.f346m = f;
        this.f347n = j11;
        this.f348o = 0;
        this.f349p = charSequence;
        this.f350q = j12;
        this.f351r = new ArrayList(arrayList);
        this.f352s = j13;
        this.f353t = bundle;
    }
}
