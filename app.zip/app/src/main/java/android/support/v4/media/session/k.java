package android.support.v4.media.session;

import android.support.v4.media.MediaMetadataCompat;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes.dex */
public abstract class k {
    public abstract MediaMetadataCompat a();

    public abstract PlaybackStateCompat b();

    public abstract void c(f fVar);
}
