package android.support.v4.media;

import android.content.Context;
import android.media.browse.MediaBrowser;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;
import android.support.v4.media.session.MediaSessionCompat$Token;
import android.util.Log;
import androidx.core.app.BundleCompat;
import androidx.media.MediaBrowserProtocol;
import java.lang.ref.WeakReference;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes.dex */
public final class i extends MediaBrowser.ConnectionCallback {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final a3.d f330a;

    public i(a3.d dVar) {
        this.f330a = dVar;
    }

    @Override // android.media.browse.MediaBrowser.ConnectionCallback
    public final void onConnected() {
        android.support.v4.media.session.d dVar;
        c cVar = (c) this.f330a.f67b;
        b bVar = cVar.mConnectionCallbackInternal;
        if (bVar != null) {
            d dVar2 = (d) bVar;
            a aVar = dVar2.f322d;
            MediaBrowser mediaBrowser = dVar2.f320b;
            Bundle extras = mediaBrowser.getExtras();
            if (extras != null) {
                int i = 0;
                byte b10 = 0;
                extras.getInt(MediaBrowserProtocol.EXTRA_SERVICE_VERSION, 0);
                IBinder binder = BundleCompat.getBinder(extras, MediaBrowserProtocol.EXTRA_MESSENGER_BINDER);
                if (binder != null) {
                    Bundle bundle = dVar2.f321c;
                    g gVar = new g(i, (boolean) (b10 == true ? 1 : 0));
                    gVar.f326b = new Messenger(binder);
                    gVar.f327l = bundle;
                    dVar2.f = gVar;
                    Messenger messenger = new Messenger(aVar);
                    dVar2.g = messenger;
                    aVar.getClass();
                    aVar.f318b = new WeakReference(messenger);
                    try {
                        g gVar2 = dVar2.f;
                        Context context = dVar2.f319a;
                        Messenger messenger2 = dVar2.g;
                        gVar2.getClass();
                        Bundle bundle2 = new Bundle();
                        bundle2.putString(MediaBrowserProtocol.DATA_PACKAGE_NAME, context.getPackageName());
                        bundle2.putBundle(MediaBrowserProtocol.DATA_ROOT_HINTS, (Bundle) gVar2.f327l);
                        Message messageObtain = Message.obtain();
                        messageObtain.what = 6;
                        messageObtain.arg1 = 1;
                        messageObtain.setData(bundle2);
                        messageObtain.replyTo = messenger2;
                        ((Messenger) gVar2.f326b).send(messageObtain);
                    } catch (RemoteException unused) {
                        Log.i("MediaBrowserCompat", "Remote error registering client messenger.");
                    }
                }
                IBinder binder2 = BundleCompat.getBinder(extras, MediaBrowserProtocol.EXTRA_SESSION_BINDER);
                int i10 = android.support.v4.media.session.c.i;
                if (binder2 == null) {
                    dVar = null;
                } else {
                    IInterface iInterfaceQueryLocalInterface = binder2.queryLocalInterface("android.support.v4.media.session.IMediaSession");
                    if (iInterfaceQueryLocalInterface == null || !(iInterfaceQueryLocalInterface instanceof android.support.v4.media.session.d)) {
                        android.support.v4.media.session.b bVar2 = new android.support.v4.media.session.b();
                        bVar2.i = binder2;
                        dVar = bVar2;
                    } else {
                        dVar = (android.support.v4.media.session.d) iInterfaceQueryLocalInterface;
                    }
                }
                if (dVar != null) {
                    dVar2.h = MediaSessionCompat$Token.a(mediaBrowser.getSessionToken(), dVar);
                }
            }
        }
        cVar.onConnected();
    }

    @Override // android.media.browse.MediaBrowser.ConnectionCallback
    public final void onConnectionFailed() {
        ((c) this.f330a.f67b).onConnectionFailed();
    }

    @Override // android.media.browse.MediaBrowser.ConnectionCallback
    public final void onConnectionSuspended() {
        c cVar = (c) this.f330a.f67b;
        b bVar = cVar.mConnectionCallbackInternal;
        if (bVar != null) {
            d dVar = (d) bVar;
            dVar.f = null;
            dVar.g = null;
            dVar.h = null;
            a aVar = dVar.f322d;
            aVar.getClass();
            aVar.f318b = new WeakReference(null);
        }
        cVar.onConnectionSuspended();
    }
}
