package android.support.v4.media;

import android.app.PendingIntent;
import android.content.Intent;
import android.media.MediaDescription;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.ResultReceiver;
import android.support.v4.media.session.MediaSessionCompat$QueueItem;
import android.support.v4.media.session.MediaSessionCompat$ResultReceiverWrapper;
import android.support.v4.media.session.MediaSessionCompat$Token;
import android.support.v4.media.session.ParcelableVolumeInfo;
import android.support.v4.media.session.PlaybackStateCompat;
import androidx.constraintlayout.widget.ConstraintLayout;
import b2.t1;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.auth.api.signin.internal.SignInConfiguration;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.internal.measurement.z3;
import e1.c5;
import e1.j4;
import e1.m4;
import e1.n4;
import e1.o4;
import e1.t;
import e1.u;
import e1.x4;
import h0.q;
import java.util.ArrayList;
import k0.r;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes.dex */
public final class f implements Parcelable.Creator {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f324a;

    public /* synthetic */ f(int i) {
        this.f324a = i;
    }

    public static void a(u uVar, Parcel parcel, int i) {
        String str = uVar.f4339a;
        int iP0 = z3.p0(parcel, 20293);
        z3.j0(parcel, 2, str);
        z3.i0(parcel, 3, uVar.f4340b, i);
        z3.j0(parcel, 4, uVar.f4341l);
        long j = uVar.f4342m;
        z3.n0(parcel, 5, 8);
        parcel.writeLong(j);
        z3.r0(parcel, iP0);
    }

    public static void b(x4 x4Var, Parcel parcel) {
        int i = x4Var.f4450a;
        int iP0 = z3.p0(parcel, 20293);
        z3.n0(parcel, 1, 4);
        parcel.writeInt(i);
        z3.j0(parcel, 2, x4Var.f4451b);
        long j = x4Var.f4452l;
        z3.n0(parcel, 3, 8);
        parcel.writeLong(j);
        Long l6 = x4Var.f4453m;
        if (l6 != null) {
            z3.n0(parcel, 4, 8);
            parcel.writeLong(l6.longValue());
        }
        z3.j0(parcel, 6, x4Var.f4454n);
        z3.j0(parcel, 7, x4Var.f4455o);
        Double d10 = x4Var.f4456p;
        if (d10 != null) {
            z3.n0(parcel, 8, 8);
            parcel.writeDouble(d10.doubleValue());
        }
        z3.r0(parcel, iP0);
    }

    @Override // android.os.Parcelable.Creator
    public final Object createFromParcel(Parcel parcel) {
        long jW = 0;
        int iV = 0;
        e.b bVar = null;
        String strX = null;
        h0.b bVar2 = null;
        Intent intent = null;
        String strX2 = null;
        Bundle bundleV = null;
        ArrayList arrayListZ = null;
        String strX3 = null;
        Bundle bundleV2 = null;
        Bundle bundleV3 = null;
        switch (this.f324a) {
            case 0:
                return new MediaBrowserCompat$MediaItem(parcel);
            case 1:
                return MediaDescriptionCompat.a(MediaDescription.CREATOR.createFromParcel(parcel));
            case 2:
                return new MediaMetadataCompat(parcel);
            case 3:
                return new RatingCompat(parcel.readInt(), parcel.readFloat());
            case 4:
                return new MediaSessionCompat$QueueItem(parcel);
            case 5:
                MediaSessionCompat$ResultReceiverWrapper mediaSessionCompat$ResultReceiverWrapper = new MediaSessionCompat$ResultReceiverWrapper();
                mediaSessionCompat$ResultReceiverWrapper.f335a = (ResultReceiver) ResultReceiver.CREATOR.createFromParcel(parcel);
                return mediaSessionCompat$ResultReceiverWrapper;
            case 6:
                return new MediaSessionCompat$Token(parcel.readParcelable(null), null);
            case 7:
                ParcelableVolumeInfo parcelableVolumeInfo = new ParcelableVolumeInfo();
                parcelableVolumeInfo.f338a = parcel.readInt();
                parcelableVolumeInfo.f340l = parcel.readInt();
                parcelableVolumeInfo.f341m = parcel.readInt();
                parcelableVolumeInfo.f342n = parcel.readInt();
                parcelableVolumeInfo.f339b = parcel.readInt();
                return parcelableVolumeInfo;
            case 8:
                return new PlaybackStateCompat(parcel);
            case 9:
                e.d dVar = new e.d();
                IBinder strongBinder = parcel.readStrongBinder();
                int i = e.c.j;
                if (strongBinder != null) {
                    IInterface iInterfaceQueryLocalInterface = strongBinder.queryLocalInterface(e.b.h);
                    if (iInterfaceQueryLocalInterface == null || !(iInterfaceQueryLocalInterface instanceof e.b)) {
                        e.a aVar = new e.a();
                        aVar.i = strongBinder;
                        bVar = aVar;
                    } else {
                        bVar = (e.b) iInterfaceQueryLocalInterface;
                    }
                }
                dVar.f3779a = bVar;
                return dVar;
            case 10:
                int iL0 = t1.l0(parcel);
                long jW2 = 0;
                long jW3 = 0;
                int iV2 = 0;
                while (parcel.dataPosition() < iL0) {
                    int i10 = parcel.readInt();
                    char c10 = (char) i10;
                    if (c10 == 1) {
                        jW2 = t1.W(parcel, i10);
                    } else if (c10 == 2) {
                        iV2 = t1.V(parcel, i10);
                    } else if (c10 != 3) {
                        t1.f0(parcel, i10);
                    } else {
                        jW3 = t1.W(parcel, i10);
                    }
                }
                t1.D(parcel, iL0);
                return new e1.d(iV2, jW2, jW3);
            case 11:
                int iL02 = t1.l0(parcel);
                long jW4 = 0;
                long jW5 = 0;
                long jW6 = 0;
                boolean zT = false;
                String strX4 = null;
                String strX5 = null;
                x4 x4Var = null;
                String strX6 = null;
                u uVar = null;
                u uVar2 = null;
                u uVar3 = null;
                while (parcel.dataPosition() < iL02) {
                    int i11 = parcel.readInt();
                    switch ((char) i11) {
                        case 2:
                            strX4 = t1.x(parcel, i11);
                            break;
                        case 3:
                            strX5 = t1.x(parcel, i11);
                            break;
                        case 4:
                            x4Var = (x4) t1.w(parcel, i11, x4.CREATOR);
                            break;
                        case 5:
                            jW4 = t1.W(parcel, i11);
                            break;
                        case 6:
                            zT = t1.T(parcel, i11);
                            break;
                        case 7:
                            strX6 = t1.x(parcel, i11);
                            break;
                        case '\b':
                            uVar = (u) t1.w(parcel, i11, u.CREATOR);
                            break;
                        case '\t':
                            jW5 = t1.W(parcel, i11);
                            break;
                        case '\n':
                            uVar2 = (u) t1.w(parcel, i11, u.CREATOR);
                            break;
                        case 11:
                            jW6 = t1.W(parcel, i11);
                            break;
                        case '\f':
                            uVar3 = (u) t1.w(parcel, i11, u.CREATOR);
                            break;
                        default:
                            t1.f0(parcel, i11);
                            break;
                    }
                }
                t1.D(parcel, iL02);
                return new e1.e(strX4, strX5, x4Var, jW4, zT, strX6, uVar, jW5, uVar2, jW6, uVar3);
            case 12:
                int iL03 = t1.l0(parcel);
                while (parcel.dataPosition() < iL03) {
                    int i12 = parcel.readInt();
                    if (((char) i12) != 1) {
                        t1.f0(parcel, i12);
                    } else {
                        bundleV3 = t1.v(parcel, i12);
                    }
                }
                t1.D(parcel, iL03);
                return new e1.i(bundleV3);
            case 13:
                int iL04 = t1.l0(parcel);
                while (parcel.dataPosition() < iL04) {
                    int i13 = parcel.readInt();
                    if (((char) i13) != 2) {
                        t1.f0(parcel, i13);
                    } else {
                        bundleV2 = t1.v(parcel, i13);
                    }
                }
                t1.D(parcel, iL04);
                return new t(bundleV2);
            case 14:
                int iL05 = t1.l0(parcel);
                long jW7 = 0;
                String strX7 = null;
                t tVar = null;
                String strX8 = null;
                while (parcel.dataPosition() < iL05) {
                    int i14 = parcel.readInt();
                    char c11 = (char) i14;
                    if (c11 == 2) {
                        strX7 = t1.x(parcel, i14);
                    } else if (c11 == 3) {
                        tVar = (t) t1.w(parcel, i14, t.CREATOR);
                    } else if (c11 == 4) {
                        strX8 = t1.x(parcel, i14);
                    } else if (c11 != 5) {
                        t1.f0(parcel, i14);
                    } else {
                        jW7 = t1.W(parcel, i14);
                    }
                }
                t1.D(parcel, iL05);
                return new u(strX7, tVar, strX8, jW7);
            case 15:
                int iL06 = t1.l0(parcel);
                while (parcel.dataPosition() < iL06) {
                    int i15 = parcel.readInt();
                    char c12 = (char) i15;
                    if (c12 == 1) {
                        strX3 = t1.x(parcel, i15);
                    } else if (c12 == 2) {
                        jW = t1.W(parcel, i15);
                    } else if (c12 != 3) {
                        t1.f0(parcel, i15);
                    } else {
                        iV = t1.V(parcel, i15);
                    }
                }
                t1.D(parcel, iL06);
                return new j4(strX3, iV, jW);
            case 16:
                int iL07 = t1.l0(parcel);
                long jW8 = 0;
                long jW9 = 0;
                int iV3 = 0;
                byte[] bArr = null;
                String strX9 = null;
                Bundle bundleV4 = null;
                String strX10 = null;
                while (parcel.dataPosition() < iL07) {
                    int i16 = parcel.readInt();
                    switch ((char) i16) {
                        case 1:
                            jW8 = t1.W(parcel, i16);
                            break;
                        case 2:
                            int iX = t1.X(parcel, i16);
                            int iDataPosition = parcel.dataPosition();
                            if (iX == 0) {
                                bArr = null;
                            } else {
                                byte[] bArrCreateByteArray = parcel.createByteArray();
                                parcel.setDataPosition(iDataPosition + iX);
                                bArr = bArrCreateByteArray;
                            }
                            break;
                        case 3:
                            strX9 = t1.x(parcel, i16);
                            break;
                        case 4:
                            bundleV4 = t1.v(parcel, i16);
                            break;
                        case 5:
                            iV3 = t1.V(parcel, i16);
                            break;
                        case 6:
                            jW9 = t1.W(parcel, i16);
                            break;
                        case 7:
                            strX10 = t1.x(parcel, i16);
                            break;
                        default:
                            t1.f0(parcel, i16);
                            break;
                    }
                }
                t1.D(parcel, iL07);
                return new m4(jW8, bArr, strX9, bundleV4, iV3, jW9, strX10);
            case 17:
                int iL08 = t1.l0(parcel);
                while (true) {
                    ArrayList arrayList = null;
                    while (parcel.dataPosition() < iL08) {
                        int i17 = parcel.readInt();
                        if (((char) i17) != 1) {
                            t1.f0(parcel, i17);
                        } else {
                            int iX2 = t1.X(parcel, i17);
                            int iDataPosition2 = parcel.dataPosition();
                            if (iX2 == 0) {
                            }
                            ArrayList arrayList2 = new ArrayList();
                            int i18 = parcel.readInt();
                            for (int i19 = 0; i19 < i18; i19++) {
                                arrayList2.add(Integer.valueOf(parcel.readInt()));
                            }
                            parcel.setDataPosition(iDataPosition2 + iX2);
                            arrayList = arrayList2;
                        }
                        break;
                    }
                    t1.D(parcel, iL08);
                    return new n4(arrayList);
                }
                break;
            case 18:
                int iL09 = t1.l0(parcel);
                while (parcel.dataPosition() < iL09) {
                    int i20 = parcel.readInt();
                    if (((char) i20) != 1) {
                        t1.f0(parcel, i20);
                    } else {
                        arrayListZ = t1.z(parcel, i20, m4.CREATOR);
                    }
                }
                t1.D(parcel, iL09);
                return new o4(arrayListZ);
            case 19:
                int iL010 = t1.l0(parcel);
                long jW10 = 0;
                int iV4 = 0;
                String strX11 = null;
                Long lValueOf = null;
                Float fValueOf = null;
                String strX12 = null;
                String strX13 = null;
                Double dValueOf = null;
                while (parcel.dataPosition() < iL010) {
                    int i21 = parcel.readInt();
                    switch ((char) i21) {
                        case 1:
                            iV4 = t1.V(parcel, i21);
                            break;
                        case 2:
                            strX11 = t1.x(parcel, i21);
                            break;
                        case 3:
                            jW10 = t1.W(parcel, i21);
                            break;
                        case 4:
                            int iX3 = t1.X(parcel, i21);
                            if (iX3 == 0) {
                                lValueOf = null;
                            } else {
                                t1.s0(parcel, iX3, 8);
                                lValueOf = Long.valueOf(parcel.readLong());
                            }
                            break;
                        case 5:
                            int iX4 = t1.X(parcel, i21);
                            if (iX4 == 0) {
                                fValueOf = null;
                            } else {
                                t1.s0(parcel, iX4, 4);
                                fValueOf = Float.valueOf(parcel.readFloat());
                            }
                            break;
                        case 6:
                            strX12 = t1.x(parcel, i21);
                            break;
                        case 7:
                            strX13 = t1.x(parcel, i21);
                            break;
                        case '\b':
                            int iX5 = t1.X(parcel, i21);
                            if (iX5 == 0) {
                                dValueOf = null;
                            } else {
                                t1.s0(parcel, iX5, 8);
                                dValueOf = Double.valueOf(parcel.readDouble());
                            }
                            break;
                        default:
                            t1.f0(parcel, i21);
                            break;
                    }
                }
                t1.D(parcel, iL010);
                return new x4(iV4, strX11, jW10, lValueOf, fValueOf, strX12, strX13, dValueOf);
            case 20:
                int iL011 = t1.l0(parcel);
                String strX14 = "";
                String strX15 = strX14;
                String strX16 = strX15;
                String strX17 = strX16;
                int iV5 = 100;
                long jW11 = 0;
                long jW12 = 0;
                long jW13 = 0;
                long jW14 = 0;
                long jW15 = 0;
                long jW16 = 0;
                long jW17 = 0;
                long jW18 = -2147483648L;
                boolean zT2 = true;
                boolean zT3 = true;
                boolean zT4 = false;
                int iV6 = 0;
                boolean zT5 = false;
                boolean zT6 = false;
                int iV7 = 0;
                int iV8 = 0;
                String strX18 = null;
                String strX19 = null;
                String strX20 = null;
                String strX21 = null;
                String strX22 = null;
                String strX23 = null;
                Boolean boolValueOf = null;
                ArrayList<String> arrayList3 = null;
                String strX24 = null;
                String strX25 = null;
                while (parcel.dataPosition() < iL011) {
                    int i22 = parcel.readInt();
                    switch ((char) i22) {
                        case 2:
                            strX18 = t1.x(parcel, i22);
                            break;
                        case 3:
                            strX19 = t1.x(parcel, i22);
                            break;
                        case 4:
                            strX20 = t1.x(parcel, i22);
                            break;
                        case 5:
                            strX21 = t1.x(parcel, i22);
                            break;
                        case 6:
                            jW11 = t1.W(parcel, i22);
                            break;
                        case 7:
                            jW12 = t1.W(parcel, i22);
                            break;
                        case '\b':
                            strX22 = t1.x(parcel, i22);
                            break;
                        case '\t':
                            zT2 = t1.T(parcel, i22);
                            break;
                        case '\n':
                            zT4 = t1.T(parcel, i22);
                            break;
                        case 11:
                            jW18 = t1.W(parcel, i22);
                            break;
                        case '\f':
                            strX23 = t1.x(parcel, i22);
                            break;
                        case '\r':
                        case 17:
                        case 19:
                        case 20:
                        case 24:
                        case '!':
                        default:
                            t1.f0(parcel, i22);
                            break;
                        case 14:
                            jW13 = t1.W(parcel, i22);
                            break;
                        case 15:
                            iV6 = t1.V(parcel, i22);
                            break;
                        case 16:
                            zT3 = t1.T(parcel, i22);
                            break;
                        case 18:
                            zT5 = t1.T(parcel, i22);
                            break;
                        case 21:
                            int iX6 = t1.X(parcel, i22);
                            if (iX6 == 0) {
                                boolValueOf = null;
                            } else {
                                t1.s0(parcel, iX6, 4);
                                boolValueOf = Boolean.valueOf(parcel.readInt() != 0);
                            }
                            break;
                        case 22:
                            jW14 = t1.W(parcel, i22);
                            break;
                        case 23:
                            int iX7 = t1.X(parcel, i22);
                            int iDataPosition3 = parcel.dataPosition();
                            if (iX7 == 0) {
                                arrayList3 = null;
                            } else {
                                ArrayList<String> arrayListCreateStringArrayList = parcel.createStringArrayList();
                                parcel.setDataPosition(iDataPosition3 + iX7);
                                arrayList3 = arrayListCreateStringArrayList;
                            }
                            break;
                        case 25:
                            strX14 = t1.x(parcel, i22);
                            break;
                        case 26:
                            strX15 = t1.x(parcel, i22);
                            break;
                        case 27:
                            strX24 = t1.x(parcel, i22);
                            break;
                        case 28:
                            zT6 = t1.T(parcel, i22);
                            break;
                        case ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_HORIZONTAL_BIAS /* 29 */:
                            jW15 = t1.W(parcel, i22);
                            break;
                        case ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_BIAS /* 30 */:
                            iV5 = t1.V(parcel, i22);
                            break;
                        case 31:
                            strX16 = t1.x(parcel, i22);
                            break;
                        case ' ':
                            iV7 = t1.V(parcel, i22);
                            break;
                        case '\"':
                            jW16 = t1.W(parcel, i22);
                            break;
                        case '#':
                            strX25 = t1.x(parcel, i22);
                            break;
                        case '$':
                            strX17 = t1.x(parcel, i22);
                            break;
                        case '%':
                            jW17 = t1.W(parcel, i22);
                            break;
                        case '&':
                            iV8 = t1.V(parcel, i22);
                            break;
                    }
                }
                t1.D(parcel, iL011);
                return new c5(strX18, strX19, strX20, strX21, jW11, jW12, strX22, zT2, zT4, jW18, strX23, jW13, iV6, zT3, zT5, boolValueOf, jW14, arrayList3, strX14, strX15, strX24, zT6, jW15, iV5, strX16, iV7, jW16, strX25, strX17, jW17, iV8);
            case 21:
                int iL012 = t1.l0(parcel);
                int iV9 = 0;
                while (parcel.dataPosition() < iL012) {
                    int i23 = parcel.readInt();
                    char c13 = (char) i23;
                    if (c13 == 1) {
                        iV = t1.V(parcel, i23);
                    } else if (c13 == 2) {
                        iV9 = t1.V(parcel, i23);
                    } else if (c13 != 3) {
                        t1.f0(parcel, i23);
                    } else {
                        bundleV = t1.v(parcel, i23);
                    }
                }
                t1.D(parcel, iL012);
                return new f0.a(iV, iV9, bundleV);
            case 22:
                int iL013 = t1.l0(parcel);
                GoogleSignInOptions googleSignInOptions = null;
                while (parcel.dataPosition() < iL013) {
                    int i24 = parcel.readInt();
                    char c14 = (char) i24;
                    if (c14 == 2) {
                        strX2 = t1.x(parcel, i24);
                    } else if (c14 != 5) {
                        t1.f0(parcel, i24);
                    } else {
                        googleSignInOptions = (GoogleSignInOptions) t1.w(parcel, i24, GoogleSignInOptions.CREATOR);
                    }
                }
                t1.D(parcel, iL013);
                return new SignInConfiguration(strX2, googleSignInOptions);
            case 23:
                int iL014 = t1.l0(parcel);
                int iV10 = 0;
                int iV11 = 0;
                PendingIntent pendingIntent = null;
                String strX26 = null;
                Integer numValueOf = null;
                while (parcel.dataPosition() < iL014) {
                    int i25 = parcel.readInt();
                    char c15 = (char) i25;
                    if (c15 == 1) {
                        iV10 = t1.V(parcel, i25);
                    } else if (c15 == 2) {
                        iV11 = t1.V(parcel, i25);
                    } else if (c15 == 3) {
                        pendingIntent = (PendingIntent) t1.w(parcel, i25, PendingIntent.CREATOR);
                    } else if (c15 == 4) {
                        strX26 = t1.x(parcel, i25);
                    } else if (c15 != 5) {
                        t1.f0(parcel, i25);
                    } else {
                        int iX8 = t1.X(parcel, i25);
                        if (iX8 == 0) {
                            numValueOf = null;
                        } else {
                            t1.s0(parcel, iX8, 4);
                            numValueOf = Integer.valueOf(parcel.readInt());
                        }
                    }
                }
                t1.D(parcel, iL014);
                return new h0.b(iV10, iV11, pendingIntent, strX26, numValueOf);
            case 24:
                int iL015 = t1.l0(parcel);
                long jW19 = -1;
                int iV12 = 0;
                boolean zT7 = false;
                String strX27 = null;
                while (parcel.dataPosition() < iL015) {
                    int i26 = parcel.readInt();
                    char c16 = (char) i26;
                    if (c16 == 1) {
                        strX27 = t1.x(parcel, i26);
                    } else if (c16 == 2) {
                        iV12 = t1.V(parcel, i26);
                    } else if (c16 == 3) {
                        jW19 = t1.W(parcel, i26);
                    } else if (c16 != 4) {
                        t1.f0(parcel, i26);
                    } else {
                        zT7 = t1.T(parcel, i26);
                    }
                }
                t1.D(parcel, iL015);
                return new h0.d(strX27, iV12, jW19, zT7);
            case 25:
                int iL016 = t1.l0(parcel);
                long jW20 = -1;
                boolean zT8 = false;
                int iV13 = 0;
                int iV14 = 0;
                String strX28 = null;
                while (parcel.dataPosition() < iL016) {
                    int i27 = parcel.readInt();
                    char c17 = (char) i27;
                    if (c17 == 1) {
                        zT8 = t1.T(parcel, i27);
                    } else if (c17 == 2) {
                        strX28 = t1.x(parcel, i27);
                    } else if (c17 == 3) {
                        iV13 = t1.V(parcel, i27);
                    } else if (c17 == 4) {
                        iV14 = t1.V(parcel, i27);
                    } else if (c17 != 5) {
                        t1.f0(parcel, i27);
                    } else {
                        jW20 = t1.W(parcel, i27);
                    }
                }
                t1.D(parcel, iL016);
                return new q(zT8, strX28, iV13, iV14, jW20);
            case 26:
                int iL017 = t1.l0(parcel);
                int iV15 = 0;
                while (parcel.dataPosition() < iL017) {
                    int i28 = parcel.readInt();
                    char c18 = (char) i28;
                    if (c18 == 1) {
                        iV = t1.V(parcel, i28);
                    } else if (c18 == 2) {
                        iV15 = t1.V(parcel, i28);
                    } else if (c18 != 3) {
                        t1.f0(parcel, i28);
                    } else {
                        intent = (Intent) t1.w(parcel, i28, Intent.CREATOR);
                    }
                }
                t1.D(parcel, iL017);
                return new h1.b(iV, iV15, intent);
            case 27:
                int iL018 = t1.l0(parcel);
                ArrayList<String> arrayList4 = null;
                String strX29 = null;
                while (parcel.dataPosition() < iL018) {
                    int i29 = parcel.readInt();
                    char c19 = (char) i29;
                    if (c19 == 1) {
                        int iX9 = t1.X(parcel, i29);
                        int iDataPosition4 = parcel.dataPosition();
                        if (iX9 == 0) {
                            arrayList4 = null;
                        } else {
                            ArrayList<String> arrayListCreateStringArrayList2 = parcel.createStringArrayList();
                            parcel.setDataPosition(iDataPosition4 + iX9);
                            arrayList4 = arrayListCreateStringArrayList2;
                        }
                    } else if (c19 != 2) {
                        t1.f0(parcel, i29);
                    } else {
                        strX29 = t1.x(parcel, i29);
                    }
                }
                t1.D(parcel, iL018);
                return new h1.d(strX29, arrayList4);
            case 28:
                int iL019 = t1.l0(parcel);
                r rVar = null;
                while (parcel.dataPosition() < iL019) {
                    int i30 = parcel.readInt();
                    char c20 = (char) i30;
                    if (c20 == 1) {
                        iV = t1.V(parcel, i30);
                    } else if (c20 == 2) {
                        bVar2 = (h0.b) t1.w(parcel, i30, h0.b.CREATOR);
                    } else if (c20 != 3) {
                        t1.f0(parcel, i30);
                    } else {
                        rVar = (r) t1.w(parcel, i30, r.CREATOR);
                    }
                }
                t1.D(parcel, iL019);
                return new h1.e(iV, bVar2, rVar);
            default:
                int iL020 = t1.l0(parcel);
                while (parcel.dataPosition() < iL020) {
                    int i31 = parcel.readInt();
                    char c21 = (char) i31;
                    if (c21 == 1) {
                        iV = t1.V(parcel, i31);
                    } else if (c21 != 2) {
                        t1.f0(parcel, i31);
                    } else {
                        strX = t1.x(parcel, i31);
                    }
                }
                t1.D(parcel, iL020);
                return new Scope(iV, strX);
        }
    }

    @Override // android.os.Parcelable.Creator
    public final Object[] newArray(int i) {
        switch (this.f324a) {
            case 0:
                return new MediaBrowserCompat$MediaItem[i];
            case 1:
                return new MediaDescriptionCompat[i];
            case 2:
                return new MediaMetadataCompat[i];
            case 3:
                return new RatingCompat[i];
            case 4:
                return new MediaSessionCompat$QueueItem[i];
            case 5:
                return new MediaSessionCompat$ResultReceiverWrapper[i];
            case 6:
                return new MediaSessionCompat$Token[i];
            case 7:
                return new ParcelableVolumeInfo[i];
            case 8:
                return new PlaybackStateCompat[i];
            case 9:
                return new e.d[i];
            case 10:
                return new e1.d[i];
            case 11:
                return new e1.e[i];
            case 12:
                return new e1.i[i];
            case 13:
                return new t[i];
            case 14:
                return new u[i];
            case 15:
                return new j4[i];
            case 16:
                return new m4[i];
            case 17:
                return new n4[i];
            case 18:
                return new o4[i];
            case 19:
                return new x4[i];
            case 20:
                return new c5[i];
            case 21:
                return new f0.a[i];
            case 22:
                return new SignInConfiguration[i];
            case 23:
                return new h0.b[i];
            case 24:
                return new h0.d[i];
            case 25:
                return new q[i];
            case 26:
                return new h1.b[i];
            case 27:
                return new h1.d[i];
            case 28:
                return new h1.e[i];
            default:
                return new Scope[i];
        }
    }
}
