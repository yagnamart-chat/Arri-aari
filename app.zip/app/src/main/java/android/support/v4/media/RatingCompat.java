package android.support.v4.media;

import android.os.Parcel;
import android.os.Parcelable;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes.dex */
public final class RatingCompat implements Parcelable {
    public static final Parcelable.Creator<RatingCompat> CREATOR = new f(3);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f315a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final float f316b;

    public RatingCompat(int i, float f) {
        this.f315a = i;
        this.f316b = f;
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return this.f315a;
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("Rating:style=");
        sb.append(this.f315a);
        sb.append(" rating=");
        float f = this.f316b;
        sb.append(f < 0.0f ? "unrated" : String.valueOf(f));
        return sb.toString();
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.f315a);
        parcel.writeFloat(this.f316b);
    }
}
