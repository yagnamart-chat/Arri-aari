package android.support.v4.media;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.IPackageInstallObserver;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.net.Uri;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Messenger;
import android.os.RemoteException;
import android.util.Log;
import android.util.SparseArray;
import android.util.SparseIntArray;
import androidx.activity.result.ActivityResultLauncher;
import androidx.constraintlayout.core.motion.utils.TypedValues;
import androidx.documentfile.provider.DocumentFile;
import androidx.fragment.app.FragmentActivity;
import androidx.savedstate.serialization.ClassDiscriminatorModeKt;
import c4.uc;
import c4.w4;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.api.internal.BasePendingResult;
import com.google.android.gms.internal.measurement.k1;
import com.google.android.gms.internal.measurement.x0;
import com.google.android.gms.internal.measurement.z3;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.inmobi.cmp.data.model.ChoiceColor;
import com.uptodown.R;
import com.uptodown.UptodownApp;
import com.uptodown.activities.UserDeviceDetailsActivity;
import com.uptodown.activities.UserDevicesActivity;
import com.uptodown.core.activities.InstallerActivity;
import com.uptodown.tv.ui.fragment.TvAppDetailFragment;
import e1.b3;
import e1.c0;
import e1.f0;
import e1.f4;
import e1.g1;
import e1.j4;
import e1.o2;
import e1.t1;
import e1.w0;
import g4.e0;
import g4.h0;
import j$.util.DesugarCollections;
import j$.util.Objects;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.WeakHashMap;
import java.util.concurrent.atomic.AtomicReference;
import k0.x;
import n4.m;
import n5.k;
import n5.p;
import org.json.JSONObject;
import w4.o;
import x4.s1;
import x4.z0;
import y1.n;
import y1.q;
import y1.t;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes.dex */
public class g implements k4.a, o, j1.a, j1.h, h2.a, j1.d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f325a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public Object f326b;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public Object f327l;

    public g(Context context, int i) {
        this.f325a = i;
        switch (i) {
            case 26:
                this.f326b = context;
                if (context != null) {
                    u1.c cVar = (u1.c) n1.g.c().b(u1.c.class);
                    if (cVar == null) {
                        com.google.android.material.drawable.a.j("FirebaseCrashlytics component is not present.");
                        throw null;
                    }
                    boolean zY = z3.y(context, "gdpr_crashlytics_allowed", false);
                    q qVar = cVar.f10112a;
                    Boolean boolValueOf = Boolean.valueOf(zY);
                    t tVar = qVar.f11538b;
                    synchronized (tVar) {
                        tVar.f = false;
                        tVar.g = boolValueOf;
                        SharedPreferences.Editor editorEdit = tVar.f11557a.edit();
                        editorEdit.putBoolean("firebase_crashlytics_collection_enabled", zY);
                        editorEdit.apply();
                        synchronized (tVar.f11559c) {
                            try {
                                boolean zA = tVar.a();
                                boolean z9 = tVar.f11561e;
                                if (zA) {
                                    if (!z9) {
                                        tVar.f11560d.c(null);
                                        tVar.f11561e = true;
                                    }
                                } else if (z9) {
                                    tVar.f11560d = new j1.i();
                                    tVar.f11561e = false;
                                }
                            } catch (Throwable th) {
                                throw th;
                            }
                            break;
                        }
                    }
                    FirebaseAnalytics firebaseAnalytics = FirebaseAnalytics.getInstance(context);
                    this.f327l = firebaseAnalytics;
                    if (z3.y(context, "gdpr_analytics_allowed", false)) {
                        if (firebaseAnalytics != null) {
                            k1 k1Var = firebaseAnalytics.f3227a;
                            Boolean bool = Boolean.TRUE;
                            k1Var.getClass();
                            k1Var.a(new x0(k1Var, bool));
                            return;
                        }
                        return;
                    }
                    if (firebaseAnalytics != null) {
                        k1 k1Var2 = firebaseAnalytics.f3227a;
                        Boolean bool2 = Boolean.FALSE;
                        k1Var2.getClass();
                        k1Var2.a(new x0(k1Var2, bool2));
                        return;
                    }
                    return;
                }
                return;
            default:
                x.g(context);
                Resources resources = context.getResources();
                this.f326b = resources;
                this.f327l = resources.getResourcePackageName(R.string.common_google_play_services_unknown_issue);
                return;
        }
    }

    public static final void b(g gVar, File file) {
        long length;
        Activity activity = (Activity) gVar.f326b;
        h0 h0Var = (h0) gVar.f327l;
        try {
            try {
                PackageManager packageManager = activity.getPackageManager();
                packageManager.getClass();
                String absolutePath = file.getAbsolutePath();
                absolutePath.getClass();
                PackageInfo packageInfoD = d5.a.d(packageManager, absolutePath, 128);
                if ((packageInfoD != null ? packageInfoD.applicationInfo : null) == null) {
                    if (h0Var != null) {
                        String name = file.getName();
                        name.getClass();
                        h0Var.f5123a.M(name.concat(" could not be parsed."));
                    }
                    if (f4.c.v != null) {
                        Bundle bundle = new Bundle();
                        bundle.putString("fileName", file.getName());
                        z4.f fVar = f4.c.v;
                        if (fVar != null) {
                            fVar.send(353, bundle);
                            return;
                        }
                        return;
                    }
                    return;
                }
                ApplicationInfo applicationInfo = packageInfoD.applicationInfo;
                applicationInfo.getClass();
                String str = applicationInfo.packageName;
                long jD = n4.e.d(packageInfoD);
                int i = 0;
                try {
                    PackageManager packageManager2 = activity.getPackageManager();
                    packageManager2.getClass();
                    str.getClass();
                    if (n4.e.d(d5.a.f(packageManager2, str, 0)) > jD) {
                        if (h0Var != null) {
                            file.getName().getClass();
                            h0Var.f5123a.M("invalid version code");
                        }
                        if (f4.c.v != null) {
                            Bundle bundle2 = new Bundle();
                            bundle2.putString("packageName", str);
                            bundle2.putLong("versionCode", jD);
                            z4.f fVar2 = f4.c.v;
                            if (fVar2 != null) {
                                fVar2.send(353, bundle2);
                                return;
                            }
                            return;
                        }
                        return;
                    }
                } catch (PackageManager.NameNotFoundException unused) {
                }
                if (h0Var != null) {
                    file.getName().getClass();
                    InstallerActivity installerActivity = h0Var.f5123a;
                    installerActivity.runOnUiThread(new e0(installerActivity, i));
                }
                if (f4.c.v != null) {
                    Bundle bundle3 = new Bundle();
                    bundle3.putString("packageName", str);
                    bundle3.putLong("versionCode", jD);
                    z4.f fVar3 = f4.c.v;
                    if (fVar3 != null) {
                        fVar3.send(351, bundle3);
                    }
                }
                ApplicationInfo applicationInfo2 = packageInfoD.applicationInfo;
                applicationInfo2.getClass();
                String absolutePath2 = file.getAbsolutePath();
                absolutePath2.getClass();
                applicationInfo2.sourceDir = absolutePath2;
                applicationInfo2.publicSourceDir = absolutePath2;
                String string = packageManager.getApplicationLabel(applicationInfo2).toString();
                long jD2 = n4.e.d(packageInfoD);
                String absolutePath3 = file.getAbsolutePath();
                absolutePath3.getClass();
                try {
                    length = new File(absolutePath3).length();
                } catch (Exception unused2) {
                    length = -1;
                }
                long j = length;
                f4.a aVar = f4.a.f4875a;
                String str2 = packageInfoD.packageName;
                str2.getClass();
                aVar.c(jD2, j, str2, string);
                packageManager.getClass().getMethod("installPackage", (Class[]) Arrays.copyOf(new Class[]{Uri.class, IPackageInstallObserver.class, Integer.TYPE, String.class}, 4)).invoke(packageManager, Uri.fromFile(file), new m(gVar), 2, null);
            } catch (Exception e5) {
                f4.a.f4875a.a();
                if (h0Var != null) {
                    file.getName().getClass();
                    String message = e5.getMessage();
                    InstallerActivity installerActivity2 = h0Var.f5123a;
                    if (message != null) {
                        installerActivity2.M(message);
                    } else {
                        String string2 = installerActivity2.getString(R.string.error_unknown);
                        string2.getClass();
                        installerActivity2.M(string2);
                    }
                }
                if (f4.c.v != null) {
                    Bundle bundle4 = new Bundle();
                    bundle4.putString("fileName", file.getName());
                    z4.f fVar4 = f4.c.v;
                    if (fVar4 != null) {
                        fVar4.send(353, bundle4);
                    }
                }
            }
        } catch (Error e8) {
            f4.a.f4875a.a();
            if (h0Var != null) {
                file.getName().getClass();
                String message2 = e8.getMessage();
                InstallerActivity installerActivity3 = h0Var.f5123a;
                if (message2 != null) {
                    installerActivity3.M(message2);
                } else {
                    String string3 = installerActivity3.getString(R.string.error_unknown);
                    string3.getClass();
                    installerActivity3.M(string3);
                }
            }
            if (f4.c.v != null) {
                Bundle bundle5 = new Bundle();
                bundle5.putString("fileName", file.getName());
                z4.f fVar5 = f4.c.v;
                if (fVar5 != null) {
                    fVar5.send(353, bundle5);
                }
            }
        }
    }

    public static final boolean c(g gVar, String str) {
        m4.b bVar = (m4.b) gVar.f327l;
        f0.i iVar = (f0.i) gVar.f326b;
        try {
            Socket socket = bVar.f7172d;
            if (socket == null) {
                ((UptodownApp) iVar.f4817b).b();
                return false;
            }
            if (socket.isClosed()) {
                ((UptodownApp) iVar.f4817b).b();
                return false;
            }
            Socket socket2 = bVar.f7172d;
            socket2.getClass();
            DataOutputStream dataOutputStream = new DataOutputStream(socket2.getOutputStream());
            dataOutputStream.writeUTF(str);
            dataOutputStream.flush();
            return true;
        } catch (UnknownHostException e5) {
            e5.printStackTrace();
            ((UptodownApp) iVar.f4817b).b();
            return false;
        } catch (IOException e8) {
            e8.printStackTrace();
            ((UptodownApp) iVar.f4817b).b();
            return false;
        } catch (Exception e10) {
            e10.printStackTrace();
            ((UptodownApp) iVar.f4817b).b();
            return false;
        }
    }

    public void A() {
        t1 t1Var = ((b3) this.f327l).f3925a;
        g1 g1Var = t1Var.f4313n;
        t1.k(g1Var);
        SparseArray sparseArrayM = g1Var.m();
        j4 j4Var = (j4) this.f326b;
        sparseArrayM.put(j4Var.f4114l, Long.valueOf(j4Var.f4113b));
        g1 g1Var2 = t1Var.f4313n;
        t1.k(g1Var2);
        int[] iArr = new int[sparseArrayM.size()];
        long[] jArr = new long[sparseArrayM.size()];
        for (int i = 0; i < sparseArrayM.size(); i++) {
            iArr[i] = sparseArrayM.keyAt(i);
            jArr[i] = ((Long) sparseArrayM.valueAt(i)).longValue();
        }
        Bundle bundle = new Bundle();
        bundle.putIntArray("uriSources", iArr);
        bundle.putLongArray("uriTimestamps", jArr);
        g1Var2.f4041w.M(bundle);
    }

    @Override // w4.o
    public void a(int i) {
        UserDevicesActivity userDevicesActivity = (UserDevicesActivity) this.f326b;
        Object obj = ((uc) ((n5.o) ((p) this.f327l)).f7469a).f2254b.get(i);
        obj.getClass();
        int i10 = UserDevicesActivity.T;
        Intent intent = new Intent(userDevicesActivity, (Class<?>) UserDeviceDetailsActivity.class);
        intent.putExtra("user_device", (s1) obj);
        ActivityResultLauncher activityResultLauncher = userDevicesActivity.S;
        float f = UptodownApp.J;
        activityResultLauncher.launch(intent, b4.c.b(userDevicesActivity));
    }

    @Override // h2.a
    public StackTraceElement[] d(StackTraceElement[] stackTraceElementArr) {
        if (stackTraceElementArr.length <= 1024) {
            return stackTraceElementArr;
        }
        h2.a[] aVarArr = (h2.a[]) this.f326b;
        StackTraceElement[] stackTraceElementArrD = stackTraceElementArr;
        for (int i = 0; i < 1; i++) {
            h2.a aVar = aVarArr[i];
            if (stackTraceElementArrD.length <= 1024) {
                break;
            }
            stackTraceElementArrD = aVar.d(stackTraceElementArr);
        }
        return stackTraceElementArrD.length > 1024 ? ((c0) this.f327l).d(stackTraceElementArrD) : stackTraceElementArrD;
    }

    @Override // j1.a
    public Object e(j1.p pVar) {
        Bundle bundle;
        g0.b bVar = (g0.b) this.f326b;
        Bundle bundle2 = (Bundle) this.f327l;
        bVar.getClass();
        return (pVar.i() && (bundle = (Bundle) pVar.g()) != null && bundle.containsKey("google.messenger")) ? bVar.a(bundle2).j(g0.h.f5011l, g0.d.f5006m) : pVar;
    }

    @Override // j1.h
    public j1.p f(Object obj) throws Throwable {
        FileWriter fileWriter;
        g2.e eVar = (g2.e) this.f327l;
        JSONObject jSONObject = (JSONObject) ((z1.e) this.f326b).f11801c.f11794a.submit(new androidx.work.impl.utils.d(this, 1)).get();
        FileWriter fileWriter2 = null;
        if (jSONObject != null) {
            g2.d dVarL = ((f0.i) eVar.f5051m).L(jSONObject);
            f0.i iVar = (f0.i) eVar.f5053o;
            long j = dVarL.f5045c;
            iVar.getClass();
            if (Log.isLoggable("FirebaseCrashlytics", 2)) {
                Log.v("FirebaseCrashlytics", "Writing settings to cache file...", null);
            }
            try {
                jSONObject.put("expires_at", j);
                fileWriter = new FileWriter((File) iVar.f4817b);
            } catch (Exception e5) {
                e = e5;
                fileWriter = null;
            } catch (Throwable th) {
                th = th;
                y1.g.b(fileWriter2, "Failed to close settings writer.");
                throw th;
            }
            try {
                try {
                    fileWriter.write(jSONObject.toString());
                    fileWriter.flush();
                } catch (Exception e8) {
                    e = e8;
                    Log.e("FirebaseCrashlytics", "Failed to cache settings", e);
                }
                y1.g.b(fileWriter, "Failed to close settings writer.");
                g2.e.d(jSONObject, "Loaded settings: ");
                String str = ((g2.f) eVar.f5050l).f;
                SharedPreferences.Editor editorEdit = ((Context) eVar.f5049b).getSharedPreferences("com.google.firebase.crashlytics", 0).edit();
                editorEdit.putString("existing_instance_identifier", str);
                editorEdit.apply();
                ((AtomicReference) eVar.f5056r).set(dVarL);
                ((j1.i) ((AtomicReference) eVar.f5057s).get()).c(dVarL);
            } catch (Throwable th2) {
                th = th2;
                fileWriter2 = fileWriter;
                y1.g.b(fileWriter2, "Failed to close settings writer.");
                throw th;
            }
        }
        return b2.t1.F(null);
    }

    @Override // k4.a
    public void g(DocumentFile documentFile) {
        int i = this.f325a;
    }

    public void h(Object obj, String str) {
        int length = str.length();
        String strValueOf = String.valueOf(obj);
        ((ArrayList) this.f326b).add(a4.x.o(new StringBuilder(length + 1 + strValueOf.length()), str, "=", strValueOf));
    }

    @Override // k4.a
    public void j(Object obj, int i, int i10, long j) {
        int i11 = this.f325a;
        obj.getClass();
    }

    @Override // k4.a
    public void k(File file) {
        int i = this.f325a;
        file.getClass();
    }

    @Override // k4.a
    public void l(DocumentFile documentFile) {
        int i = this.f325a;
    }

    @Override // k4.a
    public void m(int i, String str, long j, long j10) {
        int i10 = this.f325a;
        str.getClass();
    }

    @Override // k4.a
    public void p(File file) {
        int i = this.f325a;
        file.getClass();
    }

    @Override // j1.d
    public void q(j1.p pVar) {
        ((Map) ((g) this.f327l).f327l).remove((j1.i) this.f326b);
    }

    public String s(String str) {
        String str2 = (String) this.f327l;
        Resources resources = (Resources) this.f326b;
        int identifier = resources.getIdentifier(str, TypedValues.Custom.S_STRING, str2);
        if (identifier == 0) {
            return null;
        }
        return resources.getString(identifier);
    }

    /* JADX WARN: Removed duplicated region for block: B:158:0x02ff  */
    /* JADX WARN: Removed duplicated region for block: B:161:0x030a  */
    /* JADX WARN: Removed duplicated region for block: B:164:0x0315  */
    /* JADX WARN: Removed duplicated region for block: B:167:0x0320  */
    /* JADX WARN: Removed duplicated region for block: B:243:? A[RETURN, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void t(android.os.Bundle r21, java.lang.String r22) {
        /*
            Method dump skipped, instruction units count: 881
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v4.media.g.t(android.os.Bundle, java.lang.String):void");
    }

    public String toString() {
        switch (this.f325a) {
            case 19:
                StringBuilder sb = new StringBuilder(100);
                sb.append(this.f327l.getClass().getSimpleName());
                sb.append('{');
                ArrayList arrayList = (ArrayList) this.f326b;
                int size = arrayList.size();
                for (int i = 0; i < size; i++) {
                    sb.append((String) arrayList.get(i));
                    if (i < size - 1) {
                        sb.append(", ");
                    }
                }
                sb.append('}');
                return sb.toString();
            default:
                return super.toString();
        }
    }

    public void u(String str, Exception exc) {
        Context context = (Context) this.f326b;
        if (context != null) {
            boolean z9 = false;
            try {
                SharedPreferences sharedPreferences = context.getSharedPreferences("SettingsPreferences", 0);
                if (sharedPreferences.contains("gdpr_crashlytics_allowed")) {
                    z9 = sharedPreferences.getBoolean("gdpr_crashlytics_allowed", false);
                }
            } catch (Exception unused) {
            }
            if (z9) {
                u1.c cVar = (u1.c) n1.g.c().b(u1.c.class);
                if (cVar == null) {
                    com.google.android.material.drawable.a.j("FirebaseCrashlytics component is not present.");
                    return;
                }
                q qVar = cVar.f10112a;
                z1.e eVar = qVar.f11546o;
                eVar.f11799a.a(new n(0, qVar, str));
                Map map = Collections.EMPTY_MAP;
                eVar.f11799a.a(new n(qVar, exc));
            }
        }
    }

    @Override // k4.a
    public void v(Object obj) {
        int i = this.f325a;
        obj.getClass();
    }

    public void w(String str, Bundle bundle, z0 z0Var, String str2) {
        Bundle bundle2 = new Bundle();
        if (bundle == null) {
            bundle = bundle2;
        }
        if (z0Var != null) {
            int i = z0Var.f11367b;
            if (i > 0) {
                bundle.putString("responseCode", String.valueOf(i));
            }
            String str3 = z0Var.f11368c;
            if (str3 != null) {
                bundle.putString("exception", str3);
            }
        }
        if (str2 != null) {
            bundle.putString("workRequest", str2);
        }
        bundle.putString(ClassDiscriminatorModeKt.CLASS_DISCRIMINATOR_KEY, str);
        t(bundle, "tracking");
    }

    @Override // k4.a
    public void x() {
        switch (this.f325a) {
            case 2:
                w4 w4Var = (w4) this.f326b;
                File file = new File(w4Var.getExternalFilesDir(null), "tmp");
                if (!file.exists()) {
                    file.mkdirs();
                }
                String str = ((l4.b) ((ArrayList) this.f327l).get(0)).f6972c;
                str.getClass();
                File file2 = new File(file, str);
                w4Var.Y = file2;
                m4.g gVar = f4.c.f4891z;
                if ((gVar != null ? gVar.f : null) != null) {
                    if (file2.exists()) {
                        File file3 = w4Var.Y;
                        file3.getClass();
                        if (!file3.isDirectory()) {
                            new UptodownApp();
                            File file4 = w4Var.Y;
                            file4.getClass();
                            f4.c.c(file4);
                        }
                    }
                    w4Var.i(w4Var.getString(R.string.error_generico));
                } else {
                    w4Var.D();
                }
                break;
            default:
                float f = UptodownApp.J;
                File file5 = (File) this.f326b;
                file5.getClass();
                FragmentActivity fragmentActivityRequireActivity = ((TvAppDetailFragment) this.f327l).requireActivity();
                fragmentActivityRequireActivity.getClass();
                b4.c.r(fragmentActivityRequireActivity, null, file5);
                break;
        }
    }

    public void y(Throwable th) {
        j4 j4Var = (j4) this.f326b;
        b3 b3Var = (b3) this.f327l;
        b3Var.g();
        b3Var.f3867r = false;
        t1 t1Var = b3Var.f3925a;
        e1.g gVar = t1Var.f4312m;
        w0 w0Var = t1Var.f4314o;
        int i = 2;
        if (gVar.q(null, f0.U0)) {
            String message = th.getMessage();
            b3Var.f3871w = false;
            if (message != null) {
                if ((th instanceof IllegalStateException) || message.contains("garbage collected") || th.getClass().getSimpleName().equals("ServiceUnavailableException")) {
                    if (message.contains("Background")) {
                        b3Var.f3871w = true;
                    }
                    i = 1;
                } else if ((th instanceof SecurityException) && !message.endsWith("READ_DEVICE_CONFIG")) {
                    i = 3;
                }
            }
        }
        int i10 = i - 1;
        if (i10 == 0) {
            t1.m(w0Var);
            w0Var.f4391r.d(w0.o(t1Var.r().m()), "registerTriggerAsync failed with retriable error. Will try later. App ID, throwable", w0.o(th.toString()));
            b3Var.f3868s = 1;
            b3Var.E().add(j4Var);
            return;
        }
        if (i10 != 1) {
            t1.m(w0Var);
            w0Var.f4388o.d(w0.o(t1Var.r().m()), "registerTriggerAsync failed. Dropping URI. App ID, Throwable", th);
            A();
            b3Var.f3868s = 1;
            b3Var.F();
            return;
        }
        b3Var.E().add(j4Var);
        if (b3Var.f3868s > ((Integer) f0.f4012x0.a(null)).intValue()) {
            b3Var.f3868s = 1;
            t1.m(w0Var);
            w0Var.f4391r.d(w0.o(t1Var.r().m()), "registerTriggerAsync failed. May try later. App ID, throwable", w0.o(th.toString()));
            return;
        }
        t1.m(w0Var);
        w0Var.f4391r.e("registerTriggerAsync failed. App ID, delay in seconds, throwable", w0.o(t1Var.r().m()), w0.o(String.valueOf(b3Var.f3868s)), w0.o(th.toString()));
        int i11 = b3Var.f3868s;
        if (b3Var.f3869t == null) {
            b3Var.f3869t = new o2(b3Var, t1Var, 1);
        }
        b3Var.f3869t.b(((long) i11) * 1000);
        int i12 = b3Var.f3868s;
        b3Var.f3868s = i12 + i12;
    }

    public void z(boolean z9, Status status) {
        HashMap map;
        HashMap map2;
        synchronized (((Map) this.f326b)) {
            map = new HashMap((Map) this.f326b);
        }
        synchronized (((Map) this.f327l)) {
            map2 = new HashMap((Map) this.f327l);
        }
        for (Map.Entry entry : map.entrySet()) {
            if (z9 || ((Boolean) entry.getValue()).booleanValue()) {
                ((BasePendingResult) entry.getKey()).c(status);
            }
        }
        for (Map.Entry entry2 : map2.entrySet()) {
            if (z9 || ((Boolean) entry2.getValue()).booleanValue()) {
                ((j1.i) entry2.getKey()).b(new g0.n(status));
            }
        }
    }

    private final void i(DocumentFile documentFile) {
    }

    private final void n(DocumentFile documentFile) {
    }

    private final void o(DocumentFile documentFile) {
    }

    private final void r(DocumentFile documentFile) {
    }

    public /* synthetic */ g(int i, boolean z9) {
        this.f325a = i;
    }

    public /* synthetic */ g(Object obj, Object obj2, int i, boolean z9) {
        this.f325a = i;
        this.f326b = obj2;
        this.f327l = obj;
    }

    public g(int i) {
        this.f325a = i;
        switch (i) {
            case 21:
                h0.e eVar = h0.e.f5247d;
                this.f326b = new SparseIntArray();
                this.f327l = eVar;
                break;
            default:
                this.f326b = DesugarCollections.synchronizedMap(new WeakHashMap());
                this.f327l = DesugarCollections.synchronizedMap(new WeakHashMap());
                break;
        }
    }

    public g(a3.d dVar, q5.w0 w0Var) {
        this.f325a = 29;
        this.f327l = w0Var;
        dVar.w(new q1.b(this, 0));
        this.f326b = new HashSet();
    }

    public /* synthetic */ g(int i, Object obj, Object obj2) {
        this.f325a = i;
        this.f326b = obj;
        this.f327l = obj2;
    }

    public g(IBinder iBinder) throws RemoteException {
        this.f325a = 10;
        String interfaceDescriptor = iBinder.getInterfaceDescriptor();
        if (Objects.equals(interfaceDescriptor, "android.os.IMessenger")) {
            this.f326b = new Messenger(iBinder);
            this.f327l = null;
        } else if (Objects.equals(interfaceDescriptor, "com.google.android.gms.iid.IMessengerCompat")) {
            this.f327l = new g0.g(iBinder);
            this.f326b = null;
        } else {
            Log.w("MessengerIpcClient", "Invalid interface descriptor: ".concat(String.valueOf(interfaceDescriptor)));
            throw new RemoteException();
        }
    }

    public g(ChoiceColor choiceColor, ChoiceColor choiceColor2, c0 c0Var) {
        this.f325a = 28;
        this.f326b = choiceColor;
        this.f327l = choiceColor2;
    }

    public g(f4 f4Var) {
        this.f325a = 8;
        this.f327l = f4Var;
    }

    public /* synthetic */ g(Object obj) {
        this.f325a = 19;
        this.f327l = obj;
        this.f326b = new ArrayList();
    }

    public g(String str, t0.f fVar, c0 c0Var) {
        this.f325a = 15;
        this.f327l = str;
        this.f326b = fVar;
    }

    public g(f0.i iVar, m4.b bVar) {
        this.f325a = 24;
        iVar.getClass();
        this.f326b = iVar;
        this.f327l = bVar;
    }

    public g(UptodownApp uptodownApp) {
        this.f325a = 27;
        this.f326b = uptodownApp;
        this.f327l = new k(this);
    }

    public g(h2.a[] aVarArr) {
        this.f325a = 14;
        this.f326b = aVarArr;
        this.f327l = new c0(13);
    }
}
