package android.support.v4.media;

import android.content.ComponentName;
import android.content.Context;
import android.media.browse.MediaBrowser;
import android.os.Bundle;
import android.os.Messenger;
import android.support.v4.media.session.MediaSessionCompat$Token;
import androidx.collection.ArrayMap;
import androidx.media.MediaBrowserProtocol;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes.dex */
public class d implements b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Context f319a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final MediaBrowser f320b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Bundle f321c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final a f322d = new a(this);

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final ArrayMap f323e = new ArrayMap();
    public g f;
    public Messenger g;
    public MediaSessionCompat$Token h;

    public d(Context context, ComponentName componentName, c cVar) {
        this.f319a = context;
        Bundle bundle = new Bundle();
        this.f321c = bundle;
        bundle.putInt(MediaBrowserProtocol.EXTRA_CLIENT_VERSION, 1);
        cVar.setInternalConnectionCallback(this);
        this.f320b = new MediaBrowser(context, componentName, (MediaBrowser.ConnectionCallback) cVar.mConnectionCallbackObj, bundle);
    }
}
