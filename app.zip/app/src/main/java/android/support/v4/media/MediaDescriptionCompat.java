package android.support.v4.media;

import android.graphics.Bitmap;
import android.media.MediaDescription;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.v4.media.session.m;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes.dex */
public final class MediaDescriptionCompat implements Parcelable {
    public static final Parcelable.Creator<MediaDescriptionCompat> CREATOR = new f(1);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f305a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final CharSequence f306b;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final CharSequence f307l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final CharSequence f308m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final Bitmap f309n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final Uri f310o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final Bundle f311p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final Uri f312q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public Object f313r;

    public MediaDescriptionCompat(String str, CharSequence charSequence, CharSequence charSequence2, CharSequence charSequence3, Bitmap bitmap, Uri uri, Bundle bundle, Uri uri2) {
        this.f305a = str;
        this.f306b = charSequence;
        this.f307l = charSequence2;
        this.f308m = charSequence3;
        this.f309n = bitmap;
        this.f310o = uri;
        this.f311p = bundle;
        this.f312q = uri2;
    }

    public static MediaDescriptionCompat a(Object obj) {
        Uri mediaUri;
        Bundle bundle;
        if (obj == null) {
            return null;
        }
        MediaDescription mediaDescription = (MediaDescription) obj;
        String mediaId = mediaDescription.getMediaId();
        CharSequence title = mediaDescription.getTitle();
        CharSequence subtitle = mediaDescription.getSubtitle();
        CharSequence description = mediaDescription.getDescription();
        Bitmap iconBitmap = mediaDescription.getIconBitmap();
        Uri iconUri = mediaDescription.getIconUri();
        Bundle extras = mediaDescription.getExtras();
        if (extras != null) {
            m.a(extras);
            mediaUri = (Uri) extras.getParcelable("android.support.v4.media.description.MEDIA_URI");
        } else {
            mediaUri = null;
        }
        if (mediaUri == null) {
            bundle = extras;
        } else if (extras.containsKey("android.support.v4.media.description.NULL_BUNDLE_FLAG") && extras.size() == 2) {
            bundle = null;
        } else {
            extras.remove("android.support.v4.media.description.MEDIA_URI");
            extras.remove("android.support.v4.media.description.NULL_BUNDLE_FLAG");
            bundle = extras;
        }
        if (mediaUri == null) {
            mediaUri = mediaDescription.getMediaUri();
        }
        MediaDescriptionCompat mediaDescriptionCompat = new MediaDescriptionCompat(mediaId, title, subtitle, description, iconBitmap, iconUri, bundle, mediaUri);
        mediaDescriptionCompat.f313r = obj;
        return mediaDescriptionCompat;
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    public final String toString() {
        return ((Object) this.f306b) + ", " + ((Object) this.f307l) + ", " + ((Object) this.f308m);
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i) {
        Object objBuild = this.f313r;
        if (objBuild == null) {
            MediaDescription.Builder builder = new MediaDescription.Builder();
            builder.setMediaId(this.f305a);
            builder.setTitle(this.f306b);
            builder.setSubtitle(this.f307l);
            builder.setDescription(this.f308m);
            builder.setIconBitmap(this.f309n);
            builder.setIconUri(this.f310o);
            builder.setExtras(this.f311p);
            builder.setMediaUri(this.f312q);
            objBuild = builder.build();
            this.f313r = objBuild;
        }
        ((MediaDescription) objBuild).writeToParcel(parcel, i);
    }
}
