package android.support.v4.media;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes.dex */
public abstract class c {
    b mConnectionCallbackInternal;
    final Object mConnectionCallbackObj = new i(new a3.d(this, 2));

    public abstract void onConnected();

    public abstract void onConnectionFailed();

    public abstract void onConnectionSuspended();

    public void setInternalConnectionCallback(b bVar) {
        this.mConnectionCallbackInternal = bVar;
    }
}
