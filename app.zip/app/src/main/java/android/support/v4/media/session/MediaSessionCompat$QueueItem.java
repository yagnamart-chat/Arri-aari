package android.support.v4.media.session;

import a4.x;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.v4.media.MediaDescriptionCompat;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes.dex */
public final class MediaSessionCompat$QueueItem implements Parcelable {
    public static final Parcelable.Creator<MediaSessionCompat$QueueItem> CREATOR = new android.support.v4.media.f(4);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final MediaDescriptionCompat f332a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final long f333b;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final Object f334l;

    public MediaSessionCompat$QueueItem(Object obj, MediaDescriptionCompat mediaDescriptionCompat, long j) {
        if (mediaDescriptionCompat == null) {
            com.google.android.material.drawable.a.l("Description cannot be null.");
            throw null;
        }
        if (j == -1) {
            com.google.android.material.drawable.a.l("Id cannot be QueueItem.UNKNOWN_ID");
            throw null;
        }
        this.f332a = mediaDescriptionCompat;
        this.f333b = j;
        this.f334l = obj;
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("MediaSession.QueueItem {Description=");
        sb.append(this.f332a);
        sb.append(", Id=");
        return x.l(sb, this.f333b, " }");
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i) {
        this.f332a.writeToParcel(parcel, i);
        parcel.writeLong(this.f333b);
    }

    public MediaSessionCompat$QueueItem(Parcel parcel) {
        this.f332a = MediaDescriptionCompat.CREATOR.createFromParcel(parcel);
        this.f333b = parcel.readLong();
    }
}
