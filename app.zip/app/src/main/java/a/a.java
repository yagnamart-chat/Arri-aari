package a;

import a4.d0;
import a4.x;
import a9.k;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Looper;
import android.text.Layout;
import android.text.SpannableStringBuilder;
import android.text.style.StyleSpan;
import android.text.style.UnderlineSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.core.content.ContextCompat;
import androidx.core.location.LocationRequestCompat;
import androidx.fragment.app.FragmentActivity;
import androidx.viewbinding.ViewBindings;
import b2.t1;
import c4.i0;
import c4.p3;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.internal.measurement.j5;
import com.google.android.gms.internal.measurement.z3;
import com.google.firebase.messaging.FirebaseMessaging;
import com.inmobi.cmp.core.model.Vector;
import com.uptodown.R;
import com.uptodown.UptodownApp;
import d8.b;
import e1.c0;
import f4.c;
import f8.d;
import g4.b0;
import g4.z;
import h7.p;
import h8.m0;
import h8.u0;
import h8.v0;
import j8.v;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import kotlin.jvm.internal.l;
import kotlin.jvm.internal.y;
import n5.e;
import o7.g;
import p7.m;
import p7.u;
import t6.q;
import t6.s;
import u6.j;
import v6.h;
import w4.f;
import x4.j1;
import x4.n;
import x4.o;
import y5.i;

/* JADX INFO: compiled from: r8-map-id-d241a5175773bd4f375ad263be01ec5bc45e1e84eb83a7c77655100cbaadf630 */
/* JADX INFO: loaded from: classes.dex */
public abstract class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static boolean f0a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static int f1b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static int f2c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static boolean f3d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static String f4e;

    public static g A(p pVar) {
        g gVar = new g();
        gVar.f7662m = z3.t(pVar, gVar, gVar);
        return gVar;
    }

    public static SpannableStringBuilder B(String str, Context context, f fVar) {
        str.getClass();
        fVar.getClass();
        int i = 0;
        String strB0 = u.b0(u.b0(str, "<br />", "\n", false), "<br/>", "\n", false);
        List<o> listQ = q(strB0);
        SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder(strB0);
        int length = 0;
        for (o oVar : listQ) {
            int i10 = oVar.f11172a;
            String str2 = oVar.f11176e;
            String str3 = oVar.f11175d;
            int i11 = i10 - length;
            int length2 = str3.length() + i11;
            str2.getClass();
            spannableStringBuilder = spannableStringBuilder.replace(i11, str2.length() + i11, (CharSequence) str3);
            spannableStringBuilder.getClass();
            String str4 = oVar.f11173b;
            int iHashCode = str4.hashCode();
            int i12 = 1;
            if (iHashCode != 98) {
                if (iHashCode != 105) {
                    if (iHashCode != 117) {
                        if (iHashCode != 93028092) {
                            if (iHashCode != 1524339519) {
                                if (iHashCode != 3274) {
                                    if (iHashCode == 3275 && str4.equals("h3")) {
                                        float dimension = context.getResources().getDimension(R.dimen.text_size_m);
                                        Typeface typeface = c.f4889x;
                                        typeface.getClass();
                                        spannableStringBuilder.setSpan(new e(dimension, typeface, ContextCompat.getColor(context, R.color.text_primary)), i11, length2, 33);
                                    }
                                } else if (str4.equals("h2")) {
                                    float dimension2 = context.getResources().getDimension(R.dimen.text_size_l);
                                    Typeface typeface2 = c.f4889x;
                                    typeface2.getClass();
                                    spannableStringBuilder.setSpan(new e(dimension2, typeface2, ContextCompat.getColor(context, R.color.text_primary)), i11, length2, 33);
                                }
                            } else if (str4.equals("floatingCategoryID")) {
                                spannableStringBuilder.setSpan(new n(oVar, fVar, context, i12), i11, length2, 33);
                            }
                        } else if (str4.equals("appID")) {
                            spannableStringBuilder.setSpan(new n(oVar, fVar, context, i), i11, length2, 33);
                        }
                    } else if (str4.equals("u")) {
                        spannableStringBuilder.setSpan(new UnderlineSpan(), i11, length2, 33);
                    }
                } else if (str4.equals("i")) {
                    spannableStringBuilder.setSpan(new StyleSpan(2), i11, length2, 33);
                }
            } else if (str4.equals("b")) {
                spannableStringBuilder.setSpan(new StyleSpan(1), i11, length2, 33);
            }
            length = (str2.length() + length) - str3.length();
        }
        return spannableStringBuilder;
    }

    public static final q C(String str) {
        int i;
        j5.o(10);
        int length = str.length();
        if (length == 0) {
            return null;
        }
        int i10 = 0;
        char cCharAt = str.charAt(0);
        if (l.c(cCharAt, 48) < 0) {
            i = 1;
            if (length == 1 || cCharAt != '+') {
                return null;
            }
        } else {
            i = 0;
        }
        int i11 = 119304647;
        while (i < length) {
            int iDigit = Character.digit((int) str.charAt(i), 10);
            if (iDigit < 0) {
                return null;
            }
            int i12 = i10 ^ Integer.MIN_VALUE;
            if (Integer.compare(i12, i11 ^ Integer.MIN_VALUE) > 0) {
                if (i11 != 119304647) {
                    return null;
                }
                i11 = (int) ((((long) (-1)) & 4294967295L) / (4294967295L & ((long) 10)));
                if (Integer.compare(i12, i11 ^ Integer.MIN_VALUE) > 0) {
                    return null;
                }
            }
            int i13 = i10 * 10;
            int i14 = iDigit + i13;
            if (Integer.compare(i14 ^ Integer.MIN_VALUE, i13 ^ Integer.MIN_VALUE) < 0) {
                return null;
            }
            i++;
            i10 = i14;
        }
        return new q(i10);
    }

    public static final s D(String str) {
        int i;
        long j;
        str.getClass();
        int i10 = 10;
        j5.o(10);
        int length = str.length();
        if (length == 0) {
            return null;
        }
        char cCharAt = str.charAt(0);
        int i11 = 1;
        if (l.c(cCharAt, 48) >= 0) {
            i = 0;
        } else {
            if (length == 1 || cCharAt != '+') {
                return null;
            }
            i = 1;
        }
        long j10 = 10;
        long j11 = 0;
        long j12 = 512409557603043100L;
        while (i < length) {
            int iDigit = Character.digit((int) str.charAt(i), i10);
            if (iDigit < 0) {
                return null;
            }
            int i12 = length;
            long j13 = j11 ^ Long.MIN_VALUE;
            int i13 = i;
            if (Long.compare(j13, j12 ^ Long.MIN_VALUE) <= 0) {
                j = j10;
            } else {
                if (j12 != 512409557603043100L) {
                    return null;
                }
                if (j10 >= 0) {
                    long j14 = (LocationRequestCompat.PASSIVE_INTERVAL / j10) << i11;
                    j = j10;
                    j12 = j14 + ((long) ((((-1) - (j14 * j10)) ^ Long.MIN_VALUE) >= (j10 ^ Long.MIN_VALUE) ? i11 : 0));
                } else if (LocationRequestCompat.PASSIVE_INTERVAL < (j10 ^ Long.MIN_VALUE)) {
                    j = j10;
                    j12 = 0;
                } else {
                    j12 = 1;
                    j = j10;
                }
                if (Long.compare(j13, j12 ^ Long.MIN_VALUE) > 0) {
                    return null;
                }
            }
            long j15 = j11 * j;
            long j16 = (((long) iDigit) & 4294967295L) + j15;
            if (Long.compare(j16 ^ Long.MIN_VALUE, j15 ^ Long.MIN_VALUE) < 0) {
                return null;
            }
            i = i13 + 1;
            j11 = j16;
            length = i12;
            j10 = j;
            i10 = 10;
            i11 = 1;
        }
        return new s(j11);
    }

    public static int E(int i) {
        if (i == 0) {
            return 1;
        }
        if (i == 1) {
            return 2;
        }
        if (i == 2) {
            return 3;
        }
        if (i != 3) {
            return i != 4 ? 0 : 5;
        }
        return 4;
    }

    public static void F(int i, int i10) {
        String strO0;
        if (i < 0 || i >= i10) {
            if (i < 0) {
                strO0 = t1.o0("%s (%s) must not be negative", "index", Integer.valueOf(i));
            } else {
                if (i10 < 0) {
                    y2.n.a(String.valueOf(i10).length() + 15, i10, "negative size: ");
                    return;
                }
                strO0 = t1.o0("%s (%s) must be less than size (%s)", "index", Integer.valueOf(i), Integer.valueOf(i10));
            }
            throw new IndexOutOfBoundsException(strO0);
        }
    }

    public static void G(int i, int i10, int i11) {
        if (i < 0 || i10 < i || i10 > i11) {
            throw new IndexOutOfBoundsException((i < 0 || i > i11) ? H(i, i11, "start index") : (i10 < 0 || i10 > i11) ? H(i10, i11, "end index") : t1.o0("end index (%s) must not be less than start index (%s)", Integer.valueOf(i10), Integer.valueOf(i)));
        }
    }

    public static String H(int i, int i10, String str) {
        if (i < 0) {
            return t1.o0("%s (%s) must not be negative", str, Integer.valueOf(i));
        }
        if (i10 >= 0) {
            return t1.o0("%s (%s) must not be greater than size (%s)", str, Integer.valueOf(i), Integer.valueOf(i10));
        }
        y2.n.a(String.valueOf(i10).length() + 15, i10, "negative size: ");
        return null;
    }

    public static boolean I(byte b10) {
        return b10 > -65;
    }

    public static final u0 a(String str, d dVar) {
        if (m.l0(str)) {
            com.google.android.material.drawable.a.l("Blank serial names are prohibited");
            return null;
        }
        Iterator it = ((h) v0.f5414a.values()).iterator();
        while (((v6.d) it).hasNext()) {
            b bVar = (b) ((v6.d) it).next();
            if (str.equals(bVar.getDescriptor().a())) {
                StringBuilder sbV = x.v("\n                The name of serial descriptor should uniquely identify associated serializer.\n                For serial name ", str, " there already exists ");
                sbV.append(y.a(bVar.getClass()).c());
                sbV.append(".\n                Please refer to SerialDescriptor documentation for additional information.\n            ");
                com.google.android.material.drawable.a.l(p7.n.Q(sbV.toString()));
                return null;
            }
        }
        return new u0(str, dVar);
    }

    public static Vector b(int i, String str) {
        if (str.length() != i) {
            throw new a6.e(l.g(": bitfield encoding length mismatch", "h.e"));
        }
        int i10 = 1;
        Vector vector = new Vector(null, i10, 0 == true ? 1 : 0);
        if (1 <= i) {
            while (true) {
                int i11 = i10 + 1;
                String strValueOf = String.valueOf(str.charAt(i10 - 1));
                strValueOf.getClass();
                if (strValueOf.equals("1")) {
                    vector.set(i10);
                }
                if (i10 == i) {
                    break;
                }
                i10 = i11;
            }
        }
        vector.setBitLength(str.length());
        return vector;
    }

    public static final String c(String str) {
        str.getClass();
        return u6.l.j0(m.s0(str, new String[]{" "}), " ", null, null, k9.a.f6875b, 30);
    }

    public static y5.g d(String str) throws a6.e {
        str.getClass();
        List listS0 = m.s0(str, new String[]{"-"});
        if (listS0.size() != 2) {
            throw new a6.e("f.k: TCModelError, hash: ".concat(str));
        }
        int i = Integer.parseInt((String) listS0.get(0));
        int i10 = Integer.parseInt((String) listS0.get(1));
        return new y5.g(i, i10 != 1 ? i10 != 2 ? i.NOT_ALLOWED : i.REQUIRE_LI : i.REQUIRE_CONSENT);
    }

    public static void e(FragmentActivity fragmentActivity, h7.a aVar) {
        View viewInflate = LayoutInflater.from(fragmentActivity).inflate(R.layout.item_opt_out_confirmation, (ViewGroup) null);
        Button button = (Button) viewInflate.findViewById(R.id.btn_opt_out_confirmation_ok);
        TextView textView = (TextView) viewInflate.findViewById(R.id.tv_opt_out_confirmation_message);
        l9.d dVar = q9.c.f8559d;
        if (dVar != null) {
            Integer num = dVar.g;
            if (num != null) {
                viewInflate.setBackgroundColor(num.intValue());
            }
            Integer num2 = dVar.i;
            if (num2 != null) {
                textView.setTextColor(num2.intValue());
            }
            Integer num3 = dVar.f7043m;
            if (num3 != null) {
                button.setTextColor(num3.intValue());
            }
        }
        z3.e(s6.e.f9025d, textView);
        z3.e(s6.e.f9026e, button);
        AlertDialog alertDialogCreate = new AlertDialog.Builder(fragmentActivity).setView(viewInflate).setCancelable(false).create();
        button.setOnClickListener(new b0(alertDialogCreate, aVar));
        alertDialogCreate.show();
    }

    public static final void f(g8.f fVar) {
        fVar.getClass();
        if ((fVar instanceof v ? (v) fVar : null) != null) {
            return;
        }
        n1.i.l(y.a(fVar.getClass()), "This serializer can be used only with Json format.Expected Encoder to be JsonEncoder, got ");
    }

    public static final i8.i g(g8.e eVar) {
        eVar.getClass();
        i8.i iVar = eVar instanceof i8.i ? (i8.i) eVar : null;
        if (iVar != null) {
            return iVar;
        }
        n1.i.l(y.a(eVar.getClass()), "This serializer can be used only with Json format.Expected Decoder to be JsonDecoder, got ");
        return null;
    }

    public static final String h(String str) throws NoSuchAlgorithmException {
        str.getClass();
        MessageDigest messageDigest = MessageDigest.getInstance("MD5");
        byte[] bytes = str.getBytes(p7.a.f7743a);
        bytes.getClass();
        byte[] bArrDigest = messageDigest.digest(bytes);
        bArrDigest.getClass();
        return j.h0(bArrDigest, "", 30);
    }

    public static f8.f i(String str, f8.e[] eVarArr) {
        if (m.l0(str)) {
            com.google.android.material.drawable.a.l("Blank serial names are prohibited");
            return null;
        }
        f8.a aVar = new f8.a(str);
        return new f8.f(str, f8.i.f4987c, aVar.f4966b.size(), j.j0(eVarArr), aVar);
    }

    public static final f8.f j(String str, t1 t1Var, f8.e[] eVarArr, h7.l lVar) {
        if (m.l0(str)) {
            com.google.android.material.drawable.a.l("Blank serial names are prohibited");
            return null;
        }
        if (t1Var.equals(f8.i.f4987c)) {
            com.google.android.material.drawable.a.l("For StructureKind.CLASS please use 'buildClassSerialDescriptor' instead");
            return null;
        }
        f8.a aVar = new f8.a(str);
        lVar.invoke(aVar);
        return new f8.f(str, t1Var, aVar.f4966b.size(), j.j0(eVarArr), aVar);
    }

    public static f8.f k(String str, t1 t1Var, f8.e[] eVarArr) {
        if (m.l0(str)) {
            com.google.android.material.drawable.a.l("Blank serial names are prohibited");
            return null;
        }
        if (t1Var.equals(f8.i.f4987c)) {
            com.google.android.material.drawable.a.l("For StructureKind.CLASS please use 'buildClassSerialDescriptor' instead");
            return null;
        }
        f8.a aVar = new f8.a(str);
        return new f8.f(str, t1Var, aVar.f4966b.size(), j.j0(eVarArr), aVar);
    }

    public static void l(int i, Object[] objArr) {
        for (int i10 = 0; i10 < i; i10++) {
            if (objArr[i10] == null) {
                StringBuilder sb = new StringBuilder(20);
                sb.append("at index ");
                sb.append(i10);
                throw new NullPointerException(sb.toString());
            }
        }
    }

    public static s1.a m(String str, String str2) {
        a3.a aVar = new a3.a(str, str2);
        n9.u uVarA = s1.a.a(a3.a.class);
        uVarA.f7576b = 1;
        uVarA.f = new androidx.core.view.inputmethod.a(aVar, 24);
        return uVarA.d();
    }

    public static final void n(i0 i0Var, String str) {
        if (i0Var.isFinishing() || str == null || str.length() == 0) {
            return;
        }
        AlertDialog alertDialog = i0Var.F;
        if (alertDialog != null) {
            alertDialog.dismiss();
        }
        AlertDialog.Builder builder = new AlertDialog.Builder(i0Var);
        d0 d0VarK = d0.k(i0Var.getLayoutInflater());
        TextView textView = (TextView) d0VarK.f87m;
        TextView textView2 = (TextView) d0VarK.f88n;
        TextView textView3 = (TextView) d0VarK.f89o;
        textView2.setTypeface(c.f4890y);
        textView2.setText(i0Var.getString(R.string.go_to_web_dialog_message));
        textView.setTypeface(c.f4889x);
        textView.setOnClickListener(new c4.v(i0Var, 6));
        textView3.setTypeface(c.f4889x);
        textView3.setText(i0Var.getString(R.string.open_web));
        textView3.setOnClickListener(new b0(25, i0Var, str));
        builder.setView((LinearLayout) d0VarK.f85b);
        builder.setCancelable(true);
        AlertDialog alertDialog2 = i0Var.F;
        if (alertDialog2 == null || !alertDialog2.isShowing()) {
            AlertDialog alertDialogCreate = builder.create();
            i0Var.F = alertDialogCreate;
            alertDialogCreate.getClass();
            Window window = alertDialogCreate.getWindow();
            if (window != null) {
                x.y(window, 0);
            }
            AlertDialog alertDialog3 = i0Var.F;
            alertDialog3.getClass();
            alertDialog3.show();
        }
    }

    public static final void o(i0 i0Var, String str, String str2) {
        i0Var.getClass();
        if (i0Var.isFinishing()) {
            return;
        }
        AlertDialog alertDialog = i0Var.F;
        if (alertDialog != null) {
            alertDialog.dismiss();
        }
        AlertDialog.Builder builder = new AlertDialog.Builder(i0Var);
        View viewInflate = i0Var.getLayoutInflater().inflate(R.layout.dialog_login_required, (ViewGroup) null, false);
        int i = R.id.iv_close_dialog_login_required;
        ImageView imageView = (ImageView) ViewBindings.findChildViewById(viewInflate, R.id.iv_close_dialog_login_required);
        if (imageView != null) {
            i = R.id.tv_login_dialog_login_required;
            TextView textView = (TextView) ViewBindings.findChildViewById(viewInflate, R.id.tv_login_dialog_login_required);
            if (textView != null) {
                i = R.id.tv_msg_dialog_login_required;
                TextView textView2 = (TextView) ViewBindings.findChildViewById(viewInflate, R.id.tv_msg_dialog_login_required);
                if (textView2 != null) {
                    i = R.id.tv_title_dialog_login_required;
                    TextView textView3 = (TextView) ViewBindings.findChildViewById(viewInflate, R.id.tv_title_dialog_login_required);
                    if (textView3 != null) {
                        textView3.setTypeface(c.f4889x);
                        textView3.setText(str);
                        textView2.setTypeface(c.f4890y);
                        textView2.setText(str2);
                        textView.setTypeface(c.f4889x);
                        textView.setOnClickListener(new c4.v(i0Var, 4));
                        imageView.setOnClickListener(new c4.v(i0Var, 5));
                        builder.setView((RelativeLayout) viewInflate);
                        builder.setCancelable(true);
                        AlertDialog alertDialog2 = i0Var.F;
                        if (alertDialog2 == null || !alertDialog2.isShowing()) {
                            AlertDialog alertDialogCreate = builder.create();
                            i0Var.F = alertDialogCreate;
                            alertDialogCreate.getClass();
                            Window window = alertDialogCreate.getWindow();
                            if (window != null) {
                                x.y(window, 0);
                            }
                            AlertDialog alertDialog3 = i0Var.F;
                            alertDialog3.getClass();
                            alertDialog3.show();
                            return;
                        }
                        return;
                    }
                }
            }
        }
        com.google.android.material.drawable.a.j("Missing required view with ID: ".concat(viewInflate.getResources().getResourceName(i)));
    }

    public static k p(String str) {
        str.getClass();
        byte[] bytes = str.getBytes(p7.a.f7743a);
        bytes.getClass();
        k kVar = new k(bytes);
        kVar.f262l = str;
        return kVar;
    }

    public static List q(String str) {
        ArrayList arrayList = new ArrayList();
        o7.e eVar = new o7.e(p7.k.a(new p7.k("\\[(\\w+)=([\\w\\d]*)](.*?)\\[/(\\w+)]"), str));
        while (eVar.hasNext()) {
            p7.i iVar = (p7.i) eVar.next();
            int i = iVar.b().f7218a;
            String str2 = (String) ((p7.h) iVar.a()).get(1);
            long j = Long.parseLong((String) ((p7.h) iVar.a()).get(2));
            String str3 = (String) ((p7.h) iVar.a()).get(3);
            Long lValueOf = Long.valueOf(j);
            String strGroup = iVar.f7764a.group();
            strGroup.getClass();
            arrayList.add(new o(i, str2, lValueOf, str3, strGroup));
        }
        o7.e eVar2 = new o7.e(p7.k.a(new p7.k("\\[url=([^\\]]+)](.*?)\\[/url]"), str));
        while (eVar2.hasNext()) {
            p7.i iVar2 = (p7.i) eVar2.next();
            int i10 = iVar2.b().f7218a;
            String str4 = (String) ((p7.h) iVar2.a()).get(0);
            String str5 = (String) ((p7.h) iVar2.a()).get(1);
            String str6 = (String) ((p7.h) iVar2.a()).get(2);
            String strGroup2 = iVar2.f7764a.group();
            strGroup2.getClass();
            o oVar = new o(str4, str6, strGroup2, i10);
            oVar.f = str5;
            arrayList.add(oVar);
        }
        o7.e eVar3 = new o7.e(p7.k.a(new p7.k("<(\\w+)>(.*?)</(\\w+)>"), str));
        while (eVar3.hasNext()) {
            p7.i iVar3 = (p7.i) eVar3.next();
            int i11 = iVar3.b().f7218a;
            String str7 = (String) ((p7.h) iVar3.a()).get(1);
            String str8 = (String) ((p7.h) iVar3.a()).get(2);
            String strGroup3 = iVar3.f7764a.group();
            strGroup3.getClass();
            arrayList.add(new o(str7, str8, strGroup3, i11));
        }
        return u6.l.p0(arrayList, new z(13));
    }

    public static s1.a r(String str, a3.f fVar) {
        n9.u uVarA = s1.a.a(a3.a.class);
        uVarA.f7576b = 1;
        uVarA.c(s1.i.a(Context.class));
        uVarA.f = new a3.e(0, str, fVar);
        return uVarA.d();
    }

    public static e0.a s(Context context, GoogleSignInOptions googleSignInOptions) {
        k0.x.g(googleSignInOptions);
        return new e0.a(context, d0.a.f3693a, googleSignInOptions, new i0.c(new c0(16), Looper.getMainLooper()));
    }

    public static final b t(b bVar) {
        bVar.getClass();
        return bVar.getDescriptor().c() ? bVar : new m0(bVar);
    }

    public static SpannableStringBuilder u(i0 i0Var, String str) {
        List<o> listK = o7.i.K(new o7.d((o7.f) p7.k.a(new p7.k("\\[a](.*?)\\[/a]"), str), (h7.l) new androidx.room.f(29)));
        SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder(new p7.k("\\[a](.*?)\\[/a]").b(str, new x4.l(0)));
        for (o oVar : listK) {
            int iK0 = m.k0(spannableStringBuilder, oVar.f11175d, 0, false, 6);
            int length = oVar.f11175d.length() + iK0;
            if (iK0 >= 0) {
                spannableStringBuilder.setSpan(new p3(i0Var, 2), iK0, length, 33);
            }
        }
        return spannableStringBuilder;
    }

    public static j1.p v(Intent intent) {
        e0.c cVar;
        GoogleSignInAccount googleSignInAccount;
        j8.n nVar = f0.h.f4814a;
        Status status = Status.f2628p;
        if (intent == null) {
            cVar = new e0.c(null, status);
        } else {
            Status status2 = (Status) intent.getParcelableExtra("googleSignInStatus");
            GoogleSignInAccount googleSignInAccount2 = (GoogleSignInAccount) intent.getParcelableExtra("googleSignInAccount");
            if (googleSignInAccount2 == null) {
                if (status2 != null) {
                    status = status2;
                }
                cVar = new e0.c(null, status);
            } else {
                cVar = new e0.c(googleSignInAccount2, Status.f2626n);
            }
        }
        Status status3 = cVar.f3786a;
        if (status3.f2631a > 0 || (googleSignInAccount = cVar.f3787b) == null) {
            return t1.E(status3.f2633l != null ? new i0.h(status3) : new g0.n(status3));
        }
        return t1.F(googleSignInAccount);
    }

    public static void w(UptodownApp uptodownApp) {
        FirebaseMessaging firebaseMessaging;
        synchronized (FirebaseMessaging.class) {
            firebaseMessaging = FirebaseMessaging.getInstance(n1.g.c());
        }
        firebaseMessaging.getClass();
        j1.i iVar = new j1.i();
        firebaseMessaging.f.execute(new y1.n(3, firebaseMessaging, iVar));
        j1.p pVar = iVar.f6343a;
        androidx.core.view.inputmethod.a aVar = new androidx.core.view.inputmethod.a(uptodownApp, 29);
        pVar.getClass();
        pVar.f6365b.o(new j1.m(j1.j.f6344a, aVar));
        pVar.p();
    }

    public static ArrayList x(Context context) {
        x4.e eVarB;
        int applicationEnabledSetting;
        context.getClass();
        n5.g gVarJ = n5.g.D.j(context);
        gVarJ.b();
        ArrayList arrayList = new ArrayList();
        Iterator it = gVarJ.a0().iterator();
        it.getClass();
        while (it.hasNext()) {
            Object next = it.next();
            next.getClass();
            j1 j1Var = (j1) next;
            String str = j1Var.f11105b;
            str.getClass();
            try {
                applicationEnabledSetting = context.getPackageManager().getApplicationEnabledSetting(str);
            } catch (Error e5) {
                e5.printStackTrace();
            } catch (Exception e8) {
                e8.printStackTrace();
            }
            if (applicationEnabledSetting != 2 && applicationEnabledSetting != 3 && applicationEnabledSetting != 4) {
                if (str.equalsIgnoreCase(context.getPackageName())) {
                    long j = j1Var.f11106l;
                    if (j > 0) {
                        if (j > 721) {
                            arrayList.add(j1Var);
                        }
                    }
                }
                if (!j1Var.b() && (eVarB = gVarJ.B(str)) != null && eVarB.v == 0 && eVarB.b(context)) {
                    arrayList.add(j1Var);
                }
            }
        }
        gVarJ.c();
        return arrayList;
    }

    public static boolean y() {
        HashSet<String> hashSet = new HashSet();
        try {
            n1.b.D("Checking for Root access");
            o4.a aVar = new o4.a(new String[]{"id"}, hashSet);
            q4.c cVarE = q4.c.e(0);
            if (cVarE.j) {
                androidx.window.layout.c.g("Unable to add commands to a closed shell");
            } else if (aVar.f7636d) {
                androidx.window.layout.c.g("This command has already been executed. (Don't re-use command instances.)");
            } else {
                while (cVarE.f7990r) {
                }
                cVarE.i.add(aVar);
                new c0.c(cVarE, 1).start();
            }
            n1.b.n(q4.c.e(0), aVar);
        } catch (Exception unused) {
        }
        for (String str : hashSet) {
            n1.b.D(str);
            if (str.toLowerCase().contains("uid=0")) {
                n1.b.D("Access Given");
                return true;
            }
            return false;
        }
        return false;
    }

    public static final boolean z(TextView textView) {
        int lineCount;
        textView.getClass();
        Layout layout = textView.getLayout();
        return layout != null && (lineCount = layout.getLineCount()) > 0 && layout.getEllipsisCount(lineCount - 1) > 0;
    }
}
